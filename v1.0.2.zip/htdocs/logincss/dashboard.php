<?php
session_start();
if (!isset($_SESSION['username'])) {
    header("Location: ../login.php");
    exit();
}

$username = $_SESSION['username'];
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Dashboard</title>
<style>
:root {
    --bg: #f5f5f5;
    --card-bg: #fff;
    --text: #222;
    --primary: #000;
    --accent: #555;
    --border: #ccc;
}

body {
    font-family: Arial, sans-serif;
    background-color: var(--bg);
    color: var(--text);
    display: flex;
    align-items: center;
    justify-content: center;
    min-height: 100vh;
    margin: 0;
    padding: 15px;
}

/* ✅ Container styling with centered watermark */
.container {
    position: relative;
    background: var(--card-bg);
    border-radius: 12px;
    box-shadow: 0 0 10px rgba(0,0,0,0.2);
    max-width: 900px;
    width: 100%;
    height: 90vh;
    display: flex;
    flex-direction: column;
    justify-content: flex-start;
    padding: 25px;
    box-sizing: border-box;
    overflow-y: auto;
}

/* ✅ Watermark logo in center */
.container::before {
    content: "";
    position: absolute;
    top: 50%;
    left: 50%;
    width: 180px;
    height: 180px;
    background: url('logo.webp') no-repeat center center;
    background-size: contain;
    opacity: 0.25;
    transform: translate(-50%, -50%);
    pointer-events: none;
    z-index: 0;
}

/* Keep content above watermark */
.container > * {
    position: relative;
    z-index: 1;
}

/* Responsive adjustments */
@media (max-width: 768px) {
    .container {
        height: auto;
        min-height: 90vh;
        padding: 18px;
        border-radius: 10px;
    }
    .container::before {
        width: 120px;
        height: 120px;
        top: 55%;
        opacity: 0.18;
    }
}

@media (max-width: 400px) {
    .container::before {
        width: 90px;
        height: 90px;
        opacity: 0.15;
    }
}
</style>
</head>
<body>
<div class="container">

    <!-- Include Navigation -->
    <?php include 'nav.php'; ?>
    
    <h1>Welcome, <?php echo htmlspecialchars($username); ?> 👋</h1>

</div>
</body>
</html>
