<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
session_start();

require_once 'config.php';

// Access control
if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit();
}

$message = "";
$success = false; // track success

// Handle form submission
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $aadhar = trim($_POST['aadhar']);
    $fullname = trim($_POST['fullname']);
    $parent = trim($_POST['parent']);
    $mobile = trim($_POST['mobile']);
    $dob = trim($_POST['dob']);
    $house = trim($_POST['house']);
    $address = trim($_POST['address']);
    $place = trim($_POST['place']);
    $taluk = trim($_POST['taluk']);
    $district = trim($_POST['district']);
    $pincode = trim($_POST['pincode']);
    $created_by = $_SESSION['username'];

    if (!preg_match('/^\d{12}$/', $aadhar)) {
        $message = "❌ Invalid Aadhar number. Must be 12 digits.";
    } elseif (strtotime($dob) >= time()) {
        $message = "❌ Date of Birth cannot be a future date.";
    } else {
        // Check if member already exists
        $check = $conn->prepare("SELECT 1 FROM ABS_customer_details WHERE Aadhar_Number = ?");
        $check->bind_param("s", $aadhar);
        $check->execute();
        $result = $check->get_result();

        if ($result && $result->num_rows > 0) {
            $message = "❌ Member already exists.";
        } else {
            // Insert into ABS_customer_details
            $sql = "INSERT INTO ABS_customer_details 
                (Aadhar_Number, Full_Name, Parent_Name, Mobile_Number, Date_of_Birth, 
                 House_No, Address, Place, Taluk, District, Pincode, Created_By)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

            $stmt = $conn->prepare($sql);
            $stmt->bind_param(
                "ssssssssssss",
                $aadhar, $fullname, $parent, $mobile, $dob, $house,
                $address, $place, $taluk, $district, $pincode, $created_by
            );

            if ($stmt->execute()) {
                // ✅ Successfully inserted into ABS_customer_details

                // Generate username (first 2 words of full name)
                $nameParts = explode(" ", trim($fullname));
                $username = implode(" ", array_slice($nameParts, 0, 2));

                // Insert into ABS_Login_Members_Creds
                $insertLogin = $conn->prepare("
                    INSERT INTO ABS_Login_Members_Creds 
                    (Username, Userid, Password, DateOfBirth, Created_By)
                    VALUES (?, ?, ?, ?, ?)
                ");
                $emptyPassword = ""; // Blank password
                $insertLogin->bind_param(
                    "sssss",
                    $username,
                    $mobile,
                    $emptyPassword,
                    $dob,
                    $created_by
                );
                $insertLogin->execute();
                $insertLogin->close();

                $message = "✅ Member details added successfully!";
                $success = true;
            } else {
                $message = "❌ Error: " . $stmt->error;
            }
            $stmt->close();
        }
        $check->close();
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Add Member</title>
<style>
:root {
    --bg: #f5f5f5;
    --card-bg: #fff;
    --text: #222;
    --primary: #000;
    --accent: #444;
    --border: #ccc;
    --radius: 10px;
}
* { box-sizing: border-box; }

body {
    font-family: Arial, sans-serif;
    background-color: var(--bg);
    color: var(--text);
    margin: 0;
    padding: 15px;
    display: flex;
    justify-content: center;
    align-items: flex-start;
}

.container {
    width: 100%;
    max-width: 900px;
    background: var(--card-bg);
    border-radius: var(--radius);
    box-shadow: 0 4px 15px rgba(0,0,0,0.1);
    padding: 20px;
}

/* TITLE & MESSAGE */
h2 {
    text-align: center;
    margin: 15px 0 20px;
    color: var(--primary);
}
.msg {
    text-align: center;
    font-weight: bold;
    margin-bottom: 15px;
    transition: opacity 0.8s ease;
}
.msg.error { color: red; }
.msg.success { color: green; }

/* FORM STYLES */
form {
    display: flex;
    flex-direction: column;
    gap: 14px;
}

label {
    font-weight: bold;
    margin-bottom: 4px;
}

input, textarea {
    width: 100%;
    padding: 10px;
    border: 1px solid var(--border);
    border-radius: 6px;
    font-size: 15px;
}

textarea {
    resize: none;
}

button {
    background: var(--primary);
    color: #fff;
    border: none;
    padding: 10px;
    border-radius: 6px;
    cursor: pointer;
    font-size: 16px;
    font-weight: bold;
    transition: 0.3s;
}
button:hover {
    background: var(--accent);
}

/* MOBILE */
@media (max-width: 600px) {
    .container {
        padding: 15px;
    }
}
</style>
</head>
<body>
<div class="container">

    <?php include 'nav.php'; ?>

    <h2>Add Member</h2>

    <?php if ($message): ?>
        <div class="msg <?php echo (strpos($message, '❌') !== false) ? 'error' : 'success'; ?>" id="alertMsg">
            <?php echo htmlspecialchars($message); ?>
        </div>
    <?php endif; ?>

    <form method="POST" id="memberForm">
        <label for="aadhar">Aadhar Number</label>
        <input type="text" id="aadhar" name="aadhar" maxlength="12" required>

        <label for="fullname">Full Name</label>
        <input type="text" id="fullname" name="fullname" required>

        <label for="parent">Parent Name</label>
        <input type="text" id="parent" name="parent" required>

        <label for="mobile">Mobile Number</label>
        <input type="tel" id="mobile" name="mobile" maxlength="10" pattern="[0-9]{10}" required>

        <label for="dob">Date of Birth</label>
        <input type="date" id="dob" name="dob" max="<?php echo date('Y-m-d'); ?>" required>

        <label for="house">House No</label>
        <input type="text" id="house" name="house" required>

        <label for="address">Address</label>
        <textarea id="address" name="address" rows="2" required></textarea>

        <label for="place">Place</label>
        <input type="text" id="place" name="place" required>

        <label for="taluk">Taluk</label>
        <input type="text" id="taluk" name="taluk" required>

        <label for="district">District</label>
        <input type="text" id="district" name="district" required>

        <label for="pincode">Pincode</label>
        <input type="text" id="pincode" name="pincode" maxlength="6" pattern="[0-9]{6}" required>

        <button type="submit">Add Member Details</button>
    </form>
</div>

<script>
// Fade out alert message after 4 seconds
setTimeout(() => {
    const msg = document.getElementById('alertMsg');
    if (msg) {
        msg.style.opacity = '0';
        setTimeout(() => msg.remove(), 800);
    }
}, 4000);

// Clear form automatically after success
<?php if ($success): ?>
    document.addEventListener('DOMContentLoaded', () => {
        setTimeout(() => {
            document.getElementById('memberForm').reset();
        }, 500);
    });
<?php endif; ?>
</script>
</body>
</html>
