<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit();
}
?>

<style>
/* ========== GENERAL STYLES ========== */
.navbar {
    background-color: #222;
    color: #fff;
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 10px 15px;
    border-radius: 8px;
    flex-wrap: wrap;
    margin-bottom: 20px;
    position: relative;
    z-index: 1000;
}

.navbar-left, .navbar-right {
    display: flex;
    align-items: center;
    gap: 15px;
}

.navbar a {
    color: #fff;
    text-decoration: none;
    font-weight: bold;
    font-size: 16px;
    padding: 6px 10px;
    border-radius: 5px;
    transition: background 0.3s;
    display: flex;
    align-items: center;
    gap: 8px;
}

.navbar a:hover {
    background-color: #444;
}

/* ========== DROPDOWN STYLES ========== */
.dropdown {
    position: relative;
    display: inline-block;
}

.dropbtn {
    background: none;
    border: none;
    color: #fff;
    font-weight: bold;
    font-size: 16px;
    cursor: pointer;
    padding: 6px 10px;
    border-radius: 5px;
    transition: background 0.3s;
    display: flex;
    align-items: center;
    gap: 8px;
}

.dropbtn:hover {
    background-color: #444;
}

.dropdown-content {
    display: none;
    position: absolute;
    background-color: #333;
    min-width: 180px;
    border-radius: 6px;
    box-shadow: 0 4px 8px rgba(0,0,0,0.3);
    z-index: 2000;
}

.dropdown-content a {
    color: white;
    padding: 10px 12px;
    text-decoration: none;
    display: flex;
    align-items: center;
    gap: 8px;
}

.dropdown-content a:hover {
    background-color: #555;
}

.dropdown:hover .dropdown-content {
    display: block;
}

/* ========== HAMBURGER ICON (blue like mem_nav.php) ========== */
.hamburger {
    display: none;
    flex-direction: column;
    justify-content: center;
    align-items: center;
    cursor: pointer;
    width: 36px;
    height: 32px;
    position: absolute;
    right: 15px;
    top: 12px;
    z-index: 3000;
    background: #00bfff;
    border-radius: 8px;
    padding: 5px;
    box-shadow: 0 0 6px rgba(0, 191, 255, 0.6);
}

.hamburger div {
    height: 3px;
    width: 100%;
    background: #fff;
    margin: 4px 0;
    border-radius: 2px;
    transition: 0.3s;
}

.hamburger.active div:nth-child(1) {
    transform: rotate(45deg) translate(5px, 5px);
}
.hamburger.active div:nth-child(2) {
    opacity: 0;
}
.hamburger.active div:nth-child(3) {
    transform: rotate(-45deg) translate(6px, -6px);
}

/* ========== MOBILE FIX ========== */
@media (max-width: 768px) {
    .hamburger {
        display: flex;
    }

    .navbar {
        flex-direction: column;
        align-items: flex-start;
    }

    .navbar-left, .navbar-right {
        display: flex;
        flex-direction: column;
        gap: 10px;
        width: 100%;
        background: #222;
        border-radius: 8px;
        padding: 0;
        max-height: 0;
        overflow: hidden;
        opacity: 0;
        transform: translateY(-10px);
        transition: all 0.3s ease-in-out;
    }

    .navbar-left.active, .navbar-right.active {
        padding: 10px 0;
        max-height: 800px;
        opacity: 1;
        transform: translateY(0);
    }

    .dropdown-content {
        display: none;
        position: static;
        background: #333;
        box-shadow: none;
        padding-left: 20px;
    }

    .dropdown.open .dropdown-content {
        display: block;
        animation: slideDown 0.25s ease-in-out;
    }

    .dropbtn::after {
        content: " ▼";
        font-size: 12px;
    }

    @keyframes slideDown {
        from { opacity: 0; transform: translateY(-5px); }
        to { opacity: 1; transform: translateY(0); }
    }
}
</style>

<!-- ✅ Font Awesome Icons -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">

<div class="navbar">
    <div class="hamburger" id="hamburger">
        <div></div>
        <div></div>
        <div></div>
    </div>

    <div class="navbar-left" id="navLeft">
        <a href="dashboard.php"><i class="fa-solid fa-house"></i> Home</a>

        <div class="dropdown">
            <button class="dropbtn"><i class="fa-solid fa-id-card"></i> Aadhar Details</button>
            <div class="dropdown-content">
                <a href="addMember.php"><i class="fa-solid fa-user-plus"></i> Add</a>
                <a href="vu_member_details.php"><i class="fa-solid fa-eye"></i> View/Update</a>
            </div>
        </div>

        <div class="dropdown">
            <button class="dropbtn"><i class="fa-solid fa-users"></i> Member</button>
            <div class="dropdown-content">
                <a href="add_MemberToScheme.php"><i class="fa-solid fa-user-check"></i> Add to Scheme</a>
                <a href="search_members.php"><i class="fa-solid fa-magnifying-glass"></i> Search Member</a>
            </div>
        </div>

        <div class="dropdown">
            <button class="dropbtn"><i class="fa-solid fa-file-invoice"></i> Receipt</button>
            <div class="dropdown-content">
                <a href="add_receipt.php"><i class="fa-solid fa-file-circle-plus"></i> Add</a>
                <a href="view_receipts.php"><i class="fa-solid fa-file-lines"></i> View</a>
            </div>
        </div>

        <div class="dropdown">
            <button class="dropbtn"><i class="fa-solid fa-trophy"></i> Dip Information</button>
            <div class="dropdown-content">
                <a href="add_luckydip.php"><i class="fa-solid fa-plus"></i> Add</a>
                <a href="view_monthwisedipinfo.php"><i class="fa-solid fa-calendar-days"></i> Monthwise</a>
            </div>
        </div>
    </div>

    <div class="navbar-right" id="navRight">
        <a href="logout.php"><i class="fa-solid fa-right-from-bracket"></i> Logout</a>
    </div>
</div>

<script>
const hamburger = document.getElementById('hamburger');
const navLeft = document.getElementById('navLeft');
const navRight = document.getElementById('navRight');

hamburger.addEventListener('click', () => {
    hamburger.classList.toggle('active');
    navLeft.classList.toggle('active');
    navRight.classList.toggle('active');
});

// Dropdown tap-to-expand
const dropdowns = document.querySelectorAll('.dropdown');
dropdowns.forEach(drop => {
    const btn = drop.querySelector('.dropbtn');
    btn.addEventListener('click', e => {
        if (window.innerWidth <= 768) {
            e.preventDefault();
            dropdowns.forEach(d => {
                if (d !== drop) d.classList.remove('open');
            });
            drop.classList.toggle('open');
        }
    });
});

// Close menu after link click
document.querySelectorAll('.navbar a').forEach(link => {
    link.addEventListener('click', () => {
        if (window.innerWidth <= 768) {
            hamburger.classList.remove('active');
            navLeft.classList.remove('active');
            navRight.classList.remove('active');
            dropdowns.forEach(d => d.classList.remove('open'));
        }
    });
});
</script>
