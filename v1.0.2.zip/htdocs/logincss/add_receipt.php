<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
session_start();
if (!isset($_SESSION['username'])) {
    header("Location: ../login.php");
    exit();
}

include '../config.php';
$username = $_SESSION['username'];

$schemes = [];
$query = "SELECT Scheme_Name, scheme_table_name, receipt_table_name 
          FROM ABS_Schemes_Details 
          WHERE Status='ACTIVE' 
          ORDER BY Scheme_Name";
$res = $conn->query($query);
if ($res->num_rows > 0) {
    while ($row = $res->fetch_assoc()) {
        $schemes[] = $row;
    }
}

$member = null;
$message = "";

// Handle search
if (isset($_POST['search'])) {
    $criteria = "Scheme_Card_Number";
    $value = trim($_POST['value']);
    $scheme = $_POST['scheme'];
    $schemeTable = "";

    foreach ($schemes as $s) {
        if ($s['Scheme_Name'] == $scheme) {
            $schemeTable = $s['scheme_table_name'];
            break;
        }
    }

    if (!empty($schemeTable) && !empty($value)) {
        $stmt = $conn->prepare("SELECT Scheme_Card_Number, Aadhar_Number, Full_Name, Parent_Name, Mobile_Number, Date_Of_Birth, 
                                       House_No, Address, Place, Taluk, District, Pincode, Winning_Status 
                                FROM $schemeTable WHERE $criteria = ?");
        $stmt->bind_param("s", $value);
        $stmt->execute();
        $result = $stmt->get_result();
        if ($result->num_rows > 0) {
            $member = $result->fetch_assoc();
        } else {
            $message = "❌ No record found for given search criteria.";
        }
    }
}

// Handle confirmed insert
if (isset($_POST['final_confirm_insert'])) {
    $scheme = $_POST['scheme'];
    $receiptTable = "";

    foreach ($schemes as $s) {
        if ($s['Scheme_Name'] == $scheme) {
            $receiptTable = $s['receipt_table_name'];
            break;
        }
    }

    if (!empty($receiptTable)) {
        $Scheme_Card_Number = $_POST['Scheme_Card_Number'];
        $Aadhar_Number = $_POST['Aadhar_Number'];
        $Mobile_Number = $_POST['Mobile_Number'];
        $Receipt_Number = trim($_POST['Receipt_Number']);
        $Receipt_Amount = trim($_POST['Receipt_Amount']);
        $Receipt_Date = $_POST['Receipt_Date'];
        $CreatedBy = $_SESSION['username'];

        if (!ctype_digit($Receipt_Number) || $Receipt_Number <= 0) {
            $message = "⚠️ Receipt Number must be a positive numeric value.";
        } elseif (!ctype_digit($Receipt_Amount) || $Receipt_Amount <= 0) {
            $message = "⚠️ Receipt Amount must be a positive whole number (no decimals).";
        } elseif (strtotime($Receipt_Date) > time()) {
            $message = "⚠️ Receipt Date cannot be a future date.";
        } else {
            $check = $conn->prepare("SELECT * FROM $receiptTable WHERE Receipt_Number = ?");
            $check->bind_param("s", $Receipt_Number);
            $check->execute();
            $exist = $check->get_result();
            if ($exist->num_rows > 0) {
                $message = "⚠️ This receipt number already exists.";
            } else {
                $stmt = $conn->prepare("INSERT INTO $receiptTable 
                    (Scheme_Card_Number, Aadhar_Number, Mobile_Number, Receipt_Number, Receipt_Amount, Receipt_Date, Created_By)
                    VALUES (?, ?, ?, ?, ?, ?, ?)");
                $stmt->bind_param("sssssss", $Scheme_Card_Number, $Aadhar_Number, $Mobile_Number, $Receipt_Number, $Receipt_Amount, $Receipt_Date, $CreatedBy);
                if ($stmt->execute()) {
                    $message = "✅ Receipt added successfully!";
                } else {
                    $message = "❌ Error adding receipt.";
                }
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Add Receipt</title>
<style>
body { font-family: Arial, sans-serif; background: #f5f5f5; margin: 0; padding: 20px; }
.container { background: #fff; border-radius: 12px; box-shadow: 0 0 8px rgba(0,0,0,0.2); max-width: 900px; margin: auto; padding: 25px; position: relative; overflow-y: auto; }
.container::before { content: ""; position: absolute; top: 50%; left: 50%; width: 180px; height: 180px; background-size: contain; opacity: 0.25; transform: translate(-50%, -50%); z-index: 0; }
.container > * { position: relative; z-index: 1; }
h2 { text-align: center; margin-top: 0; }

.search-section { background: #eee; border: 1px solid #ccc; border-radius: 10px; padding: 15px 20px; margin-bottom: 25px; }
.search-title { background: #ddd; padding: 8px 12px; font-weight: bold; border-radius: 6px; margin-bottom: 15px; }

/* ✅ Single-row layout for Search Section */
.search-grid {
  display: grid;
  grid-template-columns: 2fr 2fr 1.5fr;
  gap: 15px;
  align-items: end;
}
@media (max-width: 768px) {
  .search-grid { grid-template-columns: 1fr; }
}

label { font-weight: bold; display: block; margin-bottom: 5px; }
select, input[type="text"], input[type="number"], input[type="date"] {
  width: 100%; padding: 8px; border: 1px solid #bbb; border-radius: 6px; box-sizing: border-box;
}
button { border: none; padding: 10px 15px; border-radius: 6px; font-weight: bold; cursor: pointer; }
.btn-search { background: #28a745; color: #fff; }
.btn-search:hover { background: #218838; }
.btn-clear { background: #dc3545; color: #fff; }
.btn-clear:hover { background: #c82333; }

.details { background: #fafafa; border: 1px solid #ddd; border-radius: 8px; padding: 15px; margin-bottom: 20px; }
.status-badge { padding: 5px 10px; border-radius: 5px; font-weight: bold; color: #fff; }
.status-runner { background: #ffcc00; color: #000; }
.status-winner { background: #28a745; }

.receipt-section { margin-top: 20px; border-top: 2px solid #ccc; padding-top: 15px; }
.receipt-grid { display: grid; grid-template-columns: repeat(4, 1fr); gap: 15px; }
@media (max-width: 768px) { .receipt-grid { grid-template-columns: 1fr; } }

.message { text-align: center; font-weight: bold; margin-top: 10px; }
.message.success { color: green; }
.message.error { color: red; }

.member-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 20px; }
.member-col p { margin: 6px 0; border-bottom: 1px solid #eee; padding-bottom: 5px; }
@media (max-width: 768px) { .member-grid { grid-template-columns: 1fr; } }
</style>

<script>
function clearForm() { window.location.href = "add_receipt.php"; }

function handleConfirmInsert(e) {
    e.preventDefault();
    const form = e.target;
    const name = "<?= isset($member['Full_Name']) ? addslashes($member['Full_Name']) : '' ?>";
    const receiptNo = form.Receipt_Number.value;
    const amount = form.Receipt_Amount.value;
    const date = form.Receipt_Date.value;

    if (!receiptNo || !amount || !date) {
        alert("Please fill all receipt details before submitting.");
        return;
    }

    const msg = `Confirm to add this receipt?\n\nCustomer: ${name}\nReceipt No: ${receiptNo}\nAmount: ₹${amount}\nDate: ${date}`;
    if (confirm(msg)) {
        const hidden = document.createElement('input');
        hidden.type = 'hidden';
        hidden.name = 'final_confirm_insert';
        hidden.value = '1';
        form.appendChild(hidden);
        form.submit();
    }
}
</script>
</head>
<body>
<div class="container">
    <?php include 'nav.php'; ?>
    <h2>Add Receipt</h2>

    <form method="post" class="search-section">
        <div class="search-title">🔍 Search Member</div>
        <div class="search-grid">
            <div>
                <label for="scheme">Select Scheme:</label>
                <select name="scheme" required>
                    <option value="">Select</option>
                    <?php foreach ($schemes as $scheme) { ?>
                        <option value="<?= htmlspecialchars($scheme['Scheme_Name']); ?>" 
                            <?= (isset($_POST['scheme']) && $_POST['scheme']==$scheme['Scheme_Name']) ? 'selected' : ''; ?>>
                            <?= htmlspecialchars($scheme['Scheme_Name']); ?>
                        </option>
                    <?php } ?>
                </select>
            </div>
            <div>
                <label for="value">Scheme Card Number:</label>
                <input type="text" name="value" value="<?= htmlspecialchars($_POST['value'] ?? ''); ?>" required>
            </div>
            <div style="display:flex; gap:10px; justify-content:flex-start;">
                <button type="submit" name="search" class="btn-search">Search</button>
                <button type="button" class="btn-clear" onclick="clearForm()">Clear</button>
            </div>
        </div>
    </form>

    <?php if ($message): ?>
        <div class="message <?= strpos($message, '✅') !== false ? 'success' : 'error'; ?>">
            <?= $message; ?>
        </div>
    <?php endif; ?>

    <?php if ($member): ?>
    <div class="details">
        <h3>Member Details</h3>
        <div class="member-grid">
            <div class="member-col">
                <p><strong>Scheme Card No:</strong> <?= htmlspecialchars($member['Scheme_Card_Number']); ?></p>
                <p><strong>Aadhar No:</strong> <?= htmlspecialchars($member['Aadhar_Number']); ?></p>
                <p><strong>Full Name:</strong> <?= htmlspecialchars($member['Full_Name']); ?></p>
                <p><strong>Parent Name:</strong> <?= htmlspecialchars($member['Parent_Name']); ?></p>
                <p><strong>Mobile:</strong> <?= htmlspecialchars($member['Mobile_Number']); ?></p>
                <p><strong>Date of Birth:</strong> <?= htmlspecialchars($member['Date_Of_Birth']); ?></p>
            </div>
            <div class="member-col">
                <p><strong>Address:</strong> <?= htmlspecialchars($member['Address']); ?></p>
                <p><strong>Taluk:</strong> <?= htmlspecialchars($member['Taluk']); ?></p>
                <p><strong>District:</strong> <?= htmlspecialchars($member['District']); ?></p>
                <p><strong>Pincode:</strong> <?= htmlspecialchars($member['Pincode']); ?></p>
                <p><strong>Winning Status:</strong> 
                    <?php
                        $status = htmlspecialchars($member['Winning_Status']);
                        $class = $status == 'WINNER' ? 'status-winner' : ($status == 'RUNNER' ? 'status-runner' : '');
                        echo "<span class='status-badge $class'>$status</span>";
                    ?>
                </p>
            </div>
        </div>
    </div>

    <?php if ($member['Winning_Status'] != 'WINNER'): ?>
    <div class="receipt-section">
        <h3>Enter Receipt Details</h3>
        <form method="post" onsubmit="handleConfirmInsert(event)">
            <input type="hidden" name="scheme" value="<?= htmlspecialchars($_POST['scheme']); ?>">
            <input type="hidden" name="Scheme_Card_Number" value="<?= htmlspecialchars($member['Scheme_Card_Number']); ?>">
            <input type="hidden" name="Aadhar_Number" value="<?= htmlspecialchars($member['Aadhar_Number']); ?>">
            <input type="hidden" name="Mobile_Number" value="<?= htmlspecialchars($member['Mobile_Number']); ?>">

            <div class="receipt-grid">
                <div>
                    <label>Receipt Number:</label>
                    <input type="text" name="Receipt_Number" value="<?= htmlspecialchars($_POST['Receipt_Number'] ?? ''); ?>" required>
                </div>
                <div>
                    <label>Receipt Amount:</label>
                    <input type="number" name="Receipt_Amount" value="<?= htmlspecialchars($_POST['Receipt_Amount'] ?? ''); ?>" required>
                </div>
                <div>
                    <label>Receipt Date:</label>
                    <input type="date" name="Receipt_Date" value="<?= htmlspecialchars($_POST['Receipt_Date'] ?? ''); ?>" max="<?= date('Y-m-d'); ?>" required>
                </div>
                <div style="display:flex;align-items:end;">
                    <button type="submit" name="confirm_insert" class="btn-search">Submit Receipt</button>
                </div>
            </div>
        </form>
    </div>
    <?php else: ?>
        <div class="message error">🏆 This card has already won. You cannot add receipts for WINNER cards.</div>
    <?php endif; ?>
    <?php endif; ?>
</div>
</body>
</html>
