<?php
// reset_password.php - Black / Gray / White Theme (Improved Alignment + Login Link)
session_start();
require_once 'logincss/config.php';

$errors = [];
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username'] ?? '');
    $dob = trim($_POST['dob'] ?? '');
    $role = trim($_POST['role'] ?? '');
    $new_password = $_POST['new_password'] ?? '';
    $confirm_password = $_POST['confirm_password'] ?? '';

    if ($username === '' || $dob === '' || $role === '' || $new_password === '' || $confirm_password === '') {
        $errors[] = 'Please fill in all fields.';
    } elseif ($new_password !== $confirm_password) {
        $errors[] = 'Passwords do not match.';
    } else {
        // Choose table and key field based on role
        if ($role === 'ADMIN' || $role === 'USER') {
            $table = 'ABS_Login_Creds';
            $keyField = 'username';
        } elseif ($role === 'MEMBER') {
            $table = 'ABS_Login_Members_Creds';
            $keyField = 'Userid';
        } else {
            $errors[] = 'Invalid role selected.';
            $table = '';
        }

        if ($table !== '') {
            $sql = "SELECT $keyField FROM $table WHERE $keyField = ? AND DateofBirth = ? LIMIT 1";
            if ($stmt = $conn->prepare($sql)) {
                $stmt->bind_param('ss', $username, $dob);
                $stmt->execute();
                $result = $stmt->get_result();
                if ($row = $result->fetch_assoc()) {
                    $hashed = password_hash($new_password, PASSWORD_DEFAULT);
                    $update = $conn->prepare("UPDATE $table SET password = ? WHERE $keyField = ?");
                    $update->bind_param('ss', $hashed, $username);
                    if ($update->execute()) {
                        $success = 'Password reset successful. You can now <a href="login.php">login</a>.';
                    } else {
                        $errors[] = 'Failed to update password. Please try again later.';
                    }
                    $update->close();
                } else {
                    $errors[] = 'Invalid username or date of birth.';
                }
                $stmt->close();
            } else {
                $errors[] = 'Database error: unable to prepare statement.';
            }
        }
    }
}
?>

<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Reset Password - ABS Dream India Groups</title>
<style>
:root {
  --bg: #f4f5f6;
  --card: #ffffff;
  --text: #111111;
  --muted: #6b6f73;
  --accent: #000000;
}
html,body {
  height:100%; margin:0; font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,'Helvetica Neue',Arial;
  background:linear-gradient(180deg,var(--bg),#ececec);
  color:var(--text); display:flex; align-items:center; justify-content:center; padding:24px;
}
.container {width:100%; max-width:420px; margin:auto;}
.card {background:var(--card); border-radius:12px; box-shadow:0 6px 18px rgba(16,24,32,0.08); padding:32px; border:1px solid rgba(0,0,0,0.06); box-sizing:border-box;}
h1 {margin:0 0 8px 0; font-size:22px; text-align:center;}
p.lead {margin:0 0 18px 0; color:var(--muted); font-size:13px; text-align:center;}
.form-group {display:flex; flex-direction:column; margin-bottom:16px;}
label {font-size:14px; margin-bottom:6px; color:var(--muted);}
input[type="text"], input[type="password"], input[type="date"], select {
  width:100%; padding:12px 14px; font-size:15px; border-radius:8px;
  border:1px solid rgba(0,0,0,0.12); background:#fafafa; color:var(--text);
  box-sizing:border-box; transition:all 0.2s ease;
}
input:focus, select:focus {outline:none; border-color:#000; box-shadow:0 0 0 2px rgba(0,0,0,0.1);}
.btn {width:100%; padding:12px 16px; font-weight:600; border-radius:10px; border:none; background:var(--accent); color:#fff; font-size:15px; cursor:pointer; transition:background 0.2s ease;}
.btn:hover {background:#222;}
.error, .success {
  padding:12px 14px; border-radius:8px; font-size:13px; margin-bottom:14px; line-height:1.4;
}
.error {background:#fff6f6; border:1px solid #ffd6d6; color:#8a1f1f;}
.success {background:#f0fff5; border:1px solid #a3e6b1; color:#1a5f2a;}
.footer-note {text-align:center; margin-top:16px; font-size:13px; color:var(--muted);}
.login-link {text-align:center; margin-top:18px; font-size:14px;}
.login-link a {color:var(--accent); text-decoration:none; font-weight:600;}
.login-link a:hover {text-decoration:underline;}
@media (max-width:480px){
  body{padding:16px;}
  .card{padding:24px; border-radius:10px;}
  input, .btn, select{font-size:14px;}
}
</style>
</head>
<body>
  <div class="container">
    <div class="card">
      <h1>Reset Password</h1>
      <p class="lead">Enter your username and date of birth to reset your password.</p>

      <?php if (!empty($errors)): ?>
        <div class="error"><?php echo implode('<br>', array_map('htmlspecialchars', $errors)); ?></div>
      <?php endif; ?>

      <?php if ($success): ?>
        <div class="success"><?php echo $success; ?></div>
      <?php else: ?>
        <form method="post" novalidate>
          <div class="form-group">
            <label for="username">Username / User ID</label>
            <input type="text" name="username" id="username" required value="<?php echo htmlspecialchars($_POST['username'] ?? ''); ?>">
          </div>

          <div class="form-group">
            <label for="role">Select Role</label>
            <select name="role" id="role" required>
              <option value="">-- Select Role --</option>
              <option value="ADMIN" <?php echo (($_POST['role'] ?? '') === 'ADMIN') ? 'selected' : ''; ?>>ADMIN</option>
              <option value="USER" <?php echo (($_POST['role'] ?? '') === 'USER') ? 'selected' : ''; ?>>USER</option>
              <option value="MEMBER" <?php echo (($_POST['role'] ?? '') === 'MEMBER') ? 'selected' : ''; ?>>MEMBER</option>
            </select>
          </div>

          <div class="form-group">
            <label for="dob">Date of Birth</label>
            <input type="date" name="dob" id="dob" required value="<?php echo htmlspecialchars($_POST['dob'] ?? ''); ?>">
          </div>

          <div class="form-group">
            <label for="new_password">New Password</label>
            <input type="password" name="new_password" id="new_password" required>
          </div>

          <div class="form-group">
            <label for="confirm_password">Confirm Password</label>
            <input type="password" name="confirm_password" id="confirm_password" required>
          </div>

          <button class="btn" type="submit">Reset Password</button>
        </form>
      <?php endif; ?>

      <div class="login-link">
        <a href="login.php">Back to Login</a>
      </div>

      <div class="footer-note">&copy; <?php echo date('Y'); ?> AssureTechGet - All rights reserved</div>
    </div>
  </div>
</body>
</html>
