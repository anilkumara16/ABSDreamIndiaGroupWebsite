<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once "config.php";

// Fetch schemes (RESTORED WORKING LOGIC)
$schemes = [];
$sql = "SELECT scheme_name FROM ABS_Schemes_Details ORDER BY scheme_name ASC";
$result = $conn->query($sql);
if ($result && $result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $schemes[] = $row['scheme_name'];
    }
}

// CSV Export Handler
if (isset($_POST['export'])) {

    $scheme = $_POST['scheme'];
    $type = $_POST['type'];

    if (!$scheme || !$type) {
        echo "<div class='error-msg'>Please select both fields.</div>";
    } else {

        $q = "SELECT scheme_table_name, receipt_table_name 
              FROM ABS_Schemes_Details 
              WHERE scheme_name='$scheme'";

        $r = $conn->query($q)->fetch_assoc();

        $table = ($type === "customers") ?
                    $r['scheme_table_name'] :
                    $r['receipt_table_name'];

        $data = $conn->query("SELECT * FROM $table");

        // ⭐ Restored date-time CSV filename
        $timestamp = date("Y-m-d_H-i-s");
        header("Content-Type: text/csv");
        header("Content-Disposition: attachment; filename={$table}_{$timestamp}.csv");

        $output = fopen("php://output", "w");

        // Header row
        $first = $data->fetch_assoc();
        fputcsv($output, array_keys($first));

        if (isset($first['Aadhar_Number'])) {
            $first['Aadhar_Number'] = str_pad($first['Aadhar_Number'], 12, "0", STR_PAD_LEFT);
        }
        fputcsv($output, $first);

        while ($row = $data->fetch_assoc()) {
            if (isset($row['Aadhar_Number'])) {
                $row['Aadhar_Number'] = str_pad($row['Aadhar_Number'], 12, "0", STR_PAD_LEFT);
            }
            fputcsv($output, $row);
        }

        fclose($output);
        exit;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Export CSV - ABS</title>
<meta name="viewport" content="width=device-width, initial-scale=1">

<style>
    body {
        margin: 0;
        font-family: 'Poppins', sans-serif;
        background: linear-gradient(135deg, #1f1f1f, #2c2c2c);
        min-height: 100vh;
        color: #fff;
    }

    .logo-box {
        text-align: center;
        padding-top: 30px;
        margin-bottom: -10px;
    }

    .logo-box img {
        width: 120px;
        height: auto;
        filter: drop-shadow(0px 0px 4px rgba(255,255,255,0.3));
    }

    .container-box {
        max-width: 420px;
        background: #111;
        padding: 25px;
        margin: 20px auto 40px;
        border-radius: 12px;
        box-shadow: 0px 0px 12px rgba(255,255,255,0.08);
    }

    h2 {
        text-align: center;
        margin-bottom: 20px;
        font-weight: 600;
    }

    label {
        font-size: 14px;
        font-weight: 500;
    }

    select {
        width: 100%;
        padding: 12px;
        border-radius: 8px;
        margin-top: 6px;
        background: #222;
        color: #fff;
        border: 1px solid #444;
    }

    button {
        width: 100%;
        background: #ffb92d;
        padding: 12px;
        border: none;
        border-radius: 8px;
        margin-top: 20px;
        font-size: 16px;
        font-weight: bold;
        cursor: pointer;
        color: #111;
    }

    button:hover {
        background: #ffcc55;
    }

    .loader {
        display: none;
        text-align: center;
        margin-top: 15px;
    }

    .loader div {
        width: 14px;
        height: 14px;
        background: #ffb92d;
        border-radius: 50%;
        display: inline-block;
        animation: bounce 0.6s infinite alternate;
    }

    .loader div:nth-child(2) {
        animation-delay: 0.2s;
    }
    .loader div:nth-child(3) {
        animation-delay: 0.4s;
    }

    @keyframes bounce {
        to { transform: translateY(-10px); }
    }

    .error-msg {
        margin-top: 15px;
        padding: 10px;
        background: #ff4d4d;
        border-radius: 8px;
        text-align: center;
    }
</style>

<script>
function showLoader() {
    document.getElementById("loader").style.display = "block";
}
</script>

</head>
    <script>
function showLoader() {
    const loader = document.getElementById("loader");
    loader.style.display = "block";

    // ⏳ Auto-hide loader after 4 seconds (covers cancel case)
    setTimeout(() => {
        loader.style.display = "none";
    }, 4000);
}
</script>

<body>

<div class="logo-box">
    <img src="img/6-1024x492.webp" alt="ABS Logo">
</div>

<div class="container-box">
    <h2>Export CSV</h2>

    <form method="POST" onsubmit="showLoader()">

        <label>Select Scheme</label>
        <select name="scheme" required>
            <option value="">-- Select Scheme --</option>
            <?php foreach ($schemes as $s) { echo "<option value='$s'>$s</option>"; } ?>
        </select>

        <br><br>

        <label>Select Type</label>
        <select name="type" required>
            <option value="">-- Select --</option>
            <option value="customers">Customer Details</option>
            <option value="receipts">Receipt Details</option>
        </select>

        <button type="submit" name="export">Download CSV</button>

        <div id="loader" class="loader">
            <div></div><div></div><div></div>
            <p>Generating file...</p>
        </div>
    </form>
</div>

</body>
</html>
