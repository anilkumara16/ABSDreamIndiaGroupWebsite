<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
session_start();
if (!isset($_SESSION['username'])) {
    header("Location: ../login.php");
    exit();
}

require_once "../config.php";
$username = $_SESSION['username'];

// 🔹 Fetch all active schemes
$tables = [];
$tableSQL = "SELECT Scheme_Name, receipt_table_name, scheme_table_name FROM ABS_Schemes_Details WHERE Status = 'ACTIVE'";
$tableResult = $conn->query($tableSQL);

if ($tableResult && $tableResult->num_rows > 0) {
    while ($row = $tableResult->fetch_assoc()) {
        if (!empty($row['receipt_table_name'])) {
            $tables[] = [
                'scheme_name' => $row['Scheme_Name'],
                'receipt_table' => $row['receipt_table_name'],
                'scheme_table' => $row['scheme_table_name']
            ];
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Member Receipts</title>
<style>
:root {
    --bg: #f5f5f5;
    --card-bg: #fff;
    --text: #222;
    --primary: #000;
    --accent: #555;
    --border: #ccc;
    --total-bg: #e8f5e9;
}

body {
    font-family: Arial, sans-serif;
    background-color: var(--bg);
    color: var(--text);
    display: flex;
    align-items: center;
    justify-content: center;
    min-height: 100vh;
    margin: 0;
    padding: 15px;
}

.container {
    position: relative;
    background: var(--card-bg);
    border-radius: 12px;
    box-shadow: 0 0 10px rgba(0,0,0,0.2);
    max-width: 900px;
    width: 100%;
    min-height: 90vh;
    display: flex;
    flex-direction: column;
    justify-content: flex-start;
    padding: 25px;
    box-sizing: border-box;
}

.container::before {
    content: "";
    position: absolute;
    top: 50%;
    left: 50%;
    width: 180px;
    height: 180px;
    /*background: url('logo.webp') no-repeat center center;*/
    background-size: contain;
    opacity: 0.25;
    transform: translate(-50%, -50%);
    pointer-events: none;
    z-index: 0;
}

.container > * {
    position: relative;
    z-index: 1;
}

.table-container {
    margin-top: 20px;
    border: 1px solid var(--border);
    border-radius: 10px;
    overflow: hidden;
    box-shadow: 0 2px 6px rgba(0,0,0,0.1);
}

table {
    width: 100%;
    border-collapse: collapse;
    font-size: 15px;
}

th, td {
    padding: 10px 12px;
    text-align: left;
    border-bottom: 1px solid var(--border);
}

th {
    background: #f0f0f0;
    font-weight: bold;
}

tr:nth-child(even) {
    background: #fafafa;
}

.total-row {
    background: var(--total-bg);
    font-weight: bold;
    color: #2e7d32;
}

.scheme-title {
    margin-top: 25px;
    font-size: 18px;
    font-weight: bold;
    color: var(--primary);
}

/* --- Winner Highlight --- */
.winner-section {
    background: linear-gradient(90deg, #fff9e6, #fff4c2);
    border: 2px solid gold;
    border-radius: 10px;
    padding: 10px;
    text-align: center;
    margin-bottom: 10px;
    font-weight: bold;
    color: #b8860b;
    display: flex;
    flex-direction: column;
    align-items: center;
    position: relative;
    overflow: hidden;
}

/* Sparkle animation (CSS only) */
.winner-section::after {
    content: "";
    position: absolute;
    top: -50%;
    left: -50%;
    width: 200%;
    height: 200%;
    background: radial-gradient(circle, rgba(255,215,0,0.4) 10%, transparent 10%) 0 0/50px 50px,
                radial-gradient(circle, rgba(255,255,255,0.6) 10%, transparent 10%) 25px 25px/50px 50px;
    animation: sparkle 3s linear infinite;
    opacity: 0.7;
    pointer-events: none;
}

@keyframes sparkle {
    0% { transform: translate(0, 0) rotate(0deg); }
    100% { transform: translate(25px, 25px) rotate(360deg); }
}

/* Glowing border for winning card table */
.winner-table {
    border: 2px solid gold !important;
    box-shadow: 0 0 15px rgba(255,215,0,0.6);
    animation: pulse 2s infinite;
}

@keyframes pulse {
    0% { box-shadow: 0 0 5px rgba(255,215,0,0.5); }
    50% { box-shadow: 0 0 20px rgba(255,215,0,0.9); }
    100% { box-shadow: 0 0 5px rgba(255,215,0,0.5); }
}

/* 🏆 Trophy styling beside card number */
.trophy {
    color: gold;
    margin-left: 6px;
    font-size: 1.1em;
    vertical-align: middle;
    display: inline-block;
    animation: shine 3s ease-in-out infinite;
}

/* ✨ Shine animation for trophy */
@keyframes shine {
    0%, 100% { text-shadow: 0 0 4px rgba(255,215,0,0.5), 0 0 8px rgba(255,223,0,0.3); }
    50% { text-shadow: 0 0 12px rgba(255,223,0,0.9), 0 0 20px rgba(255,255,0,0.7); }
}

@media (max-width: 768px) {
    .container { padding: 18px; border-radius: 10px; }
    th, td { font-size: 14px; padding: 8px 10px; }
    .scheme-title { font-size: 16px; }
}
</style>
</head>
<body>
<div class="container">

    <?php include 'mem_nav.php'; ?>
      
    <img src="logo.webp" alt="ABS Dream India Logo" 
     style="width:180px; height:auto; max-width:100%; display:block; margin:0 auto;">

    
    
    <h1>Member Receipts</h1>

    <?php
    if (empty($tables)) {
        echo "<p>No active schemes found.</p>";
    } else {
        foreach ($tables as $tbl) {
            $schemeName = $tbl['scheme_name'];
            $receiptTable = $tbl['receipt_table'];
            $schemeTable = $tbl['scheme_table'];

            $check = $conn->query("SHOW TABLES LIKE '$receiptTable'");
            if ($check && $check->num_rows > 0) {
                $sqlCard = "SELECT DISTINCT Scheme_Card_Number FROM $receiptTable WHERE Mobile_Number = ?";
                $stmtCard = $conn->prepare($sqlCard);
                if ($stmtCard) {
                    $stmtCard->bind_param("s", $username);
                    $stmtCard->execute();
                    $resCard = $stmtCard->get_result();

                    if ($resCard && $resCard->num_rows > 0) {
                        echo "<div class='scheme-title'>{$schemeName}</div>";

                        while ($cardRow = $resCard->fetch_assoc()) {
                            $cardNum = htmlspecialchars($cardRow['Scheme_Card_Number']);
                            $isWinner = false;

                            if (!empty($schemeTable)) {
                                $checkWin = $conn->prepare("SELECT Winning_Status FROM $schemeTable WHERE Scheme_Card_Number = ?");
                                if ($checkWin) {
                                    $checkWin->bind_param("s", $cardNum);
                                    $checkWin->execute();
                                    $resWin = $checkWin->get_result();
                                    if ($resWin && $resWin->num_rows > 0) {
                                        $winData = $resWin->fetch_assoc();
                                        if (strtoupper($winData['Winning_Status']) === 'WINNER') {
                                            $isWinner = true;
                                        }
                                    }
                                    $checkWin->close();
                                }
                            }

                            if ($isWinner) {
                                echo "<div class='winner-section'>
                                        🎉 Congratulations! You are a Winner! 🎉
                                      </div>";
                            }

                            $sqlRec = "SELECT Receipt_Number, Receipt_Amount, Receipt_Date 
                                       FROM $receiptTable 
                                       WHERE Mobile_Number = ? AND Scheme_Card_Number = ?";
                            $stmtRec = $conn->prepare($sqlRec);
                            if ($stmtRec) {
                                $stmtRec->bind_param("ss", $username, $cardNum);
                                $stmtRec->execute();
                                $resRec = $stmtRec->get_result();

                                if ($resRec && $resRec->num_rows > 0) {
                                    $tableClass = $isWinner ? 'table-container winner-table' : 'table-container';
                                    echo "<div class='{$tableClass}'>";
                                    echo "<table>";
                                    
                                    // 🏆 Trophy beside winning card
                                    $cardTitle = $isWinner ? "Scheme Card: {$cardNum} <span class='trophy'>🏆</span>" : "Scheme Card: {$cardNum}";
                                    echo "<tr><th colspan='4'>{$cardTitle}</th></tr>";

                                    echo "<tr><th>Sl. No</th><th>Receipt Number</th><th>Receipt Amount</th><th>Receipt Date</th></tr>";

                                    $sl = 1;
                                    $total = 0;
                                    while ($r = $resRec->fetch_assoc()) {
                                        $receiptNo = htmlspecialchars($r['Receipt_Number']);
                                        $receiptAmt = htmlspecialchars($r['Receipt_Amount']);
                                        $receiptDate = htmlspecialchars(
                                            ($r['Receipt_Date'] && $r['Receipt_Date'] !== '0000-00-00')
                                                ? date("d-m-Y", strtotime($r['Receipt_Date']))
                                                : '-'
                                        );
                                        $total += $r['Receipt_Amount'];

                                        echo "<tr>
                                                <td>{$sl}</td>
                                                <td>{$receiptNo}</td>
                                                <td>₹{$receiptAmt}</td>
                                                <td>{$receiptDate}</td>
                                              </tr>";
                                        $sl++;
                                    }
                                    echo "<tr class='total-row'>
                                            <td colspan='2'>Total</td>
                                            <td colspan='2'>₹" . number_format($total, 2) . "</td>
                                          </tr>";
                                    echo "</table></div>";
                                }
                                $stmtRec->close();
                            }
                        }
                    }
                    $stmtCard->close();
                }
            }
        }
    }
    $conn->close();
    ?>

</div>
</body>
</html>
