<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit();
}
?>

<style>
/* ========== GENERAL STYLES ========== */
.navbar {
    background-color: #222;
    color: #fff;
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 10px 15px;
    border-radius: 8px;
    flex-wrap: wrap;
    margin-bottom: 20px;
    position: relative;
    z-index: 1000;
}

.navbar-left, .navbar-right {
    display: flex;
    align-items: center;
    gap: 15px;
}

.navbar a {
    color: #fff;
    text-decoration: none;
    font-weight: bold;
    font-size: 16px;
    padding: 6px 10px;
    border-radius: 5px;
    transition: background 0.3s;
    display: flex;
    align-items: center;
    gap: 8px;
}

.navbar a:hover {
    background-color: #444;
}

/* ========== ICON STYLES ========== */
.navbar a i {
    font-size: 18px;
}

/* ========== HAMBURGER ICON ========== */
.hamburger {
    display: none;
    flex-direction: column;
    justify-content: center;
    align-items: center;
    cursor: pointer;
    width: 36px;
    height: 32px;
    position: absolute;
    right: 15px;
    top: 12px;
    z-index: 3000;

    /* 🔹 Blue background */
    background: #00bfff;
    border-radius: 8px;
    padding: 5px;
    box-shadow: 0 0 6px rgba(0, 191, 255, 0.6);
}

/* 🔹 Blue hamburger lines */
.hamburger div {
    height: 3px;
    width: 100%;
    background: #fff;
    margin: 4px 0;
    border-radius: 2px;
    transition: 0.3s;
}

.hamburger.active div:nth-child(1) {
    transform: rotate(45deg) translate(5px, 5px);
}
.hamburger.active div:nth-child(2) {
    opacity: 0;
}
.hamburger.active div:nth-child(3) {
    transform: rotate(-45deg) translate(6px, -6px);
}

/* ========== MOBILE FIX ========== */
@media (max-width: 768px) {
    .hamburger {
        display: flex;
    }

    .navbar {
        flex-direction: column;
        align-items: flex-start;
    }

    .navbar-left, .navbar-right {
        display: flex;
        flex-direction: column;
        gap: 10px;
        width: 100%;
        background: #222;
        border-radius: 8px;
        padding: 0;
        max-height: 0;
        overflow: hidden;
        opacity: 0;
        transform: translateY(-10px);
        transition: all 0.3s ease-in-out;
    }

    .navbar-left.active, .navbar-right.active {
        padding: 10px 0;
        max-height: 800px;
        opacity: 1;
        transform: translateY(0);
    }
}
</style>

<!-- ✅ NAVBAR HTML -->
<div class="navbar">
    <div class="hamburger" id="hamburger">
        <div></div>
        <div></div>
        <div></div>
    </div>

    <div class="navbar-left" id="navLeft">
        <a href="mem_Dashboard.php"><i class="fa-solid fa-house"></i> Home</a>
        <a href="mem_scheme.php"><i class="fa-solid fa-clipboard-list"></i> Schemes Details</a>
        <a href="mem_receipts.php"><i class="fa-solid fa-file-invoice"></i> Receipts Details</a>
    </div>

    <div class="navbar-right" id="navRight">
        <a href="logout.php"><i class="fa-solid fa-right-from-bracket"></i> Logout</a>
    </div>
</div>

<!-- ✅ FONT AWESOME 6 CDN (works without kit) -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">

<!-- ✅ TOGGLE SCRIPT -->
<script>
const hamburger = document.getElementById('hamburger');
const navLeft = document.getElementById('navLeft');
const navRight = document.getElementById('navRight');

hamburger.addEventListener('click', () => {
    hamburger.classList.toggle('active');
    navLeft.classList.toggle('active');
    navRight.classList.toggle('active');
});

// Close after clicking a link on mobile
document.querySelectorAll('.navbar a').forEach(link => {
    link.addEventListener('click', () => {
        if (window.innerWidth <= 768) {
            hamburger.classList.remove('active');
            navLeft.classList.remove('active');
            navRight.classList.remove('active');
        }
    });
});
</script>
