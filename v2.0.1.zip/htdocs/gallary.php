<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title>ABS Dream India Group</title>
	<link rel="icon" href="img/6-1024x492.webp">
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="" name="keywords">
    <meta content="" name="description">

    <!-- Favicon -->
    <link href="img/favicon.ico" rel="icon">

    <!-- Google Web Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Open+Sans&family=Space+Grotesk&display=swap" rel="stylesheet">

    <!-- Icon Font Stylesheet -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.1/font/bootstrap-icons.css" rel="stylesheet">

    <!-- Libraries Stylesheet -->
    <link href="lib/animate/animate.min.css" rel="stylesheet">
    <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">

    <!-- Customized Bootstrap Stylesheet -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- Template Stylesheet -->
    <link href="css/style.css" rel="stylesheet">
	<style>
    .lang-kn { display: none; } /* Default: show English */
    .lang-switch {
      position: fixed;
      top: 10px;
      right: 15px;
      background: #0056b3;
      color: white;
      padding: 6px 10px;
      border-radius: 5px;
      cursor: pointer;
      font-weight: 600;
    }
	</style>
</head>

<body>
    <!-- Spinner Start -->
    <!--<div id="spinner"
        class="show bg-white position-fixed translate-middle w-100 vh-100 top-50 start-50 d-flex align-items-center justify-content-center">
        <div class="spinner-grow text-primary" style="width: 3rem; height: 3rem;" role="status">
            <span class="sr-only">Loading...</span>
        </div>
    </div>-->
    <!-- Spinner End -->


   <!-- Navbar Start -->
    <div class="container-fluid sticky-top">
        <div class="container">
            <nav class="navbar navbar-expand-lg navbar-light border-bottom border-2 border-white">
                <a href="index.html" class="navbar-brand">
                    <h1><img src="img/6-1024x492.webp" alt="ABS Logo" class="img-fluid" style="height: 50px;"></h1>
                </a>
                <button type="button" class="navbar-toggler ms-auto me-0" data-bs-toggle="collapse"
                    data-bs-target="#navbarCollapse">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarCollapse">
                    <div class="navbar-nav ms-auto">
					<div class="lang-switch" onclick="toggleLanguage()">E / ಕ</div>
						<a href="index.html" class="nav-item nav-link active">
							<span class="lang-en">Home</span>
							<span class="lang-kn">ಮುಖಪುಟ</span>
						</a>

						<a href="about.html" class="nav-item nav-link">
							<span class="lang-en">About</span>
							<span class="lang-kn">ನಮ್ಮ ಬಗ್ಗೆ</span>
						</a>

						<a href="service.html" class="nav-item nav-link">
							<span class="lang-en">Services</span>
							<span class="lang-kn">ಸೇವೆಗಳು</span>
						</a>

						<!-- <a href="project.html" class="nav-item nav-link">
							<span class="lang-en">Projects</span>
							<span class="lang-kn">ಯೋಜನೆಗಳು</span>
						</a> -->

						<div class="nav-item dropdown">
							<a href="#" class="nav-link dropdown-toggle" data-bs-toggle="dropdown">
								<span class="lang-en">Projects</span>
								<span class="lang-kn">ಯೋಜನೆಗಳು</span>
							</a>
							<div class="dropdown-menu bg-light mt-2">
								<a href="absgs.html" class="dropdown-item">
									<span class="lang-en">ABS Gold Scheme</span>
									<span class="lang-kn">ABS ಚಿನ್ನದ  ಯೋಜನೆ</span>
								</a>
								<!-- <a href="team.html" class="dropdown-item">
									<span class="lang-en">Our Team</span>
									<span class="lang-kn">ನಮ್ಮ ತಂಡ</span>
								</a>
								<a href="testimonial.html" class="dropdown-item">
									<span class="lang-en">Testimonial</span>
									<span class="lang-kn">ಪ್ರಶಂಸಾಪತ್ರ</span>
								</a>
								<a href="404.html" class="dropdown-item">
									<span class="lang-en">404 Page</span>
									<span class="lang-kn">404 ಪುಟ</span>
								</a> -->
							</div>
						</div>

						<a href="contact.html" class="nav-item nav-link">
							<span class="lang-en">Contact</span>
							<span class="lang-kn">ಸಂಪರ್ಕಿಸಿ</span>
						</a>
						<a href="gallary.php" class="nav-item nav-link">
							<span class="lang-en">Photo Gallary</span>
							<span class="lang-kn">ಚಿತ್ರಸಂಪುಟ</span>
						</a>

						<a href="login.php" class="nav-item nav-link">
							<span class="lang-en">Login</span>
							<span class="lang-kn">ಪ್ರವೇಶ ಪುಟ</span>
						</a>
						
                    </div>
                </div>
            </nav>
        </div>
    </div>
    <!-- Navbar End -->


    <!-- Hero Start -->
    <div class="container-fluid pb-5 bg-primary hero-header">
        <div class="container py-5">
            <div class="row g-3 align-items-center">
                <div class="col-lg-6 text-center text-lg-start">
                    <h1 class="display-1 mb-0 animated slideInLeft">
						<span class="lang-en">Photo Gallary</span>
						<span class="lang-kn">ಚಿತ್ರಸಂಪುಟ</span>
					</h1>

                </div>
                <div class="col-lg-6 animated slideInRight">
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb justify-content-center justify-content-lg-end mb-0">
                            <li class="breadcrumb-item">
								<a class="text-primary" href="#">
									<span class="lang-en">Home</span>
									<span class="lang-kn">ಮುಖಪುಟ</span>
								</a>
							</li>
							<li class="breadcrumb-item">
								<a class="text-primary" href="#">
									<span class="lang-en">Pages</span>
									<span class="lang-kn">ಪುಟಗಳು</span>
								</a>
							</li>
							<li class="breadcrumb-item text-secondary active" aria-current="page">
								<span class="lang-en">Photo Gallary</span>
								<span class="lang-kn">ಚಿತ್ರಸಂಪುಟ</span>
							</li>

                        </ol>
                    </nav>
                </div>
            </div>
        </div>
    </div>
    <!-- Hero End -->

	<!-- Gallary Start -->
	<div class="container-fluid py-5" style="display:flex; justify-content:center; align-items:center;flex-direction: column;">
		<div class="col-lg-6">
                    <div class="owl-carousel header-carousel animated fadeIn">
    					<?php
        				$dir = "giftimgs/"; // your folder name
        				$images = glob($dir . "*.{jpg,jpeg,png,webp,gif}", GLOB_BRACE);
        				if (!empty($images)) {
            				foreach ($images as $image) {
                			echo '<img class="img-fluid" src="' . $image . '" alt="">';
            				}
        				} else {
            				echo '<p style="text-align:center; color:#555;">No images found in gallery.</p>';
        				}
    					?>
					</div>
                </div>
	</div>
	<!-- Gallary End -->

    <!-- Footer Start -->
    <div class="container-fluid bg-dark text-white-50 footer pt-5">
        <div class="container py-5">
            <div class="row g-5">
                <div class="col-md-6 col-lg-3 wow fadeIn" data-wow-delay="0.1s">
                    <a href="index.html" class="d-inline-block mb-3">
                        <h1 class="text-white"><img src="img/6-1024x492.webp" alt="ABS Logo" class="img-fluid" style="height: 70px;"></h1>
                    </a>
                    <p class="mb-4">
						<span class="lang-en">Your trusted partner for a wide range of business services, all under one roof.</span>
						<span class="lang-kn">ನಿಮಗೆ ಅಗತ್ಯವಿರುವ ಎಲ್ಲಾ ಸೇವೆಗಳನ್ನು ಒಂದೇ ವೇದಿಕೆಯಲ್ಲಿ ಪಡೆಯಬಹುದಾಗಿದೆ..</span>
					</p>

                    <!-- <a class="btn btn-primary border-2 px-4" href="https://htmlcodex.com/downloading/?item=3587">Buy Pro Version</a> -->
                </div>
                <div class="col-md-6 col-lg-3 wow fadeIn" data-wow-delay="0.3s">
                    <h5 class="text-white mb-4">
						<span class="lang-en">Get In Touch</span>
						<span class="lang-kn">ಸಂಪರ್ಕಿಸಿ</span>
					</h5>

                    <p>
						<i class="fa fa-map-marker-alt me-3"></i>
						<span class="lang-en">74, Thirula, B C M Office opposite Kotturu Road, Hagaribommanahalli, Vijayanagar District – 583212</span>
						<span class="lang-kn">74, ಥಿರುಲಾ, ಬಿ ಸಿ ಎಂ ಕಚೇರಿ ಎದುರುಗಡೆ, ಕೊಟ್ಟೂರು ರಸ್ತೆ, ಹಗರಿಬೊಮ್ಮನಹಳ್ಳಿ, ವಿಜಯನಗರ ಜಿಲ್ಲೆ – 583212</span>
					</p>

                    <p><i class="fa fa-phone-alt me-3"></i>+91 89706 88749</p>
                    <p><i class="fa fa-envelope me-3"></i>support@absdreamindiagroups.com<br>absdreamindiagroups1@gmail.com</p>
                    <div class="d-flex pt-2">
                        <!-- <a class="btn btn-outline-primary btn-square border-2 me-2" href=""><i class="fab fa-twitter"></i></a>
                        <a class="btn btn-outline-primary btn-square border-2 me-2" href=""><i class="fab fa-facebook-f"></i></a> -->
                        <a class="btn btn-outline-primary btn-square border-2 me-2" href="https://www.youtube.com/@ABSDreamIndiaGroups"><i class="fab fa-youtube"></i></a>
                        <a class="btn btn-outline-primary btn-square border-2 me-2" href="https://www.instagram.com/absdreamindiagroups/"><i class="fab fa-instagram"></i></a>
						<a class="btn btn-outline-primary btn-square border-2 me-2" href="http://wa.me/+918970688749"><i class="fab fa-whatsapp"></i></a>
                        <!-- <a class="btn btn-outline-primary btn-square border-2 me-2" href=""><i class="fab fa-linkedin-in"></i></a> -->
                    </div>
                </div>
                <div class="col-md-6 col-lg-3 wow fadeIn" data-wow-delay="0.5s">
                    <h5 class="text-white mb-4">
						<span class="lang-en">Popular Link</span>
						<span class="lang-kn">ಪ್ರಚಲಿತ ಲಿಂಕ್</span>
					</h5>
					<a class="btn btn-link" href="index.html">
						<span class="lang-en">Home</span>
						<span class="lang-kn">ಮುಖಪುಟ</span>
					</a>
					<a class="btn btn-link" href="about.html">
						<span class="lang-en">About Us</span>
						<span class="lang-kn">ನಮ್ಮ ಬಗ್ಗೆ</span>
					</a>
					<a class="btn btn-link" href="service.html">
						<span class="lang-en">Services</span>
						<span class="lang-kn">ಸೇವೆಗಳು</span>
					</a>
					<a class="btn btn-link" href="contact.html">
						<span class="lang-en">Contact Us</span>
						<span class="lang-kn">ಸಂಪರ್ಕಿಸಿ</span>
					</a>
					
                    <!-- <a class="btn btn-link" href="">Terms & Condition</a>
                    <a class="btn btn-link" href="">Career</a> -->
                </div>
                <div class="col-md-6 col-lg-3 wow fadeIn" data-wow-delay="0.7s">
                    <h5 class="text-white mb-4">
						<span class="lang-en">Our Projects</span>
						<span class="lang-kn">ನಮ್ಮ ಯೋಜನೆಗಳು</span>
					</h5>
                    <a class="btn btn-link" href="">
						<span class="lang-en">ABS Gold Scheme</span>
						<span class="lang-kn">ABS ಚಿನ್ನದ  ಯೋಜನೆ</span>
					</a>

                    <!-- <a class="btn btn-link" href="">Project Planning</a>
                    <a class="btn btn-link" href="">Renovation</a>
                    <a class="btn btn-link" href="">Implement</a>
                    <a class="btn btn-link" href="">Landscape Design</a> -->
                </div>
            </div>
        </div>
        <div class="container wow fadeIn" data-wow-delay="0.1s">
            <div class="copyright">
                <div class="row">
                    <div class="col-md-6 text-center text-md-start mb-3 mb-md-0">
                        &copy; <a class="border-bottom" href="#">ABS Dream India Group</a>, All Right Reserved.

                        <!--/*** The author’s attribution link must remain intact in the template. ***/-->
                        <!--/*** If you wish to remove this credit link, please purchase the Pro Version . ***/-->
                        Designed By <a class="border-bottom" href="https://htmlcodex.com">HTML Codex</a>
                    </div>
                    <div class="col-md-6 text-center text-md-end">
                        <div class="footer-menu">
                            <a href="">Home</a>
                            <!-- a href="">Cookies</a>
                            <a href="">Help</a>
                            <a href="">FAQs</a> -->
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Footer End -->


    <!-- Back to Top -->
    <a href="#" class="btn btn-lg btn-primary btn-lg-square back-to-top"><i class="bi bi-arrow-up"></i></a>


    <!-- JavaScript Libraries -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.1/jquery.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="lib/wow/wow.min.js"></script>
    <script src="lib/easing/easing.min.js"></script>
    <script src="lib/waypoints/waypoints.min.js"></script>
    <script src="lib/owlcarousel/owl.carousel.min.js"></script>

    <!-- Template Javascript -->
    <script src="js/main.js"></script>
	<script>
    let currentLang = "en";
    function toggleLanguage() {
      if (currentLang === "en") {
        document.querySelectorAll(".lang-en").forEach(e => e.style.display = "none");
        document.querySelectorAll(".lang-kn").forEach(e => e.style.display = "inline");
        currentLang = "kn";
      } else {
        document.querySelectorAll(".lang-en").forEach(e => e.style.display = "inline");
        document.querySelectorAll(".lang-kn").forEach(e => e.style.display = "none");
        currentLang = "en";
      }
    }
  </script>
</body>

</html>