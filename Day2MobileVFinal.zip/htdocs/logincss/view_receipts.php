<?php
session_start();
if (!isset($_SESSION['username'])) {
    header("Location: ../login.php");
    exit();
}

include '../config.php';
$username = $_SESSION['username'];

// Fetch active schemes
$schemes = [];
$query = "SELECT Scheme_Name, scheme_table_name, receipt_table_name 
          FROM ABC_Schemes_Details 
          WHERE Status='ACTIVE' 
          ORDER BY Scheme_Name";
$res = $conn->query($query);
if ($res->num_rows > 0) {
    while ($row = $res->fetch_assoc()) {
        $schemes[] = $row;
    }
}

$member = null;
$receipts = [];
$message = "";
$totalPaid = 0;
$createdBy = "";

// Handle search
if (isset($_POST['search'])) {
    $criteria = $_POST['criteria'];
    $value = trim($_POST['value']);
    $scheme = $_POST['scheme'];
    $schemeTable = "";
    $receiptTable = "";

    foreach ($schemes as $s) {
        if ($s['Scheme_Name'] == $scheme) {
            $schemeTable = $s['scheme_table_name'];
            $receiptTable = $s['receipt_table_name'];
            break;
        }
    }

    if (!empty($schemeTable) && !empty($receiptTable) && !empty($criteria) && !empty($value)) {
        // Fetch member details
        $stmt = $conn->prepare("SELECT Scheme_Card_Number, Aadhar_Number, Full_Name, Parent_Name, Mobile_Number, Date_Of_Birth,
                                       House_No, Address, Place, Taluk, District, Pincode, Winning_Status
                                FROM $schemeTable WHERE $criteria = ?");
        $stmt->bind_param("s", $value);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            $member = $result->fetch_assoc();

            // Fetch receipts
            $cardNo = $member['Scheme_Card_Number'];
            $stmt2 = $conn->prepare("SELECT Receipt_Number, Receipt_Amount, Receipt_Date, Created_By 
                                     FROM $receiptTable 
                                     WHERE Scheme_Card_Number = ?
                                     ORDER BY Receipt_Date DESC");
            $stmt2->bind_param("s", $cardNo);
            $stmt2->execute();
            $res2 = $stmt2->get_result();

            if ($res2->num_rows > 0) {
                while ($row = $res2->fetch_assoc()) {
                    $receipts[] = $row;
                    $totalPaid += $row['Receipt_Amount'];
                    $createdBy = $row['Created_By'];
                }
            } else {
                $message = "⚠️ No receipts found for this member.";
            }
        } else {
            $message = "❌ No record found for given search criteria.";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>View Receipts</title>
<style>
body {
    font-family: Arial, sans-serif;
    background: #f5f5f5;
    margin: 0;
    padding: 20px;
}
.container {
    background: #fff;
    border-radius: 12px;
    box-shadow: 0 0 8px rgba(0,0,0,0.2);
    max-width: 900px;
    margin: auto;
    padding: 25px;
    position: relative;
    overflow-y: auto;
}
.container::before {
    content: "";
    position: absolute;
    top: 50%; left: 50%;
    width: 180px; height: 180px;
    /*background: url('logo.webp') no-repeat center center;*/
    background-size: contain;
    opacity: 0.25;
    transform: translate(-50%, -50%);
    z-index: 0;
}
.container > * { position: relative; z-index: 1; }

h2 { text-align: center; margin-top: 0; }

.search-section {
    background: #eee;
    border: 1px solid #ccc;
    border-radius: 10px;
    padding: 15px 20px;
    margin-bottom: 25px;
}
.search-title {
    background: #ddd;
    padding: 8px 12px;
    font-weight: bold;
    border-radius: 6px;
    margin-bottom: 15px;
}
.search-grid {
    display: grid;
    grid-template-columns: repeat(2, 1fr);
    gap: 15px;
}
label {
    font-weight: bold;
    display: block;
    margin-bottom: 5px;
}
select, input[type="text"] {
    width: 100%;
    padding: 8px;
    border: 1px solid #bbb;
    border-radius: 6px;
    box-sizing: border-box;
}
button {
    border: none;
    padding: 10px 15px;
    border-radius: 6px;
    font-weight: bold;
    cursor: pointer;
}
.btn-search {
    background: #28a745;
    color: #fff;
}
.btn-search:hover { background: #218838; }
.btn-clear {
    background: #dc3545;
    color: #fff;
}
.btn-clear:hover { background: #c82333; }

.details {
    background: #fafafa;
    border: 1px solid #ddd;
    border-radius: 8px;
    padding: 15px;
    margin-bottom: 20px;
}
.details-grid {
    display: grid;
    grid-template-columns: repeat(2, 1fr);
    gap: 20px;
}
.details table {
    width: 100%;
    border-collapse: collapse;
}
.details td {
    padding: 6px 10px;
    border-bottom: 1px solid #eee;
}

/* ✅ Added responsive wrapper for receipts table */
.receipts {
    background: #fafafa;
    border: 1px solid #ddd;
    border-radius: 8px;
    padding: 15px;
    overflow-x: auto; /* 👈 Makes the table scrollable horizontally */
}
.receipts table {
    width: 100%;
    border-collapse: collapse;
    min-width: 600px; /* 👈 Prevents columns from shrinking too much */
}
.receipts th, .receipts td {
    padding: 6px 10px;
    border-bottom: 1px solid #eee;
    white-space: nowrap; /* 👈 Keeps text in one line */
}
.receipts th {
    background: #ddd;
    text-align: left;
}
.status-badge {
    padding: 5px 10px;
    border-radius: 5px;
    font-weight: bold;
    color: #fff;
}
.status-runner { background: #ffcc00; color: #000; }
.status-winner { background: #28a745; }

.message {
    text-align: center;
    font-weight: bold;
    margin-top: 10px;
}
.message.success { color: green; }
.message.error { color: red; }

@media (max-width: 768px) {
    .search-grid { grid-template-columns: 1fr; }
    .details-grid { grid-template-columns: 1fr; }
    /* ✅ Ensure scroll works nicely on mobile */
    .receipts { padding-bottom: 10px; }
}
</style>
<script>
function clearForm() {
    window.location.href = "view_receipts.php";
}
</script>
</head>
<body>
<div class="container">

    <?php include 'nav.php'; ?>

    <h2>View Receipts</h2>

    <form method="post" class="search-section">
        <div class="search-title">🔍 Search Member</div>
        <div class="search-grid">
            <div>
                <label for="criteria">Search By:</label>
                <select name="criteria" required>
                    <option value="">Select</option>
                    <option value="Aadhar_Number" <?= (isset($_POST['criteria']) && $_POST['criteria']=='Aadhar_Number') ? 'selected' : ''; ?>>Aadhar Number</option>
                    <option value="Mobile_Number" <?= (isset($_POST['criteria']) && $_POST['criteria']=='Mobile_Number') ? 'selected' : ''; ?>>Mobile Number</option>
                    <option value="Scheme_Card_Number" <?= (isset($_POST['criteria']) && $_POST['criteria']=='Scheme_Card_Number') ? 'selected' : ''; ?>>Member Card Number</option>
                </select>
            </div>
            <div>
                <label for="scheme">Select Scheme:</label>
                <select name="scheme" required>
                    <option value="">Select</option>
                    <?php foreach ($schemes as $scheme) { ?>
                        <option value="<?= htmlspecialchars($scheme['Scheme_Name']); ?>" 
                            <?= (isset($_POST['scheme']) && $_POST['scheme']==$scheme['Scheme_Name']) ? 'selected' : ''; ?>>
                            <?= htmlspecialchars($scheme['Scheme_Name']); ?>
                        </option>
                    <?php } ?>
                </select>
            </div>
            <div>
                <label for="value">Enter Value:</label>
                <input type="text" name="value" value="<?= htmlspecialchars($_POST['value'] ?? ''); ?>" required>
            </div>
            <div style="display:flex; gap:10px; align-items:center; margin-top:25px;">
                <button type="submit" name="search" class="btn-search">Search</button>
                <button type="button" class="btn-clear" onclick="clearForm()">Clear</button>
            </div>
        </div>
    </form>

    <?php if ($message): ?>
        <div class="message <?= strpos($message, '✅') !== false ? 'success' : 'error'; ?>">
            <?= $message; ?>
        </div>
    <?php endif; ?>

    <?php if ($member): ?>
    <div class="details">
        <h3>Member Details</h3>
        <div class="details-grid">
            <table>
                <tr><td><strong>Scheme Card No:</strong></td><td><?= htmlspecialchars($member['Scheme_Card_Number']); ?></td></tr>
                <tr><td><strong>Aadhar No:</strong></td><td><?= htmlspecialchars($member['Aadhar_Number']); ?></td></tr>
                <tr><td><strong>Full Name:</strong></td><td><?= htmlspecialchars($member['Full_Name']); ?></td></tr>
                <tr><td><strong>Parent Name:</strong></td><td><?= htmlspecialchars($member['Parent_Name']); ?></td></tr>
                <tr><td><strong>Mobile:</strong></td><td><?= htmlspecialchars($member['Mobile_Number']); ?></td></tr>
                <tr><td><strong>Date of Birth:</strong></td><td><?= htmlspecialchars($member['Date_Of_Birth']); ?></td></tr>
            </table>
            <table>
                <tr><td><strong>Address:</strong></td><td><?= htmlspecialchars($member['Address']); ?></td></tr>
                <tr><td><strong>Taluk:</strong></td><td><?= htmlspecialchars($member['Taluk']); ?></td></tr>
                <tr><td><strong>District:</strong></td><td><?= htmlspecialchars($member['District']); ?></td></tr>
                <tr><td><strong>Pincode:</strong></td><td><?= htmlspecialchars($member['Pincode']); ?></td></tr>
                <tr>
                    <td><strong>Winning Status:</strong></td>
                    <td>
                        <?php
                            $status = htmlspecialchars($member['Winning_Status']);
                            $class = $status == 'WINNER' ? 'status-winner' : ($status == 'RUNNER' ? 'status-runner' : '');
                            echo "<span class='status-badge $class'>$status</span>";
                        ?>
                    </td>
                </tr>
            </table>
        </div>
    </div>

    <?php if (!empty($receipts)): ?>
    <div class="receipts">
        <h3>Receipt Details</h3>
        <table>
            <tr>
                <th>Receipt No</th>
                <th>Receipt Amount</th>
                <th>Receipt Date</th>
                <th>Created By</th>
            </tr>
            <?php foreach ($receipts as $r): ?>
                <tr>
                    <td><?= htmlspecialchars($r['Receipt_Number']); ?></td>
                    <td><?= htmlspecialchars($r['Receipt_Amount']); ?></td>
                    <td><?= htmlspecialchars($r['Receipt_Date']); ?></td>
                    <td><?= htmlspecialchars($r['Created_By']); ?></td>
                </tr>
            <?php endforeach; ?>
            <tr style="font-weight:bold;background:#f0f0f0;">
                <td style="text-align:left;">Total Amount Paid:</td>
                <td><?= htmlspecialchars($totalPaid); ?></td>
                <td></td>
                <td></td>
            </tr>
        </table>
    </div>
    <?php endif; ?>
    <?php endif; ?>

</div>
</body>
</html>
