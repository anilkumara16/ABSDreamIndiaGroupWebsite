<?php
session_start();
if (!isset($_SESSION['username'])) {
    header("Location: ../login.php");
    exit();
}

include '../config.php';

/* =======================
   EXPORT CSV (ALL DATA)
======================= */
if (isset($_GET['export']) && $_GET['export'] == 'csv') {

    header('Content-Type: text/csv');
    header('Content-Disposition: attachment; filename=All_Referrals_' . date('Ymd_His') . '.csv');

    $output = fopen("php://output", "w");

    fputcsv($output, ['Sl No','Referrer ID','Referrer Name','Name','Mobile','Email','PAN','Aadhaar','Date']);

   	$sql = "SELECT referrer_id, referrer_name,
               referred_name, referred_mobile, referred_email,
               pan_card, aadhaar_number, created_at
        FROM ABS_Referral_Details
        ORDER BY created_at DESC";

    $res = $conn->query($sql);
    $sl = 1;

    while ($row = $res->fetch_assoc()) {
        $masked = "XXXXXX" . substr($row['aadhaar_number'], -4);

        fputcsv($output, [
    		$sl++,
    		$row['referrer_id'],
    		$row['referrer_name'],
    		$row['referred_name'],
            $row['referred_mobile'],
            $row['referred_email'],
            $row['pan_card'],
            $masked,
            date("d-m-Y", strtotime($row['created_at']))
        ]);
    }

    fclose($output);
    exit();
}

/* =======================
   PAGINATION
======================= */
$limit = 10;
$page  = isset($_GET['page']) ? (int)$_GET['page'] : 1;
if ($page < 1) $page = 1;

$offset = ($page - 1) * $limit;

/* =======================
   TOTAL COUNT
======================= */
$countQuery = "SELECT COUNT(*) AS total FROM ABS_Referral_Details";
$countRes   = $conn->query($countQuery);
$totalRows  = $countRes->fetch_assoc()['total'];
$totalPages = ceil($totalRows / $limit);

/* =======================
   FETCH PAGINATED DATA
======================= */
$stmt = $conn->prepare("
    SELECT referrer_id, referrer_name,
           referred_name, referred_mobile, referred_email,
           pan_card, aadhaar_number, created_at
    FROM ABS_Referral_Details
    ORDER BY created_at DESC
    LIMIT ?, ?
");
$stmt->bind_param("ii", $offset, $limit);
$stmt->execute();
$result = $stmt->get_result();
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>View Referrals</title>

<style>
body {
    font-family: Arial, sans-serif;
    background: #f5f5f5;
    margin: 0;
    padding: 20px;
}
.container {
    background: #fff;
    border-radius: 12px;
    box-shadow: 0 0 8px rgba(0,0,0,0.2);
    max-width: 900px;
    margin: auto;
    padding: 25px;
}
h2 { text-align:center; margin-top:0; }

/* Top Summary Section */
.summary {
    background:#eee;
    border:1px solid #ccc;
    border-radius:10px;
    padding:15px 20px;
    margin-bottom:20px;
    display:flex;
    justify-content:space-between;
    align-items:center;
}
.count-box {
    font-weight:bold;
    font-size:16px;
}
.export-btn {
    background:#28a745;
    color:#fff;
    padding:8px 14px;
    border-radius:6px;
    text-decoration:none;
}
.export-btn:hover { background:#218838; }

/* Table */
.table-box {
    background:#fafafa;
    border:1px solid #ddd;
    border-radius:8px;
    padding:15px;
    overflow-x:auto;
}
table {
    width:100%;
    border-collapse:collapse;
    min-width:900px;
}
th, td {
    padding:8px 10px;
    border-bottom:1px solid #eee;
    text-align:left;
}
th { background:#ddd; }

/* Pagination */
.pagination {
    margin-top:20px;
    text-align:center;
}
.pagination a {
    padding:6px 10px;
    margin:2px;
    border-radius:4px;
    text-decoration:none;
    background:#eee;
    color:#000;
}
.pagination a.active {
    background:#28a745;
    color:#fff;
}

/* Mobile */
@media (max-width:768px){
    .summary { flex-direction:column; gap:10px; align-items:flex-start; }
}
</style>
</head>

<body>
<div class="container">

<?php include 'nav.php'; ?>

<img src="logo.webp" alt="Logo"
style="width:180px; display:block; margin:0 auto;">

<h2>View Referrals</h2>

<div class="summary">
    <div class="count-box">Total Referrals: <?= $totalRows; ?></div>
    <a href="?export=csv" class="export-btn">Export CSV</a>
</div>

<div class="table-box">
<table>
<tr>
<th>Sl No</th>
<th>Referrer ID</th>
<th>Referrer Name</th>
<th>Referred Name</th>
<th>Mobile</th>
<th>Email</th>
<th>PAN</th>
<th>Aadhaar</th>
<th>Date</th>
</tr>

<?php
$sl = $offset + 1;
while ($row = $result->fetch_assoc()):
$masked = "XXXXXX" . substr($row['aadhaar_number'], -4);
?>
<tr>
<td><?= $sl++; ?></td>
<td><?= htmlspecialchars($row['referrer_id']); ?></td>
<td><?= htmlspecialchars($row['referrer_name']); ?></td>
<td><?= htmlspecialchars($row['referred_name']); ?></td>
<td><?= htmlspecialchars($row['referred_mobile']); ?></td>
<td><?= htmlspecialchars($row['referred_email']); ?></td>
<td><?= htmlspecialchars($row['pan_card']); ?></td>
<td><?= $masked; ?></td>
<td><?= date("d-m-Y", strtotime($row['created_at'])); ?></td>
</tr>
<?php endwhile; ?>
</table>
</div>

<div class="pagination">
<?php for ($i=1;$i<=$totalPages;$i++): ?>
<a href="?page=<?= $i; ?>" class="<?= ($i==$page)?'active':''; ?>">
<?= $i; ?>
</a>
<?php endfor; ?>
</div>

</div>
</body>
</html>