<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
session_start();

if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit();
}

require_once "config.php"; // DB connection

$message = "";
$customer = null;
$created_by = $_SESSION['username'];
$schemes = [];

// 🔹 Preload active schemes
$schemeSQL = "SELECT id, Scheme_Name, scheme_table_name 
              FROM ABC_Schemes_Details 
              WHERE Status = 'ACTIVE' 
              ORDER BY Scheme_Name";
$schemeResult = $conn->query($schemeSQL);
if ($schemeResult && $schemeResult->num_rows > 0) {
    $schemes = $schemeResult->fetch_all(MYSQLI_ASSOC);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    // 🔹 Step 1: Search for Aadhar Number
    if (isset($_POST['search'])) {
        $aadhar = trim($_POST['aadhar']);

        // Validate Aadhar - must be 12 digits numeric only
        if (!preg_match('/^[0-9]{12}$/', $aadhar)) {
            $message = "⚠️ Aadhar Number must be exactly 12 digits!";
        } else {
            $sql = "SELECT * FROM ABS_customer_details WHERE Aadhar_Number = ?";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("s", $aadhar);
            $stmt->execute();
            $result = $stmt->get_result();
            $customer = $result->fetch_assoc();

            if (!$customer) {
                $message = "❌ Member not found!";
            }
        }
    }

    // 🔹 Step 2: Insert Gold Scheme Details
    if (isset($_POST['add_scheme'])) {
        $aadhar = $_POST['aadhar'];
        $scheme_no = trim($_POST['scheme_no']);
        $scheme_id = $_POST['scheme_id']; // scheme dropdown selection
        $created_at = date("Y-m-d H:i:s");

        // Validate Scheme Number
        if (!preg_match('/^[0-9]+$/', $scheme_no)) {
            $message = "⚠️ Scheme Card Number must contain only numbers!";
        } elseif (empty($scheme_id)) {
            $message = "⚠️ Please select a scheme!";
        } else {

            // 🔹 Fetch Scheme Details
            $schemeInfoSQL = "SELECT Scheme_Name, scheme_table_name 
                              FROM ABC_Schemes_Details 
                              WHERE id = ?";
            $stmtScheme = $conn->prepare($schemeInfoSQL);
            $stmtScheme->bind_param("i", $scheme_id);
            $stmtScheme->execute();
            $schemeInfo = $stmtScheme->get_result()->fetch_assoc();

            if (!$schemeInfo) {
                $message = "❌ Invalid scheme selected!";
            } else {
                $schemeName = $schemeInfo['Scheme_Name'];
                $schemeTable = $schemeInfo['scheme_table_name'];

                if (empty($schemeTable)) {
                    die("⚠️ Invalid scheme table name configured!");
                }

                // Check if Scheme_Card_Number already exists in that scheme table
                $checkSQL = "SELECT Scheme_Card_Number FROM $schemeTable WHERE Scheme_Card_Number = ?";
                $checkStmt = $conn->prepare($checkSQL);
                $checkStmt->bind_param("s", $scheme_no);
                $checkStmt->execute();
                $checkResult = $checkStmt->get_result();

                if ($checkResult->num_rows > 0) {
                    $message = "⚠️ Scheme Card Number already allotted to someone!";
                } else {
                    // Retrieve customer again
                    $sql = "SELECT * FROM ABS_customer_details WHERE Aadhar_Number = ?";
                    $stmt = $conn->prepare($sql);
                    $stmt->bind_param("s", $aadhar);
                    $stmt->execute();
                    $customer = $stmt->get_result()->fetch_assoc();

                    if ($customer) {
                        // ✅ Insert into scheme table (updated for your table structure)
                        $insertSQL = "INSERT INTO $schemeTable 
                        (Scheme_Card_Number, Aadhar_Number, Full_Name, Parent_Name, Mobile_Number, Date_Of_Birth,
                         House_No, Address, Place, Taluk, District, Pincode, Created_By, Created_At)
                        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

                        $stmt2 = $conn->prepare($insertSQL);
                        $stmt2->bind_param(
                            "isssssssssssss",
                            $scheme_no,
                            $customer['Aadhar_Number'],
                            $customer['Full_Name'],
                            $customer['Parent_Name'],
                            $customer['Mobile_Number'],
                            $customer['Date_of_Birth'],
                            $customer['House_No'],
                            $customer['Address'],
                            $customer['Place'],
                            $customer['Taluk'],
                            $customer['District'],
                            $customer['Pincode'],
                            $created_by,
                            $created_at
                        );
                        $stmt2->execute();

                        $message = "✅ Scheme details added successfully!";
                        $customer = null;
                    } else {
                        $message = "❌ Member not found!";
                    }
                }
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Add Gold Scheme</title>
<style>
:root {
    --bg: #f5f5f5;
    --card-bg: #fff;
    --text: #222;
    --primary: #000;
    --accent: #555;
    --border: #ccc;
}

body {
    font-family: Arial, sans-serif;
    background: var(--bg);
    color: var(--text);
    margin: 0;
    padding: 15px;
    display: flex;
    justify-content: center;
}

.container {
    background: var(--card-bg);
    border-radius: 12px;
    box-shadow: 0 0 10px rgba(0,0,0,0.15);
    max-width: 800px;
    width: 100%;
    padding: 25px;
    box-sizing: border-box;
    position: relative;
}

.message {
    background: #ffdddd;
    border-left: 5px solid #f44336;
    color: #333;
    padding: 10px;
    margin-bottom: 15px;
    border-radius: 5px;
    text-align: center;
    animation: fadeOut 4s ease-in-out forwards;
}
@keyframes fadeOut {
    0% {opacity: 1;}
    80% {opacity: 1;}
    100% {opacity: 0;}
}

form {
    display: flex;
    flex-direction: column;
    gap: 12px;
}

input[type="text"], select {
    padding: 10px;
    border: 1px solid var(--border);
    border-radius: 6px;
    width: 100%;
    box-sizing: border-box;
}

button {
    padding: 10px;
    background: var(--primary);
    color: white;
    border: none;
    border-radius: 6px;
    cursor: pointer;
}
button:hover {
    background: var(--accent);
}

.customer-details {
    margin-top: 20px;
    background: #fafafa;
    border: 1px solid var(--border);
    border-radius: 8px;
    padding: 15px;
}
.customer-details p {
    margin: 5px 0;
}

@media (max-width: 600px) {
    .container { padding: 18px; }
}
</style>
</head>
<body>
<div class="container">

    <?php include 'nav.php'; ?>

    <h2>Add Member to Gold Scheme</h2>

    <?php if ($message): ?>
        <div class="message"><?php echo htmlspecialchars($message); ?></div>
    <?php endif; ?>

    <!-- Search form -->
    <form method="post">
        <label>Enter Aadhar Number:</label>
        <input type="text" name="aadhar" maxlength="12" minlength="12" pattern="[0-9]{12}" 
               title="Enter exactly 12 digits" required 
               value="<?php echo isset($_POST['aadhar']) ? htmlspecialchars($_POST['aadhar']) : ''; ?>">
        <button type="submit" name="search">🔍 Search</button>
    </form>

    <?php if ($customer): ?>
        <div class="customer-details">
            <p><strong>Aadhar:</strong> <?= htmlspecialchars($customer['Aadhar_Number']); ?></p>
            <p><strong>Name:</strong> <?= htmlspecialchars($customer['Full_Name']); ?></p>
            <p><strong>Parent:</strong> <?= htmlspecialchars($customer['Parent_Name']); ?></p>
            <p><strong>Mobile:</strong> <?= htmlspecialchars($customer['Mobile_Number']); ?></p>
            <p><strong>DOB:</strong> <?= htmlspecialchars($customer['Date_of_Birth']); ?></p>
            <p><strong>House:</strong> <?= htmlspecialchars($customer['House_No']); ?></p>
            <p><strong>Address:</strong> <?= htmlspecialchars($customer['Address']); ?></p>
            <p><strong>Place:</strong> <?= htmlspecialchars($customer['Place']); ?></p>
            <p><strong>Taluk:</strong> <?= htmlspecialchars($customer['Taluk']); ?></p>
            <p><strong>District:</strong> <?= htmlspecialchars($customer['District']); ?></p>
            <p><strong>Pincode:</strong> <?= htmlspecialchars($customer['Pincode']); ?></p>
        </div>

        <form method="post" style="margin-top: 25px;" onsubmit="return confirmAddScheme();">
            <input type="hidden" name="aadhar" value="<?= htmlspecialchars($customer['Aadhar_Number']); ?>">

            <label style="margin-top: 10px;">Select Scheme:</label>
            <select name="scheme_id" required>
                <option value="">-- Select Active Scheme --</option>
                <?php foreach ($schemes as $scheme): ?>
                    <option value="<?= $scheme['id']; ?>"><?= htmlspecialchars($scheme['Scheme_Name']); ?></option>
                <?php endforeach; ?>
            </select>

            <label style="margin-top: 10px;">Enter Scheme Card Number:</label>
            <input type="text" name="scheme_no" required pattern="[0-9]+" title="Only numbers are allowed">

            <button type="submit" name="add_scheme" style="margin-top: 15px;">💳 Add to Scheme</button>
        </form>
    <?php endif; ?>

</div>

<script>
function confirmAddScheme() {
    return confirm("Are you sure you want to add this member to the selected scheme?");
}
</script>

</body>
</html>
