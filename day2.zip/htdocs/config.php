<?php
// Database configuration
$servername = "sql304.infinityfree.com";     // usually 'localhost' or your hosting server
$username   = "if0_40255690";          // your MySQL username
$password   = "sJlnyjoJhuE";              // your MySQL password
$dbname     = "if0_40255690_ABSDB"; // your database name

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("❌ Database connection failed: " . $conn->connect_error);
}

// Optional: set character encoding
$conn->set_charset("utf8");
?>
