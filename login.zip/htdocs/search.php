<?php
require_once 'config.php';

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

$result = null;
$message = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $slno = trim($_POST['slno']);
    if ($slno !== '') {
        $sql = "SELECT * FROM lucky_dip_candidates WHERE Slno = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("i", $slno);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows === 0) {
            $message = "<div class='error'>❌ No record found for Sl No: <strong>$slno</strong></div>";
        }
    } else {
        $message = "<div class='error'>⚠️ Please enter a valid Sl No!</div>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Search Candidate - ABS Lucky Dip</title>
<style>
    * { box-sizing: border-box; }
    body {
        font-family: "Poppins", sans-serif;
        background: linear-gradient(135deg, #6a11cb, #2575fc);
        margin: 0;
        padding: 15px;
        display: flex;
        justify-content: center;
        align-items: flex-start;
        min-height: 100vh;
    }
    .wrapper {
        background: #fff;
        width: 100%;
        max-width: 700px;
        border-radius: 15px;
        box-shadow: 0 4px 18px rgba(0,0,0,0.15);
        overflow: hidden;
        animation: fadeIn 0.4s ease-in-out;
    }
    @keyframes fadeIn {
        from { opacity: 0; transform: translateY(10px); }
        to { opacity: 1; transform: translateY(0); }
    }

    .header {
        background: #0d47a1;
        color: #fff;
        text-align: center;
        padding: 15px 10px;
    }
    .header h1 {
        font-size: 1.4rem;
        margin: 0;
        font-weight: 700;
    }
    .header h2 {
        font-size: 1rem;
        margin: 5px 0;
        font-weight: 500;
        font-style: italic;
    }
    .header p {
        margin: 2px 0;
        font-size: 0.8rem;
    }

    .content {
        padding: 20px;
    }
    h3 {
        text-align: center;
        color: #2575fc;
        margin-bottom: 12px;
        font-size: 1.1rem;
    }

    form {
        display: flex;
        justify-content: center;
        align-items: center;
        gap: 10px;
        flex-wrap: wrap;
        margin-bottom: 20px;
    }

    input[type="number"] {
        width: 200px;
        padding: 10px;
        border: 1px solid #ccc;
        border-radius: 6px;
        font-size: 0.95rem;
        outline: none;
    }
    input:focus {
        border-color: #2575fc;
        box-shadow: 0 0 6px rgba(37,117,252,0.4);
    }

    button {
        background: linear-gradient(135deg, #6a11cb, #2575fc);
        color: #fff;
        border: none;
        padding: 10px 16px;
        border-radius: 6px;
        font-size: 1rem;
        cursor: pointer;
        font-weight: 600;
        transition: 0.3s;
    }
    button:hover {
        opacity: 0.9;
        transform: scale(1.02);
    }

    .success, .error {
        margin-bottom: 10px;
        padding: 10px;
        border-radius: 5px;
        font-weight: 500;
        text-align: center;
    }
    .success {
        background: #d4edda;
        color: #155724;
    }
    .error {
        background: #f8d7da;
        color: #721c24;
    }

    .details {
        background: #f9f9f9;
        border-radius: 10px;
        padding: 15px;
        font-size: 0.95rem;
        line-height: 1.5;
        display: grid;
        grid-template-columns: 1fr 1fr;
        gap: 8px 20px;
    }
    .details div span {
        font-weight: 600;
        color: #0d47a1;
    }

    @media (max-width: 600px) {
        .details {
            grid-template-columns: 1fr;
        }
        .header h1 { font-size: 1.2rem; }
        .header h2 { font-size: 0.9rem; }
        .header p { font-size: 0.75rem; }
    }
</style>
</head>
<body>

<div class="wrapper">
    <div class="header">
        <h1>ABS DREAM INDIA GROUPS</h1>
        <h2>"Your Trust, Our Movement"</h2>
        <p>#74, ‘Kiran’, Behind RTC Complex, Hospet – 583212</p>
    </div>

    <div class="content">
        <h3>🔍 Search Candidate Details</h3>

        <?= $message ?>

        <form method="POST">
            <input type="number" name="slno" placeholder="Enter Sl No" required>
            <button type="submit">Search</button>
        </form>

        <?php if ($result && $result->num_rows > 0): 
            $row = $result->fetch_assoc(); ?>
            <div class="details">
                <div><span>Sl No:</span> <?= htmlspecialchars($row['Slno']) ?></div>
                <div><span>Candidate Name:</span> <?= htmlspecialchars($row['Candidate_Name']) ?></div>
                <div><span>Parent Name:</span> <?= htmlspecialchars($row['Parent_Name']) ?></div>
                <div><span>Address (Aadhar):</span> <?= htmlspecialchars($row['Address_Aadhar']) ?></div>
                <div><span>Thaluk:</span> <?= htmlspecialchars($row['Thaluk']) ?></div>
                <div><span>Village:</span> <?= htmlspecialchars($row['Village']) ?></div>
                <div><span>Pin Code:</span> <?= htmlspecialchars($row['Pin_Code']) ?></div>
                <div><span>Aadhar No:</span> <?= htmlspecialchars($row['Aadhar_No']) ?></div>
                <div><span>Mobile No:</span> <?= htmlspecialchars($row['Mobile_No']) ?></div>
                <div><span>Scheme Name:</span> <?= htmlspecialchars($row['Scheme_Name']) ?></div>
                <div><span>Registered At:</span> <?= htmlspecialchars($row['Registered_At']) ?></div>
            </div>
        <?php endif; ?>
    </div>
</div>

</body>
</html>
