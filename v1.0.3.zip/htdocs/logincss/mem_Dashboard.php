<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
session_start();
if (!isset($_SESSION['username'])) {
    header("Location: ../login.php");
    exit();
}

require_once "../config.php"; 
$username = $_SESSION['username'];

// 🔹 Fetch member details
$sql = "SELECT 
            Aadhar_Number, 
            Full_Name, 
            Parent_Name, 
            Mobile_Number, 
            Date_Of_Birth, 
            House_No, 
            Address, 
            Place, 
            Taluk, 
            District, 
            Pincode 
        FROM ABS_customer_details 
        WHERE Mobile_Number = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $username);
$stmt->execute();
$result = $stmt->get_result();
$member = $result->fetch_assoc();
$stmt->close();

// 🔹 Fetch winner card details
$winnerCards = [];
$schemeSQL = "SELECT Scheme_Name, Dip_Info_table_name FROM ABS_Schemes_Details WHERE Status='ACTIVE'";
$schemeResult = $conn->query($schemeSQL);

if ($schemeResult && $schemeResult->num_rows > 0) {
    while ($scheme = $schemeResult->fetch_assoc()) {
        $schemeName = $scheme['Scheme_Name'];
        $dipTable = $scheme['Dip_Info_table_name'];

        if (!empty($dipTable)) {
            // Check if table exists
            $check = $conn->query("SHOW TABLES LIKE '$dipTable'");
            if ($check && $check->num_rows > 0) {
                $dipSQL = "SELECT Scheme_Card_Number, Win_Date 
                           FROM $dipTable 
                           WHERE Mobile_Number = ? AND Winning_Status = 'WINNER'";
                $stmt = $conn->prepare($dipSQL);
                if ($stmt) {
                    $stmt->bind_param("s", $username);
                    $stmt->execute();
                    $res = $stmt->get_result();
                    while ($row = $res->fetch_assoc()) {
                        $winnerCards[] = [
                            'Scheme_Name' => $schemeName,
                            'Scheme_Card_Number' => $row['Scheme_Card_Number'],
                            'Win_Date' => ($row['Win_Date'] && $row['Win_Date'] !== '0000-00-00')
                                ? date("d-m-Y", strtotime($row['Win_Date']))
                                : '-'
                        ];
                    }
                    $stmt->close();
                }
            }
        }
    }
}
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Member Dashboard</title>
<style>
:root {
    --bg: #f5f5f5;
    --card-bg: #fff;
    --text: #222;
    --primary: #000;
    --accent: #555;
    --border: #ccc;
    --win-bg: #d4edda;
    --trophy: #f4c542;
}

body {
    font-family: Arial, sans-serif;
    background-color: var(--bg);
    color: var(--text);
    display: flex;
    align-items: center;
    justify-content: center;
    min-height: 100vh;
    margin: 0;
    padding: 15px;
}

.container {
    position: relative;
    background: var(--card-bg);
    border-radius: 12px;
    box-shadow: 0 0 10px rgba(0,0,0,0.2);
    max-width: 800px;
    width: 100%;
    min-height: 90vh;
    display: flex;
    flex-direction: column;
    justify-content: flex-start;
    padding: 25px;
    box-sizing: border-box;
    height: auto;
    overflow: hidden;
}

/* Watermark */
.container::before {
    content: "";
    position: absolute;
    top: 50%;
    left: 50%;
    width: 180px;
    height: 180px;
    background: url('logo.webp') no-repeat center center;
    background-size: contain;
    opacity: 0.25;
    transform: translate(-50%, -50%);
    pointer-events: none;
    z-index: 0;
}

.container > * {
    position: relative;
    z-index: 1;
}

.profile-card, .winner-card {
    background: #fafafa;
    border: 1px solid var(--border);
    border-radius: 10px;
    padding: 20px;
    margin-top: 20px;
    box-shadow: 0 2px 6px rgba(0,0,0,0.1);
}

.profile-card h2, .winner-card h2 {
    margin-bottom: 15px;
    font-size: 20px;
    color: var(--primary);
    text-align: center;
}

/* 🏆 Winner card styling */
.winner-card {
    background: var(--win-bg);
    position: relative;
    animation: glow 2s ease-in-out infinite alternate;
    overflow: hidden;
}

/* 🎊 Fewer confetti particles */
.winner-card::after {
    content: "";
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background-image:
        radial-gradient(circle, gold 3px, transparent 4px),
        radial-gradient(circle, #ff4081 3px, transparent 4px);
    background-size: 100px 100px; /* wider spacing = fewer confetti */
    animation: confetti-fall 16s linear infinite;
    opacity: 0.25;
    pointer-events: none;
}

@keyframes confetti-fall {
    0% { background-position: 0 -100px, 60px -200px; }
    100% { background-position: 0 600px, 60px 700px; }
}

/* 🌟 Soft glow */
@keyframes glow {
    from { box-shadow: 0 0 10px #66bb6a, 0 0 20px #81c784; }
    to { box-shadow: 0 0 20px #43a047, 0 0 30px #2e7d32; }
}

/* 🏆 Congratulations */
.congrats {
    text-align: center;
    font-size: 22px;
    font-weight: bold;
    color: #2e7d32;
    margin-bottom: 15px;
    text-shadow: 0 0 8px #81c784;
}

.congrats .trophy {
    color: var(--trophy);
    font-size: 28px;
    vertical-align: middle;
    animation: shine 3s ease-in-out infinite;
}

/* ✨ Trophy shine */
@keyframes shine {
    0%, 100% { text-shadow: 0 0 6px rgba(255,215,0,0.6), 0 0 10px rgba(255,223,0,0.4); }
    50% { text-shadow: 0 0 14px rgba(255,223,0,1), 0 0 25px rgba(255,255,0,0.8); }
}

.winner-item {
    background: #fff;
    border: 1px solid var(--border);
    border-radius: 8px;
    padding: 12px;
    margin-bottom: 10px;
}

.winner-item p {
    margin: 6px 0;
}

.winner-item .label {
    font-weight: bold;
    color: var(--accent);
}

/* Profile section */
.profile-details {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 10px 20px;
    font-size: 16px;
    line-height: 1.5;
}

.profile-details div span {
    display: block;
    font-weight: bold;
    color: var(--accent);
    font-size: 14px;
}

/* Responsive */
@media (max-width: 768px) {
    .container {
        height: auto;
        padding: 18px;
        border-radius: 10px;
    }

    .profile-details {
        grid-template-columns: 1fr;
    }
}
</style>

</head>
<body>
<div class="container">

    <?php include 'mem_nav.php'; ?>

    <h1>Welcome, <?php echo htmlspecialchars($_SESSION['mem_name']); ?> 👋</h1>

    <!-- 🏆 Winner Card Section -->
    <?php if (!empty($winnerCards)): ?>
        <div class="winner-card">
            <div class="congrats">🏆 Congratulations! You’re a Winner 🎉</div>
            <?php foreach ($winnerCards as $card): ?>
                <div class="winner-item">
                    <p><span class="label">Scheme Name:</span> <?= htmlspecialchars($card['Scheme_Name']); ?></p>
                    <p><span class="label">Scheme Card Number:</span> <?= htmlspecialchars($card['Scheme_Card_Number']); ?></p>
                    <p><span class="label">Win Date:</span> <?= htmlspecialchars($card['Win_Date']); ?></p>
                </div>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>

    <!-- 👤 Member Profile -->
    <div class="profile-card">
        <h2>Member Profile</h2>
        <?php if ($member): ?>
            <div class="profile-details">
                <div><span>Aadhar Number:</span> <?= htmlspecialchars($member['Aadhar_Number']); ?></div>
                <div><span>Full Name:</span> <?= htmlspecialchars($member['Full_Name']); ?></div>
                <div><span>Parent Name:</span> <?= htmlspecialchars($member['Parent_Name']); ?></div>
                <div><span>Mobile Number:</span> <?= htmlspecialchars($member['Mobile_Number']); ?></div>
                <div><span>Date of Birth:</span> <?= htmlspecialchars($member['Date_Of_Birth']); ?></div>
                <div><span>House No:</span> <?= htmlspecialchars($member['House_No']); ?></div>
                <div><span>Address:</span> <?= htmlspecialchars($member['Address']); ?></div>
                <div><span>Place:</span> <?= htmlspecialchars($member['Place']); ?></div>
                <div><span>Taluk:</span> <?= htmlspecialchars($member['Taluk']); ?></div>
                <div><span>District:</span> <?= htmlspecialchars($member['District']); ?></div>
                <div><span>Pincode:</span> <?= htmlspecialchars($member['Pincode']); ?></div>
            </div>
        <?php else: ?>
            <p>No profile details found for this user.</p>
        <?php endif; ?>
    </div>

</div>
</body>
</html>
