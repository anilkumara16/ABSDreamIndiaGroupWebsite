<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
session_start();
if (!isset($_SESSION['username'])) {
    header("Location: ../login.php");
    exit();
}

require_once "../config.php";
$username = $_SESSION['username'];
$schemes = [];

// 🔹 Fetch all active scheme tables
$schemeSQL = "SELECT Scheme_Name, scheme_table_name 
              FROM ABS_Schemes_Details 
              WHERE Status = 'ACTIVE'";
$schemeResult = $conn->query($schemeSQL);

if ($schemeResult && $schemeResult->num_rows > 0) {
    while ($scheme = $schemeResult->fetch_assoc()) {
        $schemeName = $scheme['Scheme_Name'];
        $tableName = $scheme['scheme_table_name'];

        $memberSQL = "SELECT Scheme_Card_Number, Winning_Status, Winning_Category, Win_Date
                      FROM $tableName 
                      WHERE Mobile_Number = ?";
        $stmt = $conn->prepare($memberSQL);
        $stmt->bind_param("s", $username);
        $stmt->execute();
        $res = $stmt->get_result();

        $records = [];
        while ($row = $res->fetch_assoc()) {
            $records[] = $row;
        }

        if (!empty($records)) {
            $schemes[] = [
                'Scheme_Name' => $schemeName,
                'Records' => $records
            ];
        }

        $stmt->close();
    }
}
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>My Schemes</title>
<style>
:root {
    --bg: #f5f5f5;
    --card-bg: #fff;
    --text: #222;
    --primary: #000;
    --accent: #555;
    --border: #ccc;
    --win-bg: #d4edda;
}

body {
    font-family: Arial, sans-serif;
    background-color: var(--bg);
    color: var(--text);
    display: flex;
    align-items: center;
    justify-content: center;
    min-height: 100vh;
    margin: 0;
    padding: 15px;
}

.container {
    position: relative;
    background: var(--card-bg);
    border-radius: 12px;
    box-shadow: 0 0 10px rgba(0,0,0,0.2);
    max-width: 900px;
    width: 100%;
    height: 90vh;
    display: flex;
    flex-direction: column;
    justify-content: flex-start;
    padding: 25px;
    box-sizing: border-box;
    overflow-y: auto;
}

.container::before {
    content: "";
    position: absolute;
    top: 50%;
    left: 50%;
    width: 180px;
    height: 180px;
    background: url('logo.webp') no-repeat center center;
    background-size: contain;
    opacity: 0.25;
    transform: translate(-50%, -50%);
    pointer-events: none;
    z-index: 0;
}

.container > * {
    position: relative;
    z-index: 1;
}

h1 {
    text-align: center;
    color: var(--primary);
    margin-bottom: 15px;
}

/* Scheme card */
.scheme-card {
    background: #fafafa;
    border: 1px solid var(--border);
    border-radius: 10px;
    padding: 20px;
    margin-top: 20px;
    box-shadow: 0 2px 6px rgba(0,0,0,0.1);
}

.scheme-card h2 {
    text-align: center;
    color: var(--primary);
    margin-bottom: 15px;
}

/* Record (each winning entry) */
.record {
    border: 1px solid var(--border);
    border-radius: 8px;
    padding: 12px 15px;
    margin-bottom: 10px;
    background: #fff;
    transition: transform 0.3s ease, box-shadow 0.3s ease;
}

/* 🎉 Winner highlight */
.record.winner {
    background: var(--win-bg);
    font-weight: bold;
    border-color: #28a745;
    animation: winnerGlow 2s ease-in-out infinite alternate;
}

@keyframes winnerGlow {
    from { box-shadow: 0 0 8px #a5d6a7; transform: scale(1); }
    to { box-shadow: 0 0 20px #4caf50; transform: scale(1.02); }
}

/* ✨ Congratulations fade-in */
.congrats {
    text-align: center;
    color: #2e7d32;
    font-weight: bold;
    font-size: 16px;
    margin-bottom: 10px;
    opacity: 0;
    animation: fadeIn 1.5s ease forwards;
}

@keyframes fadeIn {
    from { opacity: 0; transform: translateY(-5px); }
    to { opacity: 1; transform: translateY(0); }
}

/* 🏆 Trophy shine */
.trophy {
    color: gold;
    margin-left: 5px;
    font-size: 1.2em;
    animation: shine 3s ease-in-out infinite;
}

@keyframes shine {
    0%,100% { text-shadow: 0 0 4px rgba(255,215,0,0.5), 0 0 8px rgba(255,223,0,0.3); }
    50% { text-shadow: 0 0 12px rgba(255,223,0,0.9), 0 0 20px rgba(255,255,0,0.7); }
}

.record p {
    margin: 6px 0;
    line-height: 1.4;
}

.label {
    font-weight: bold;
    color: var(--accent);
}

/* Responsive adjustments */
@media (max-width: 768px) {
    .container {
        height: auto;
        padding: 18px;
    }
}
</style>

</head>
<body>
<div class="container">

    <?php include 'mem_nav.php'; ?>

    <h1>My Scheme Details</h1>

    <?php if (!empty($schemes)): ?>
        <?php foreach ($schemes as $scheme): ?>
            <div class="scheme-card">
                <h2><?= htmlspecialchars($scheme['Scheme_Name']); ?></h2>

                <?php foreach ($scheme['Records'] as $index => $row): ?>
                    <div class="record <?= ($row['Winning_Status'] === 'WINNER') ? 'winner' : ''; ?>">
                        <?php if ($row['Winning_Status'] === 'WINNER'): ?>
                            <div class="congrats">🎉 Congratulations! You are a Winner <span class="trophy">🏆</span></div>
                        <?php endif; ?>

                        <p><span class="label">Sl No:</span> <?= $index + 1; ?></p>
                        <p><span class="label">Scheme Card Number:</span> <?= htmlspecialchars($row['Scheme_Card_Number']); ?></p>
                        <p><span class="label">Winning Status:</span> <?= htmlspecialchars($row['Winning_Status']); ?></p>
                        <p><span class="label">Winning Category:</span> <?= htmlspecialchars($row['Winning_Category']); ?></p>
                        <p><span class="label">Win Date:</span> <?= htmlspecialchars(
    						($row['Win_Date'] && $row['Win_Date'] !== '0000-00-00')
        					? date("d-m-Y", strtotime($row['Win_Date']))
        					: '-'
							); ?></p>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php endforeach; ?>
    <?php else: ?>
        <div class="scheme-card">
            <p>No scheme records found.</p>
        </div>
    <?php endif; ?>

</div>
</body>
</html>
