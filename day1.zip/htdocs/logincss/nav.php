<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit();
}
?>

<style>
    /* NAVIGATION BAR (for inside container) */
    .navbar {
        background-color: #222;
        color: #fff;
        display: flex;
        justify-content: space-between;
        align-items: center;
        padding: 10px 15px;
        border-radius: 8px;
        flex-wrap: wrap;
        margin-bottom: 20px;
    }

    .navbar-left, .navbar-right {
        display: flex;
        align-items: center;
        gap: 15px;
    }

    .navbar a {
        color: #fff;
        text-decoration: none;
        font-weight: bold;
        font-size: 16px;
        padding: 6px 10px;
        border-radius: 5px;
        transition: background 0.3s;
    }

    .navbar a:hover {
        background-color: #444;
    }

    /* Dropdown */
    .dropdown {
        position: relative;
        display: inline-block;
    }

    .dropbtn {
        background: none;
        border: none;
        color: #fff;
        font-weight: bold;
        font-size: 16px;
        cursor: pointer;
        padding: 6px 10px;
        border-radius: 5px;
        transition: background 0.3s;
    }

    .dropbtn:hover {
        background-color: #444;
    }

    .dropdown-content {
        display: none;
        position: absolute;
        background-color: #333;
        min-width: 160px;
        border-radius: 6px;
        box-shadow: 0 4px 8px rgba(0,0,0,0.3);
        z-index: 1;
    }

    .dropdown-content a {
        color: white;
        padding: 10px 12px;
        text-decoration: none;
        display: block;
        transition: background 0.3s;
    }

    .dropdown-content a:hover {
        background-color: #555;
    }

    .dropdown:hover .dropdown-content {
        display: block;
    }

    @media (max-width: 600px) {
        .navbar {
            flex-direction: column;
            align-items: flex-start;
        }
        .navbar-left, .navbar-right {
            width: 100%;
            justify-content: space-between;
        }
    }
</style>

<div class="navbar">
    <div class="navbar-left">
        <a href="dashboard.php">Home</a>
        <div class="dropdown">
            <button class="dropbtn">Member ▼</button>
            <div class="dropdown-content">
                <a href="addMember.php">Add</a>
                <a href="vu_member_details.php">View/Update</a>
            </div>
        </div>
        <div class="dropdown">
            <button class="dropbtn">Schemes ▼</button>
            <div class="dropdown-content">
                <a href="add_toGoldScheme.php">Add Member to Gold Scheme</a>
                <!--<a href="vu_member_details.php">View Members</a>-->
            </div>
        </div>
    </div>
    <div class="navbar-right">
        <a href="logout.php">Logout</a>
    </div>
</div>
