<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
session_start();
if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit();
}

require_once "config.php"; // DB connection

$message = "";
$customer = null;
$created_by = $_SESSION['username'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    // 🔹 Step 1: Search for Aadhar Number
    if (isset($_POST['search'])) {
        $aadhar = trim($_POST['aadhar']);
        $sql = "SELECT * FROM ABS_customer_details WHERE Aadhar_Number = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("s", $aadhar);
        $stmt->execute();
        $result = $stmt->get_result();
        $customer = $result->fetch_assoc();

        if (!$customer) {
            $message = "❌ Member not found!";
        }
    }

    // 🔹 Step 2: Insert Gold Scheme Details
    if (isset($_POST['add_scheme'])) {
        $aadhar = $_POST['aadhar'];
        $scheme_no = trim($_POST['scheme_no']);
        $created_at = date("Y-m-d H:i:s");

        // 🔸 Validate numeric Scheme Card Number
        if (!preg_match('/^[0-9]+$/', $scheme_no)) {
            $message = "⚠️ Scheme Card Number must contain only numbers!";
        } else {
            // Check if Scheme_Card_Number already exists
            $checkSQL = "SELECT Scheme_Card_Number FROM ABS_Gold_Scheme_Details WHERE Scheme_Card_Number = ?";
            $checkStmt = $conn->prepare($checkSQL);
            $checkStmt->bind_param("s", $scheme_no);
            $checkStmt->execute();
            $checkResult = $checkStmt->get_result();

            if ($checkResult->num_rows > 0) {
                $message = "⚠️ Scheme Card Number already allotted to someone!";
            } else {
                // Retrieve customer details again
                $sql = "SELECT * FROM ABS_customer_details WHERE Aadhar_Number = ?";
                $stmt = $conn->prepare($sql);
                $stmt->bind_param("s", $aadhar);
                $stmt->execute();
                $customer = $stmt->get_result()->fetch_assoc();

                if ($customer) {
                    // Insert into ABS_Gold_Scheme_Details
                    $insertSQL = "INSERT INTO ABS_Gold_Scheme_Details 
                    (Scheme_Card_Number, Aadhar_Number, Full_Name, Parent_Name, Mobile_Number, Date_of_Birth,
                     House_No, Address, Place, Taluk, District, Pincode, Created_By, Created_At)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

                    $stmt2 = $conn->prepare($insertSQL);
                    $stmt2->bind_param(
                        "ssssssssssssss",
                        $scheme_no,
                        $customer['Aadhar_Number'],
                        $customer['Full_Name'],
                        $customer['Parent_Name'],
                        $customer['Mobile_Number'],
                        $customer['Date_of_Birth'],
                        $customer['House_No'],
                        $customer['Address'],
                        $customer['Place'],
                        $customer['Taluk'],
                        $customer['District'],
                        $customer['Pincode'],
                        $created_by,
                        $created_at
                    );
                    $stmt2->execute();

                    // Insert login credentials (mobile as username, hash of mobile as password)
                    $username = $customer['Mobile_Number'];
                    $password = password_hash($customer['Mobile_Number'], PASSWORD_DEFAULT);
                    $dob = $customer['Date_of_Birth'];
                    $role = "member";

                    $loginSQL = "INSERT INTO ABS_Login_Creds (username, password, role, DateOfBirth) VALUES (?, ?, ?, ?)";
                    $stmt3 = $conn->prepare($loginSQL);
                    $stmt3->bind_param("ssss", $username, $password, $role, $dob);
                    $stmt3->execute();

                    $message = "✅ Scheme details added successfully!";
                    $customer = null;
                } else {
                    $message = "❌ Member not found!";
                }
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Add Gold Scheme</title>
<style>
:root {
    --bg: #f5f5f5;
    --card-bg: #fff;
    --text: #222;
    --primary: #000;
    --accent: #555;
    --border: #ccc;
}

body {
    font-family: Arial, sans-serif;
    background: var(--bg);
    color: var(--text);
    margin: 0;
    padding: 15px;
    display: flex;
    justify-content: center;
}

.container {
    background: var(--card-bg);
    border-radius: 12px;
    box-shadow: 0 0 10px rgba(0,0,0,0.15);
    max-width: 600px;
    width: 100%;
    padding: 25px;
    box-sizing: border-box;
    position: relative;
}

.message {
    background: #ffdddd;
    border-left: 5px solid #f44336;
    color: #333;
    padding: 10px;
    margin-bottom: 15px;
    border-radius: 5px;
    text-align: center;
    animation: fadeOut 4s ease-in-out forwards;
}
@keyframes fadeOut {
    0% {opacity: 1;}
    80% {opacity: 1;}
    100% {opacity: 0;}
}

form {
    display: flex;
    flex-direction: column;
    gap: 12px;
}

input[type="text"], input[type="number"] {
    padding: 10px;
    border: 1px solid var(--border);
    border-radius: 6px;
    width: 100%;
    box-sizing: border-box;
}

button {
    padding: 10px;
    background: var(--primary);
    color: white;
    border: none;
    border-radius: 6px;
    cursor: pointer;
}
button:hover {
    background: var(--accent);
}

.customer-details {
    margin-top: 20px;
    background: #fafafa;
    border: 1px solid var(--border);
    border-radius: 8px;
    padding: 15px;
}
.customer-details p {
    margin: 5px 0;
}

@media (max-width: 600px) {
    .container { padding: 18px; }
}
</style>
</head>
<body>
<div class="container">

    <?php include 'nav.php'; ?>

    <h2>Add Member to Gold Scheme</h2>

    <?php if ($message): ?>
        <div class="message"><?php echo htmlspecialchars($message); ?></div>
    <?php endif; ?>

    <form method="post">
        <label>Enter Aadhar Number:</label>
        <input type="text" name="aadhar" required value="<?php echo isset($_POST['aadhar']) ? htmlspecialchars($_POST['aadhar']) : ''; ?>">
        <button type="submit" name="search">🔍 Search</button>
    </form>

    <?php if ($customer): ?>
        <div class="customer-details">
            <p><strong>Aadhar:</strong> <?= htmlspecialchars($customer['Aadhar_Number']); ?></p>
            <p><strong>Name:</strong> <?= htmlspecialchars($customer['Full_Name']); ?></p>
            <p><strong>Parent:</strong> <?= htmlspecialchars($customer['Parent_Name']); ?></p>
            <p><strong>Mobile:</strong> <?= htmlspecialchars($customer['Mobile_Number']); ?></p>
            <p><strong>DOB:</strong> <?= htmlspecialchars($customer['Date_of_Birth']); ?></p>
            <p><strong>House:</strong> <?= htmlspecialchars($customer['House_No']); ?></p>
            <p><strong>Address:</strong> <?= htmlspecialchars($customer['Address']); ?></p>
            <p><strong>Place:</strong> <?= htmlspecialchars($customer['Place']); ?></p>
            <p><strong>Taluk:</strong> <?= htmlspecialchars($customer['Taluk']); ?></p>
            <p><strong>District:</strong> <?= htmlspecialchars($customer['District']); ?></p>
            <p><strong>Pincode:</strong> <?= htmlspecialchars($customer['Pincode']); ?></p>
        </div>

        <form method="post">
            <input type="hidden" name="aadhar" value="<?= htmlspecialchars($customer['Aadhar_Number']); ?>">
            <label>Enter Scheme Card Number:</label>
            <input type="text" name="scheme_no" required pattern="[0-9]+" title="Only numbers are allowed">
            <button type="submit" name="add_scheme">💳 Add Scheme</button>
        </form>
    <?php endif; ?>

</div>
</body>
</html>
