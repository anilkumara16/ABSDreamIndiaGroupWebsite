<?php
// Database configuration
$servername = "sql110.infinityfree.com";     // usually 'localhost' or your hosting server
$username   = "if0_40309763";          // your MySQL username
$password   = "J9InlzgsdsG6On8";              // your MySQL password
$dbname     = "if0_40309763_ABSDB"; // your database name

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("❌ Database connection failed: " . $conn->connect_error);
}

// Optional: set character encoding
$conn->set_charset("utf8");
?>
