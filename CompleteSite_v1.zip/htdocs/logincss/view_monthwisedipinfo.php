<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
session_start();
if (!isset($_SESSION['username'])) {
    header("Location: ../login.php");
    exit();
}

include '../config.php';
$username = $_SESSION['username'];

// Fetch active schemes
$schemes = [];
$query = "SELECT Scheme_Name, Dip_Info_table_name, start_date, end_date 
          FROM ABS_Schemes_Details 
          WHERE Status='ACTIVE' 
          ORDER BY Scheme_Name";
$res = $conn->query($query);
while ($row = $res->fetch_assoc()) {
    $schemes[] = $row;
}

$dipEntries = [];
$message = "";

// Handle search
if (isset($_POST['search'])) {
    $scheme = $_POST['scheme'] ?? '';
    $dipMonth = $_POST['Dip_Month'] ?? '';

    $dipTable = '';
    $start_date = null;
    $end_date = null;

    foreach ($schemes as $s) {
        if ($s['Scheme_Name'] === $scheme) {
            $dipTable = $s['Dip_Info_table_name'];
            $start_date = strtotime($s['start_date']);
            $end_date = strtotime($s['end_date']);
            break;
        }
    }

    if (empty($dipTable) || empty($dipMonth)) {
        $message = "❌ Please select scheme and month.";
    } else {
        $selectedDate = strtotime("01-" . $dipMonth);
        $current = strtotime(date('Y-m-01'));
        if ($selectedDate < $start_date || $selectedDate > $current || $selectedDate > $end_date) {
            $message = "⚠️ Selected month is not within valid scheme period.";
        } else {
            // Convert to actual Win_Date (using 15th of that month)
            $winDate = date('Y-m-d', strtotime('15-' . $dipMonth));

            $stmt = $conn->prepare("SELECT Scheme_Card_Number, Full_Name, Parent_Name, Mobile_Number, Winning_Category, Win_Date 
                                    FROM $dipTable WHERE Win_Date = ? ORDER BY Winning_Category");
            $stmt->bind_param("s", $winDate);
            $stmt->execute();
            $dipEntries = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
            $stmt->close();

            if (empty($dipEntries)) {
                $message = "❌ No Lucky Dip entries found for $dipMonth.";
            }
        }
    }
}
?>

<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>View Monthwise Dip Info</title>
<style>
body { font-family: Arial; background: #f5f5f5; margin: 0; padding: 20px; }
.container { background: #fff; border-radius: 12px; box-shadow: 0 0 8px rgba(0,0,0,0.2); max-width: 900px; margin: auto; padding: 25px; }
h2 { text-align: center; margin-top: 0; }
.search-section { background: #eee; border: 1px solid #ccc; border-radius: 10px; padding: 15px 20px; margin-bottom: 25px; }
.search-title { background: #ddd; padding: 8px 12px; font-weight: bold; border-radius: 6px; margin-bottom: 15px; }
.search-grid { display: grid; grid-template-columns: repeat(3, 1fr); gap: 15px; align-items: end; }
.search-buttons { display: flex; justify-content: flex-start; gap: 10px; }
label { font-weight: bold; display: block; margin-bottom: 5px; }
select, input[type="text"] { width: 100%; padding: 8px; border: 1px solid #bbb; border-radius: 6px; box-sizing: border-box; }
button { border: none; padding: 10px 15px; border-radius: 6px; font-weight: bold; cursor: pointer; }
.btn-search { background: #007bff; color: #fff; }
.btn-clear { background: #dc3545; color: #fff; }
.status-winner { background: lightgreen; padding: 3px 6px; border-radius: 4px; font-weight: bold; }
.status-runner { background: yellow; padding: 3px 6px; border-radius: 4px; font-weight: bold; }
.table-container { overflow-x: auto; }
table { width: 100%; border-collapse: collapse; margin-top: 20px; }
th, td { border: 1px solid #ccc; padding: 8px; text-align: center; }
th { background: #f0f0f0; }
@media (max-width: 768px) { .search-grid { grid-template-columns: 1fr; } }
</style>
<script>
function clearForm() {
    window.location.href = "view_monthwisedipinfo.php";
}

// Auto reload month list when scheme changes
function reloadDipMonths() {
    document.getElementById("searchForm").submit();
}
</script>
</head>
<body>
<div class="container">
    <?php include 'nav.php'; ?>
    <img src="logo.webp" alt="ABS Dream India Logo" 
     style="width:180px; height:auto; max-width:100%; display:block; margin:0 auto;">

    <h2>View Monthwise Lucky Dip Information</h2>

    <form method="post" id="searchForm" class="search-section">
        <div class="search-title">🔍 Search Lucky Dip by Month</div>
        <div class="search-grid">
            <div>
                <label>Scheme:</label>
                <select name="scheme" onchange="reloadDipMonths()" required>
                    <option value="">Select</option>
                    <?php foreach ($schemes as $scheme) { ?>
                        <option value="<?= htmlspecialchars($scheme['Scheme_Name']); ?>"
                            <?= (isset($_POST['scheme']) && $_POST['scheme']==$scheme['Scheme_Name']) ? 'selected' : ''; ?>>
                            <?= htmlspecialchars($scheme['Scheme_Name']); ?>
                        </option>
                    <?php } ?>
                </select>
            </div>
            <div>
                <label>Dip Month:</label>
                <select name="Dip_Month" required>
                    <option value="">Select</option>
                    <?php 
                    $selectedScheme = $_POST['scheme'] ?? '';
                    foreach ($schemes as $s) {
                        if ($s['Scheme_Name'] === $selectedScheme) {
                            $start = strtotime($s['start_date']);
                            $end = strtotime($s['end_date']);
                            $current = strtotime(date('Y-m-01'));
                            while ($start <= $end && $start <= $current) {
                                $monthLabel = date("M-Y", $start);
                                echo "<option value='" . htmlspecialchars($monthLabel) . "' " . 
                                     ((isset($_POST['Dip_Month']) && $_POST['Dip_Month']===$monthLabel) ? 'selected' : '') . 
                                     ">$monthLabel</option>";
                                $start = strtotime("+1 month", $start);
                            }
                        }
                    }
                    ?>
                </select>
            </div>
            <div class="search-buttons">
                <button type="submit" name="search" class="btn-search">Search</button>
                <button type="button" class="btn-clear" onclick="clearForm()">Clear</button>
            </div>
        </div>
    </form>

    <?php if ($message): ?>
        <div style="text-align:center;font-weight:bold;<?= strpos($message,'✅') !== false ? 'color:green' : 'color:red'; ?>">
            <?= $message; ?>
        </div>
    <?php endif; ?>

    <?php if (!empty($dipEntries)): ?>
        <div class="table-container">
            <table>
                <tr>
                    <th>Scheme Card Number</th>
                    <th>Full Name</th>
                    <th>Parent Name</th>
                    <th>Mobile</th>
                    <th>Category</th>
                    <th>Win Date</th>
                </tr>
                <?php foreach ($dipEntries as $entry): ?>
                    <tr>
                        <td><?= htmlspecialchars($entry['Scheme_Card_Number']); ?></td>
                        <td><?= htmlspecialchars($entry['Full_Name']); ?></td>
                        <td><?= htmlspecialchars($entry['Parent_Name']); ?></td>
                        <td><?= htmlspecialchars($entry['Mobile_Number']); ?></td>
                        <td><?= htmlspecialchars($entry['Winning_Category']); ?></td>
                        <td><?= htmlspecialchars(date('d-M-Y', strtotime($entry['Win_Date']))); ?></td>
                    </tr>
                <?php endforeach; ?>
            </table>
        </div>
    <?php endif; ?>
</div>
</body>
</html>
