<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
session_start();

if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit();
}

require_once "config.php";

$message = "";
$results = [];
$schemes = [];

// 🔹 Fetch all active schemes
$schemeSQL = "SELECT id, Scheme_Name, scheme_table_name FROM ABS_Schemes_Details WHERE Status = 'ACTIVE'";
$schemeRes = $conn->query($schemeSQL);
if ($schemeRes && $schemeRes->num_rows > 0) {
    $schemes = $schemeRes->fetch_all(MYSQLI_ASSOC);
}

// 🔹 Handle Clear (reset)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['clear'])) {
    header("Location: search_members.php");
    exit();
}

// 🔹 Handle Search
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['search'])) {
    $aadhar = trim($_POST['aadhar']);

    if (!preg_match('/^[0-9]{12}$/', $aadhar)) {
        $message = "⚠️ Please enter a valid 12-digit Aadhar Number!";
    } else {
        foreach ($schemes as $scheme) {
            $schemeTable = $scheme['scheme_table_name'];
            $schemeName  = $scheme['Scheme_Name'];

            // Check if this table exists
            $tableExists = $conn->query("SHOW TABLES LIKE '$schemeTable'");
            if ($tableExists->num_rows === 0) continue;

            // Fetch details for this member in current scheme
            $sql = "SELECT Scheme_Card_Number, IFNULL(Winning_Status, 'N/A') AS Winning_Status 
                    FROM $schemeTable 
                    WHERE Aadhar_Number = ?";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("s", $aadhar);
            $stmt->execute();
            $res = $stmt->get_result();

            while ($row = $res->fetch_assoc()) {
                $results[] = [
                    'Scheme_Name' => $schemeName,
                    'Scheme_Card_Number' => $row['Scheme_Card_Number'],
                    'Winning_Status' => $row['Winning_Status']
                ];
            }
        }

        if (empty($results)) {
            $message = "❌ No schemes found for this Aadhar Number.";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Search Member Schemes</title>
<style>
/* ✅ Copying main layout style from add_MemberToScheme.php */

body {
    font-family: Arial, sans-serif;
    background: #f5f5f5;
    color: #222;
    margin: 0;
    padding: 20px;
    display: flex;
    justify-content: center;
}

.container {
    background: #fff;
    border-radius: 12px;
    box-shadow: 0 0 8px rgba(0,0,0,0.2);
    max-width: 900px;
    width: 100%;
    padding: 25px;
    box-sizing: border-box;
}

h2 {
    text-align: center;
    margin-top: 0;
}

/* 🔹 Message */
.message {
    text-align: center;
    font-weight: bold;
    margin-top: 10px;
    padding: 10px;
    border-radius: 6px;
}
.message.success { color: green; background: #eaffea; border: 1px solid #b5e7b5; }
.message.error { color: red; background: #ffeaea; border: 1px solid #e7b5b5; }

/* 🔹 Search Section */
.search-section {
    background: #eee;
    border: 1px solid #ccc;
    border-radius: 10px;
    padding: 15px 20px;
    margin-bottom: 25px;
    display: grid;
    grid-template-columns: 2fr 1fr 1fr;
    gap: 15px;
    align-items: end;
}

.search-section label {
    font-weight: bold;
    display: block;
    margin-bottom: 5px;
}

.search-section input[type="text"] {
    width: 100%;
    padding: 8px;
    border: 1px solid #bbb;
    border-radius: 6px;
    box-sizing: border-box;
}

.search-section button {
    width: 100%;
    border: none;
    padding: 10px 15px;
    border-radius: 6px;
    font-weight: bold;
    cursor: pointer;
}

.search-btn {
    background: #28a745;
    color: white;
}
.search-btn:hover {
    background: #218838;
}
.clear-btn {
    background: #dc3545;
    color: white;
}
.clear-btn:hover {
    background: #c82333;
}

@media (max-width: 768px) {
    .search-section {
        grid-template-columns: 1fr;
    }
}

/* 🔹 Results Table */
.results-table {
    width: 100%;
    border-collapse: collapse;
    margin-top: 25px;
}

.results-table th, .results-table td {
    border: 1px solid #ddd;
    padding: 8px 10px;
    text-align: center;
}

.results-table th {
    background: #007bff;
    color: #fff;
    font-weight: bold;
}

.results-table tr:nth-child(even) {
    background: #f9f9f9;
}

.results-table tr:hover {
    background: #e8f0ff;
}
</style>
</head>

<body>
<div class="container">
    <?php include 'nav.php'; ?>

    <h2>Search Member’s Scheme Details</h2>

    <?php if ($message): ?>
        <div class="message <?= strpos($message, '❌') !== false ? 'error' : 'success'; ?>">
            <?= htmlspecialchars($message); ?>
        </div>
    <?php endif; ?>

    <form method="post" class="search-section">
        <div>
            <label>Enter Aadhar Number:</label>
            <input type="text" name="aadhar" maxlength="12" minlength="12" pattern="[0-9]{12}" 
                   title="Enter exactly 12 digits" required
                   value="<?= isset($_POST['aadhar']) ? htmlspecialchars($_POST['aadhar']) : ''; ?>">
        </div>

        <button type="submit" name="search" class="search-btn">🔍 Search</button>
        <button type="submit" name="clear" class="clear-btn">🧹 Clear</button>
    </form>

    <?php if (!empty($results)): ?>
        <h3>Scheme Details</h3>
        <table class="results-table">
            <thead>
                <tr>
                    <th>Scheme Card Number</th>
                    <th>Scheme Name</th>
                    <th>Winning Status</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($results as $r): ?>
                <tr>
                    <td><?= htmlspecialchars($r['Scheme_Card_Number']); ?></td>
                    <td><?= htmlspecialchars($r['Scheme_Name']); ?></td>
                    <td><?= htmlspecialchars($r['Winning_Status']); ?></td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    <?php endif; ?>
</div>
</body>
</html>
