<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
session_start();
if (!isset($_SESSION['username'])) {
    header("Location: ../login.php");
    exit();
}

require_once "../config.php"; // adjust if needed
$username = $_SESSION['username'];

// 🔹 Fetch member details
$sql = "SELECT 
            Aadhar_Number, 
            Full_Name, 
            Parent_Name, 
            Mobile_Number, 
            Date_Of_Birth, 
            House_No, 
            Address, 
            Place, 
            Taluk, 
            District, 
            Pincode 
        FROM ABS_customer_details 
        WHERE Mobile_Number = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $username);
$stmt->execute();
$result = $stmt->get_result();
$member = $result->fetch_assoc();
$stmt->close();
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Member Dashboard</title>
<style>
:root {
    --bg: #f5f5f5;
    --card-bg: #fff;
    --text: #222;
    --primary: #000;
    --accent: #555;
    --border: #ccc;
}

body {
    font-family: Arial, sans-serif;
    background-color: var(--bg);
    color: var(--text);
    display: flex;
    align-items: center;
    justify-content: center;
    min-height: 100vh;
    margin: 0;
    padding: 15px;
}

/* Main container */
.container {
    position: relative;
    background: var(--card-bg);
    border-radius: 12px;
    box-shadow: 0 0 10px rgba(0,0,0,0.2);
    max-width: 800px;
    width: 100%;
    height: 90vh;
    display: flex;
    flex-direction: column;
    justify-content: flex-start;
    padding: 25px;
    box-sizing: border-box;
    /*overflow-y: auto;*/
}

/* Watermark logo */
.container::before {
    content: "";
    position: absolute;
    top: 50%;
    left: 50%;
    width: 180px;
    height: 180px;
    background: url('logo.webp') no-repeat center center;
    background-size: contain;
    opacity: 0.25;
    transform: translate(-50%, -50%);
    pointer-events: none;
    z-index: 0;
}

/* Keep content above watermark */
.container > * {
    position: relative;
    z-index: 1;
}

.profile-card {
    background: #fafafa;
    border: 1px solid var(--border);
    border-radius: 10px;
    padding: 20px;
    margin-top: 20px;
    box-shadow: 0 2px 6px rgba(0,0,0,0.1);
}

.profile-card h2 {
    margin-bottom: 15px;
    font-size: 20px;
    color: var(--primary);
    text-align: center;
}

/* Grid layout for details */
.profile-details {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 10px 20px;
    font-size: 16px;
    line-height: 1.5;
}

.profile-details div span {
    display: block;
    font-weight: bold;
    color: var(--accent);
    font-size: 14px;
}

/* --- RESPONSIVE DESIGN --- */
@media (max-width: 768px) {
    .container {
        height: auto;
        min-height: 90vh;
        padding: 18px;
        border-radius: 10px;
    }

    .container::before {
        width: 120px;
        height: 120px;
        top: 55%;
        opacity: 0.18;
    }

    .profile-details {
        grid-template-columns: 1fr; /* stack vertically */
        gap: 12px;
        font-size: 15px;
    }
}

@media (max-width: 400px) {
    .container::before {
        width: 90px;
        height: 90px;
        opacity: 0.15;
    }

    .profile-card {
        padding: 15px;
    }

    .profile-details {
        font-size: 14px;
    }
}
</style>
</head>
<body>
<div class="container">

    <?php include 'mem_nav.php'; ?>

    <h1>Welcome, <?php echo htmlspecialchars($_SESSION['mem_name']); ?> 👋</h1>

    <div class="profile-card">
        <h2>Member Profile</h2>
        <?php if ($member): ?>
            <div class="profile-details">
                <div><span>Aadhar Number:</span> <?php echo htmlspecialchars($member['Aadhar_Number']); ?></div>
                <div><span>Full Name:</span> <?php echo htmlspecialchars($member['Full_Name']); ?></div>
                <div><span>Parent Name:</span> <?php echo htmlspecialchars($member['Parent_Name']); ?></div>
                <div><span>Mobile Number:</span> <?php echo htmlspecialchars($member['Mobile_Number']); ?></div>
                <div><span>Date of Birth:</span> <?php echo htmlspecialchars($member['Date_Of_Birth']); ?></div>
                <div><span>House No:</span> <?php echo htmlspecialchars($member['House_No']); ?></div>
                <div><span>Address:</span> <?php echo htmlspecialchars($member['Address']); ?></div>
                <div><span>Place:</span> <?php echo htmlspecialchars($member['Place']); ?></div>
                <div><span>Taluk:</span> <?php echo htmlspecialchars($member['Taluk']); ?></div>
                <div><span>District:</span> <?php echo htmlspecialchars($member['District']); ?></div>
                <div><span>Pincode:</span> <?php echo htmlspecialchars($member['Pincode']); ?></div>
            </div>
        <?php else: ?>
            <p>No profile details found for this user.</p>
        <?php endif; ?>
    </div>

</div>
</body>
</html>
