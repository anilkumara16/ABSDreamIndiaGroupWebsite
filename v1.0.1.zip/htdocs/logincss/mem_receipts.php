<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
session_start();
if (!isset($_SESSION['username'])) {
    header("Location: ../login.php");
    exit();
}

require_once "../config.php";
$username = $_SESSION['username'];

// 🔹 Fetch all receipt table names
$tables = [];
$tableSQL = "SELECT Scheme_Name, receipt_table_name FROM ABS_Schemes_Details WHERE Status = 'ACTIVE'";
$tableResult = $conn->query($tableSQL);

if ($tableResult && $tableResult->num_rows > 0) {
    while ($row = $tableResult->fetch_assoc()) {
        if (!empty($row['receipt_table_name'])) {
            $tables[] = [
                'scheme_name' => $row['Scheme_Name'],
                'table_name' => $row['receipt_table_name']
            ];
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Member Receipts</title>
<style>
:root {
    --bg: #f5f5f5;
    --card-bg: #fff;
    --text: #222;
    --primary: #000;
    --accent: #555;
    --border: #ccc;
    --total-bg: #e8f5e9; /* 💚 light green for totals */
}

body {
    font-family: Arial, sans-serif;
    background-color: var(--bg);
    color: var(--text);
    display: flex;
    align-items: center;
    justify-content: center;
    min-height: 100vh;
    margin: 0;
    padding: 15px;
}

/* Main container */
.container {
    position: relative;
    background: var(--card-bg);
    border-radius: 12px;
    box-shadow: 0 0 10px rgba(0,0,0,0.2);
    max-width: 900px;
    width: 100%;
    min-height: 90vh;
    display: flex;
    flex-direction: column;
    justify-content: flex-start;
    padding: 25px;
    box-sizing: border-box;
}

/* Watermark */
.container::before {
    content: "";
    position: absolute;
    top: 50%;
    left: 50%;
    width: 180px;
    height: 180px;
    background: url('logo.webp') no-repeat center center;
    background-size: contain;
    opacity: 0.25;
    transform: translate(-50%, -50%);
    pointer-events: none;
    z-index: 0;
}

.container > * {
    position: relative;
    z-index: 1;
}

/* Table styles */
.table-container {
    margin-top: 20px;
    border: 1px solid var(--border);
    border-radius: 10px;
    overflow: hidden;
    box-shadow: 0 2px 6px rgba(0,0,0,0.1);
}

table {
    width: 100%;
    border-collapse: collapse;
    font-size: 15px;
}

th, td {
    padding: 10px 12px;
    text-align: left;
    border-bottom: 1px solid var(--border);
}

th {
    background: #f0f0f0;
    font-weight: bold;
}

tr:nth-child(even) {
    background: #fafafa;
}

/* 💚 Highlight total row */
.total-row {
    background: var(--total-bg);
    font-weight: bold;
    color: #2e7d32;
}

.scheme-title {
    margin-top: 25px;
    font-size: 18px;
    font-weight: bold;
    color: var(--primary);
}

/* --- Responsive --- */
@media (max-width: 768px) {
    .container {
        padding: 18px;
        border-radius: 10px;
    }

    th, td {
        font-size: 14px;
        padding: 8px 10px;
    }

    .scheme-title {
        font-size: 16px;
    }
}
</style>
</head>
<body>
<div class="container">

    <?php include 'mem_nav.php'; ?>

    <h1>Member Receipts</h1>

    <?php
    if (empty($tables)) {
        echo "<p>No active schemes found.</p>";
    } else {
        foreach ($tables as $tbl) {
            $tableName = $tbl['table_name'];
            $schemeName = $tbl['scheme_name'];

            // Verify if table exists
            $check = $conn->query("SHOW TABLES LIKE '$tableName'");
            if ($check && $check->num_rows > 0) {
                $sql = "SELECT Receipt_Number, Receipt_Amount, Receipt_Date FROM $tableName WHERE Mobile_Number = ?";
                $stmt = $conn->prepare($sql);
                if ($stmt) {
                    $stmt->bind_param("s", $username);
                    $stmt->execute();
                    $result = $stmt->get_result();

                    if ($result && $result->num_rows > 0) {
                        echo "<div class='scheme-title'>{$schemeName}</div>";
                        echo "<div class='table-container'>";
                        echo "<table>";
                        echo "<tr><th>Sl. No</th><th>Receipt Number</th><th>Receipt Amount</th><th>Receipt Date</th></tr>";

                        $sl = 1;
                        $total = 0;
                        while ($row = $result->fetch_assoc()) {
                            $receiptNo = htmlspecialchars($row['Receipt_Number']);
                            $receiptAmt = htmlspecialchars($row['Receipt_Amount']);
                            $receiptDate = htmlspecialchars($row['Receipt_Date']);
                            $total += $row['Receipt_Amount'];

                            echo "<tr>
                                    <td>{$sl}</td>
                                    <td>{$receiptNo}</td>
                                    <td>₹{$receiptAmt}</td>
                                    <td>{$receiptDate}</td>
                                  </tr>";
                            $sl++;
                        }
                        echo "<tr class='total-row'>
                                <td colspan='2'>Total</td>
                                <td colspan='2'>₹" . number_format($total, 2) . "</td>
                              </tr>";
                        echo "</table></div>";
                    }
                    $stmt->close();
                }
            }
        }
    }
    $conn->close();
    ?>

</div>
</body>
</html>
