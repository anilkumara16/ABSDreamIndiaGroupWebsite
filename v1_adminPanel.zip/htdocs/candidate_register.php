<?php
require_once 'config.php';

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

$message = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $slno           = trim($_POST['slno']);
    $candidate_name = trim($_POST['candidate_name']);
    $parent_name    = trim($_POST['parent_name']);
    $address        = trim($_POST['address']);
    $thaluk         = trim($_POST['thaluk']);
    $village        = trim($_POST['village']);
    $pincode        = trim($_POST['pincode']);
    $aadhar         = trim($_POST['aadhar']);
    $mobile         = trim($_POST['mobile']);
    $scheme_name    = trim($_POST['scheme_name']);

    if ($candidate_name && $mobile && $aadhar) {
        $sql = "INSERT INTO lucky_dip_candidates 
                (Slno, Candidate_Name, Parent_Name, Address_Aadhar, Thaluk, Village, Pin_Code, Aadhar_No, Mobile_No, Scheme_Name)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("isssssssss", $slno, $candidate_name, $parent_name, $address, $thaluk, $village, $pincode, $aadhar, $mobile, $scheme_name);
        
        if ($stmt->execute()) {
            $message = "<div class='success'>✅ Candidate registered successfully!</div>";
        } else {
            $message = "<div class='error'>❌ Error inserting data: " . $stmt->error . "</div>";
        }
        $stmt->close();
    } else {
        $message = "<div class='error'>⚠️ Please fill all required fields!</div>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>ABS Lucky Dip Registration</title>
<style>
    * {
        box-sizing: border-box;
    }
    body {
        font-family: "Poppins", sans-serif;
        background: linear-gradient(135deg, #6a11cb, #2575fc);
        margin: 0;
        padding: 15px;
        display: flex;
        justify-content: center;
        align-items: flex-start;
        min-height: 100vh;
    }

    .wrapper {
        background: #fff;
        width: 100%;
        max-width: 480px;
        border-radius: 15px;
        box-shadow: 0 4px 18px rgba(0,0,0,0.15);
        overflow: hidden;
        animation: fadeIn 0.4s ease-in-out;
    }

    @keyframes fadeIn {
        from { opacity: 0; transform: translateY(10px); }
        to { opacity: 1; transform: translateY(0); }
    }

    /* Header */
    .header {
        background: #0d47a1;
        color: #fff;
        text-align: center;
        padding: 15px 10px;
    }
    .header h1 {
        font-size: 1.4rem;
        margin: 0;
        font-weight: 700;
    }
    .header h2 {
        font-size: 1rem;
        margin: 5px 0;
        font-weight: 500;
        font-style: italic;
    }
    .header p {
        margin: 2px 0;
        font-size: 0.8rem;
    }

    /* Form Container */
    .content {
        padding: 20px;
    }
    h3 {
        text-align: center;
        color: #2575fc;
        margin-bottom: 12px;
        font-size: 1.1rem;
    }

    form {
        display: flex;
        flex-direction: column;
        gap: 12px;
    }

    label {
        font-weight: 500;
        font-size: 0.95rem;
    }

    input, textarea {
        width: 100%;
        padding: 10px;
        border: 1px solid #ccc;
        border-radius: 6px;
        font-size: 0.95rem;
        outline: none;
        transition: all 0.2s ease;
    }
    input:focus, textarea:focus {
        border-color: #2575fc;
        box-shadow: 0 0 6px rgba(37,117,252,0.4);
    }

    button {
        background: linear-gradient(135deg, #6a11cb, #2575fc);
        color: #fff;
        border: none;
        padding: 12px 0;
        border-radius: 8px;
        font-size: 1rem;
        cursor: pointer;
        font-weight: 600;
        transition: 0.3s;
    }
    button:hover {
        opacity: 0.9;
        transform: scale(1.02);
    }

    /* Messages */
    .success, .error {
        margin-bottom: 10px;
        padding: 10px;
        border-radius: 5px;
        font-weight: 500;
        text-align: center;
    }
    .success {
        background: #d4edda;
        color: #155724;
    }
    .error {
        background: #f8d7da;
        color: #721c24;
    }

    /* Responsive Adjustments */
    @media (max-width: 480px) {
        .header h1 {
            font-size: 1.2rem;
        }
        .header h2 {
            font-size: 0.9rem;
        }
        .header p {
            font-size: 0.75rem;
        }
        .content {
            padding: 15px;
        }
        button {
            font-size: 0.95rem;
        }
    }
</style>
</head>
<body>

<div class="wrapper">
    <!-- Header Section -->
    <div class="header">
        <h1>ABS DREAM INDIA GROUPS</h1>
        <h2>"Your Trust, Our Movement"</h2>
        <p>#74, ‘Kiran’, Behind RTC Complex, Hospet – 583212</p>
    </div>

    <div class="content">
        <h3>🎟 Lucky Dip Registration Form</h3>
        <?= $message ?>

        <form method="POST">
            <label>Sl No:</label>
            <input type="number" name="slno" required>

            <label>Candidate Name:</label>
            <input type="text" name="candidate_name" required>

            <label>Parent Name:</label>
            <input type="text" name="parent_name" required>

            <label>Address (As per Aadhar):</label>
            <textarea name="address" rows="2" required></textarea>

            <label>Thaluk:</label>
            <input type="text" name="thaluk" required>

            <label>Village:</label>
            <input type="text" name="village" required>

            <label>Pin Code:</label>
            <input type="text" name="pincode" maxlength="6" required>

            <label>Aadhar Number:</label>
            <input type="text" name="aadhar" maxlength="12" required>

            <label>Mobile Number:</label>
            <input type="text" name="mobile" maxlength="10" required>

            <label>Scheme Name:</label>
            <input type="text" name="scheme_name" required>

            <button type="submit">Submit</button>
        </form>
    </div>
</div>

</body>
</html>
