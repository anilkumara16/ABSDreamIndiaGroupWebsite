<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
session_start();
require_once 'config.php';

if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit();
}

$message = "";
$member = null;
$clearForm = false;

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $created_by = $_SESSION['username'] ?? 'Unknown';

    if (isset($_POST['search'])) {
        $aadhar = trim($_POST['aadhar']);
        $sql = "SELECT * FROM ABS_customer_details WHERE Aadhar_Number = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("s", $aadhar);
        $stmt->execute();
        $result = $stmt->get_result();
        if ($result->num_rows > 0) {
            $member = $result->fetch_assoc();
        } else {
            $message = "❌ No record found for the given Aadhar number.";
        }
        $stmt->close();
    } elseif (isset($_POST['update'])) {
        $aadhar = trim($_POST['aadhar']);
        $fullname = trim($_POST['fullname']);
        $parent = trim($_POST['parent']);
        $mobile = trim($_POST['mobile']);
        $dob = trim($_POST['dob']);
        $house = trim($_POST['house']);
        $address = trim($_POST['address']);
        $place = trim($_POST['place']);
        $taluk = trim($_POST['taluk']);
        $district = trim($_POST['district']);
        $pincode = trim($_POST['pincode']);

        if (strtotime($dob) > time()) {
            $message = "❌ Date of Birth cannot be a future date.";
        } else {
            $sql = "UPDATE ABS_customer_details 
                    SET Full_Name=?, Parent_Name=?, Mobile_Number=?, Date_of_Birth=?, 
                        House_No=?, Address=?, Place=?, Taluk=?, District=?, Pincode=?, Created_By=?
                    WHERE Aadhar_Number=?";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param(
                "ssssssssssss",
                $fullname, $parent, $mobile, $dob, $house, $address,
                $place, $taluk, $district, $pincode, $created_by, $aadhar
            );
            if ($stmt->execute()) {
                $message = "✅ Member details updated successfully!";
                $clearForm = true;
            } else {
                $message = "❌ Error updating record: " . $stmt->error;
            }
            $stmt->close();
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>View / Update Member</title>
<style>
:root {
    --bg: #f5f5f5;
    --card-bg: #fff;
    --text: #222;
    --primary: #000;
    --accent: #555;
    --border: #ccc;
    --danger: #c00;
}

body {
    font-family: Arial, sans-serif;
    background-color: var(--bg);
    color: var(--text);
    display: flex;
    align-items: flex-start;
    justify-content: center;
    min-height: 100vh;
    padding: 15px;
}

.container {
    background: var(--card-bg);
    border-radius: 12px;
    box-shadow: 0 0 10px rgba(0,0,0,0.2);
    max-width: 800px;
    width: 100%;
    padding: 25px;
    box-sizing: border-box;
}

h2 {
    text-align: center;
    margin-bottom: 20px;
    color: var(--primary);
}

.msg {
    text-align: center;
    margin-bottom: 10px;
    font-weight: bold;
}
.msg.error { color: red; }
.msg.success { color: green; }

form {
    display: grid;
    grid-template-columns: 1fr;
    gap: 12px;
}

label {
    font-weight: bold;
    margin-bottom: 4px;
}

input, textarea {
    width: 100%;
    padding: 8px;
    border: 1px solid var(--border);
    border-radius: 6px;
    font-size: 15px;
    box-sizing: border-box;
}
textarea { resize: none; }

button {
    background: var(--primary);
    color: #fff;
    border: none;
    padding: 10px;
    border-radius: 6px;
    cursor: pointer;
    font-size: 16px;
    transition: 0.3s;
}
button:hover { background: var(--accent); }

/* 🔹 Updated Search Section */
.search-box {
    background: #eee;
    border: 1px solid #ccc;
    border-radius: 10px;
    padding: 15px 20px;
    margin-bottom: 25px;

    display: grid;
    grid-template-columns: 2fr 1fr 1fr;
    gap: 15px;
    align-items: end;
}

.search-box label {
    font-weight: bold;
    display: block;
    margin-bottom: 5px;
}

.search-box input[type="text"] {
    width: 100%;
    padding: 8px;
    border: 1px solid #bbb;
    border-radius: 6px;
    box-sizing: border-box;
}

.search-box button {
    width: 100%;
    border: none;
    padding: 10px 15px;
    border-radius: 6px;
    font-weight: bold;
    cursor: pointer;
}

.search-box button[type="submit"] {
    background: #28a745;
    color: white;
}
.search-box button[type="submit"]:hover {
    background: #218838;
}

.clear-btn {
    background: #dc3545;
    color: white;
}
.clear-btn:hover {
    background: #c82333;
}

@media (max-width: 768px) {
    .container { padding: 18px; }
    button, input, textarea { font-size: 16px; }
    .search-box {
        grid-template-columns: 1fr;
    }
}
</style>

</head>
<body>
<div class="container">

    <?php include 'nav.php'; ?>

    <h2>View / Update Member Details</h2>

    <?php if ($message): ?>
        <div class="msg <?php echo (strpos($message, '❌') !== false) ? 'error' : 'success'; ?>">
            <?php echo htmlspecialchars($message); ?>
        </div>
    <?php endif; ?>

    <!-- Search Form -->
    <form method="POST" id="searchForm">
        <div class="search-box">
            <div>
                <label for="aadhar">Enter Aadhar Number</label>
                <input type="text" name="aadhar" id="aadhar" maxlength="12" required 
                    value="<?php echo isset($_POST['aadhar']) && !$clearForm ? htmlspecialchars($_POST['aadhar']) : ''; ?>">
            </div>
            <button type="submit" name="search">🔍 Search</button>
            <button type="button" class="clear-btn" onclick="window.location.href='vu_member_details.php'">❌ Clear</button>
        </div>
    </form>

    <?php if ($member && !$clearForm): ?>
        <hr>
        <form method="POST">
            <input type="hidden" name="aadhar" value="<?php echo htmlspecialchars($member['Aadhar_Number']); ?>">

            <label>Full Name</label>
            <input type="text" name="fullname" value="<?php echo htmlspecialchars($member['Full_Name']); ?>" required>

            <label>Parent Name</label>
            <input type="text" name="parent" value="<?php echo htmlspecialchars($member['Parent_Name']); ?>" required>

            <label>Mobile Number</label>
            <input type="text" name="mobile" maxlength="10" pattern="[0-9]{10}" value="<?php echo htmlspecialchars($member['Mobile_Number']); ?>" required>

            <label>Date of Birth</label>
            <input type="date" name="dob" value="<?php echo htmlspecialchars($member['Date_of_Birth']); ?>" max="<?php echo date('Y-m-d'); ?>" required>

            <label>House No</label>
            <input type="text" name="house" value="<?php echo htmlspecialchars($member['House_No']); ?>" required>

            <label>Address</label>
            <textarea name="address" rows="2" required><?php echo htmlspecialchars($member['Address']); ?></textarea>

            <label>Place</label>
            <input type="text" name="place" value="<?php echo htmlspecialchars($member['Place']); ?>" required>

            <label>Taluk</label>
            <input type="text" name="taluk" value="<?php echo htmlspecialchars($member['Taluk']); ?>" required>

            <label>District</label>
            <input type="text" name="district" value="<?php echo htmlspecialchars($member['District']); ?>" required>

            <label>Pincode</label>
            <input type="text" name="pincode" maxlength="6" pattern="[0-9]{6}" value="<?php echo htmlspecialchars($member['Pincode']); ?>" required>

            <button type="submit" name="update">Update Details</button>
        </form>
    <?php endif; ?>
</div>

<?php if ($clearForm): ?>
<script>
    setTimeout(() => {
        window.location.href = "vu_member_details.php";
    }, 1500);
</script>
<?php endif; ?>

</body>
</html>
