<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
session_start();
if (!isset($_SESSION['username'])) {
    header("Location: ../login.php");
    exit();
}

include '../config.php';
$username = $_SESSION['username'];

// Fetch active schemes
$schemes = [];
$query = "SELECT Scheme_Name, scheme_table_name, Dip_Info_table_name, start_date, end_date, Dip_Day 
          FROM ABS_Schemes_Details 
          WHERE Status='ACTIVE' 
          ORDER BY Scheme_Name";
$res = $conn->query($query);
while ($row = $res->fetch_assoc()) {
    $schemes[] = $row;
}

$members = [];
$selectedMember = null;
$message = "";

// Handle search
if (isset($_POST['search'])) {
    $criteria = "Scheme_Card_Number"; // fixed default search by Scheme_Card_Number
    $value = trim($_POST['value'] ?? '');
    $scheme = $_POST['scheme'] ?? '';

    $schemeTable = '';
    foreach ($schemes as $s) {
        if ($s['Scheme_Name'] === $scheme) {
            $schemeTable = $s['scheme_table_name'];
            break;
        }
    }

    if (!empty($schemeTable) && $value !== '') {
        $sql = "SELECT Scheme_Card_Number, Full_Name, Parent_Name, Winning_Status FROM $schemeTable WHERE $criteria = ?";
        if ($stmt = $conn->prepare($sql)) {
            $stmt->bind_param("s", $value);
            $stmt->execute();
            $result = $stmt->get_result();

            if ($result->num_rows > 1) {
                while ($row = $result->fetch_assoc()) {
                    $members[] = $row;
                }
            } elseif ($result->num_rows === 1) {
                $row = $result->fetch_assoc();
                $cardNo = $row['Scheme_Card_Number'];

                $fullSql = "SELECT * FROM $schemeTable WHERE Scheme_Card_Number = ? LIMIT 1";
                if ($stmt2 = $conn->prepare($fullSql)) {
                    $stmt2->bind_param("s", $cardNo);
                    $stmt2->execute();
                    $selectedMember = $stmt2->get_result()->fetch_assoc();
                    $stmt2->close();
                } else {
                    $message = "Database error while retrieving full member record.";
                }
            } else {
                $message = "❌ No record found for given Scheme Card Number.";
            }

            $stmt->close();
        } else {
            $message = "Database error while searching.";
        }
    } else {
        $message = "❌ Please select scheme and enter Scheme Card Number.";
    }
}

// Handle member selection (from multiple-result table)
if (isset($_POST['select_member'])) {
    $scheme = $_POST['scheme'] ?? '';
    $Scheme_Card_Number = $_POST['Scheme_Card_Number'] ?? '';

    $schemeTable = '';
    foreach ($schemes as $s) {
        if ($s['Scheme_Name'] === $scheme) {
            $schemeTable = $s['scheme_table_name'];
            break;
        }
    }

    if (!empty($schemeTable) && $Scheme_Card_Number !== '') {
        $stmt = $conn->prepare("SELECT * FROM $schemeTable WHERE Scheme_Card_Number=? LIMIT 1");
        $stmt->bind_param("s", $Scheme_Card_Number);
        $stmt->execute();
        $selectedMember = $stmt->get_result()->fetch_assoc();
        $stmt->close();
    } else {
        $message = "❌ Invalid scheme or scheme card number.";
    }
}

// Handle Lucky Dip entry (same as before)
if (isset($_POST['final_confirm_insert'])) {
    $scheme = $_POST['scheme'] ?? '';
    $Scheme_Card_Number = $_POST['Scheme_Card_Number'] ?? '';
    $Category = $_POST['Category'] ?? '';
    $Dip_Month = $_POST['Dip_Month'] ?? '';
    $CreatedBy = $_SESSION['username'];
    $CreatedAt = date('Y-m-d H:i:s');

    $schemeTable = '';
    $dipInfoTable = '';
    $dipDay = 15;
    $start_date = null;
    $end_date = null;

    foreach ($schemes as $s) {
        if ($s['Scheme_Name'] === $scheme) {
            $schemeTable = $s['scheme_table_name'];
            $dipInfoTable = $s['Dip_Info_table_name'];
            $dipDay = !empty($s['Dip_Day']) ? intval($s['Dip_Day']) : 15;
            $start_date = strtotime($s['start_date']);
            $end_date = strtotime($s['end_date']);
            break;
        }
    }

    if (empty($schemeTable) || empty($dipInfoTable)) {
        $message = "❌ Invalid scheme selection.";
    } elseif ($Scheme_Card_Number === '' || $Category === '' || $Dip_Month === '') {
        $message = "❌ All Lucky Dip fields are mandatory.";
    } else {
        $selected_month = strtotime("01-" . $Dip_Month);
        $current_date = strtotime(date('Y-m-01'));

        if (!($selected_month >= $start_date && $selected_month <= $current_date) && !($selected_month === $end_date)) {
            $message = "⚠️ Dip Month must be between scheme start and current month, or equal to scheme end month.";
        } else {
            $stmt = $conn->prepare("SELECT * FROM $schemeTable WHERE Scheme_Card_Number=? LIMIT 1");
            $stmt->bind_param("s", $Scheme_Card_Number);
            $stmt->execute();
            $memberData = $stmt->get_result()->fetch_assoc();
            $stmt->close();

            if (!$memberData) {
                $message = "❌ Member not found in scheme table.";
            } else {
                $Win_Date = date('Y-m-d', strtotime($dipDay . ' ' . $Dip_Month));

                $check = $conn->prepare("SELECT 1 FROM $dipInfoTable WHERE Scheme_Card_Number=? AND Win_Date=?");
                $check->bind_param("ss", $Scheme_Card_Number, $Win_Date);
                $check->execute();
                $dup = $check->get_result();
                $check->close();

                if ($dup->num_rows > 0) {
                    $message = "⚠️ This member already has a Lucky Dip entry for " . date('d-M-Y', strtotime($Win_Date)) . ".";
                } else {
                    $insert = $conn->prepare("INSERT INTO $dipInfoTable 
                        (Scheme_Card_Number, Aadhar_Number, Full_Name, Parent_Name, Mobile_Number, Date_Of_Birth,
                         House_No, Address, Place, Taluk, District, Pincode, Winning_Status, Winning_Category, Win_Date, Created_By, Created_At)
                         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'WINNER', ?, ?, ?, ?)");

                    $insert->bind_param("ssssssssssssssss",
                        $memberData['Scheme_Card_Number'],
                        $memberData['Aadhar_Number'],
                        $memberData['Full_Name'],
                        $memberData['Parent_Name'],
                        $memberData['Mobile_Number'],
                        $memberData['Date_Of_Birth'],
                        $memberData['House_No'],
                        $memberData['Address'],
                        $memberData['Place'],
                        $memberData['Taluk'],
                        $memberData['District'],
                        $memberData['Pincode'],
                        $Category,
                        $Win_Date,
                        $CreatedBy,
                        $CreatedAt
                    );

                    $update = $conn->prepare("UPDATE $schemeTable SET Winning_Status='WINNER', Winning_Category=?, Win_Date=? WHERE Scheme_Card_Number=?");
                    $update->bind_param("sss", $Category, $Win_Date, $Scheme_Card_Number);

                    $insOk = $insert->execute();
                    $updOk = $update->execute();
                    $insert->close();
                    $update->close();

                    if ($insOk && $updOk) {
    					$message = "✅ Lucky Dip entry added successfully for " . date('d-M-Y', strtotime($Win_Date)) . "!";

    					// ✅ Reset all form data so nothing is displayed after success
    					$_POST = [];
    					$selectedMember = null;
    					$members = [];
						} else {
    					$message = "❌ Error adding Lucky Dip entry.";
					}
                }
            }
        }
    }
}
?>

<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Lucky Dip Entry</title>
<style>
body { font-family: Arial; background: #f5f5f5; margin: 0; padding: 20px; }
.container { background: #fff; border-radius: 12px; box-shadow: 0 0 8px rgba(0,0,0,0.2); max-width: 800px; margin: auto; padding: 25px; }
h2 { text-align: center; margin-top: 0; }
.search-section { background: #eee; border: 1px solid #ccc; border-radius: 10px; padding: 15px 20px; margin-bottom: 25px; }
.search-title { background: #ddd; padding: 8px 12px; font-weight: bold; border-radius: 6px; margin-bottom: 15px; }
.search-grid { display: grid; grid-template-columns: repeat(3, 1fr); gap: 15px; align-items: end; }
.search-buttons { display: flex; justify-content: flex-start; gap: 10px; }
label { font-weight: bold; display: block; margin-bottom: 5px; }
select, input[type="text"] { width: 100%; padding: 8px; border: 1px solid #bbb; border-radius: 6px; box-sizing: border-box; }
button { border: none; padding: 10px 15px; border-radius: 6px; font-weight: bold; cursor: pointer; }
.btn-search { background: #28a745; color: #fff; }
.btn-clear { background: #dc3545; color: #fff; }
.btn-select { background: #28a745; color: #fff; border: none; padding: 6px 12px; border-radius: 5px; cursor: pointer; }
.status-runner { background: yellow; padding: 2px 6px; border-radius: 4px; font-weight: bold; }
.status-winner { background: lightgreen; padding: 2px 6px; border-radius: 4px; font-weight: bold; }
.details, .receipt-section { background: #fafafa; border: 1px solid #ddd; border-radius: 8px; padding: 15px; margin-bottom: 20px; }
.member-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 20px; }
.receipt-grid { display: grid; grid-template-columns: repeat(3, 1fr); gap: 15px; }
@media (max-width: 768px) { .search-grid, .member-grid, .receipt-grid { grid-template-columns: 1fr; } }
</style>
<script>
function clearForm() {
    window.location.href = "add_luckydip.php";
}
function selectMember(cardNo) {
    const form = document.createElement('form');
    form.method = 'POST';
    form.action = '';
    form.innerHTML = `
        <input type="hidden" name="scheme" value="<?= htmlspecialchars($_POST['scheme'] ?? '') ?>">
        <input type="hidden" name="Scheme_Card_Number" value="${cardNo}">
        <input type="hidden" name="select_member" value="1">
    `;
    document.body.appendChild(form);
    form.submit();
}
</script>
</head>
<body>
<div class="container">
    <?php include 'nav.php'; ?>
    <h2>Lucky Dip Entry</h2>

    <form method="post" class="search-section">
        <div class="search-title">🔍 Search Member</div>
        <div class="search-grid">
            <div>
                <label>Scheme:</label>
                <select name="scheme" required>
                    <option value="">Select</option>
                    <?php foreach ($schemes as $scheme) { ?>
                        <option value="<?= htmlspecialchars($scheme['Scheme_Name']); ?>" 
                            <?= (isset($_POST['scheme']) && $_POST['scheme']==$scheme['Scheme_Name']) ? 'selected' : ''; ?>>
                            <?= htmlspecialchars($scheme['Scheme_Name']); ?>
                        </option>
                    <?php } ?>
                </select>
            </div>
            <div>
                <label>Scheme Card Number:</label>
                <input type="text" name="value" value="<?= htmlspecialchars($_POST['value'] ?? ''); ?>" required>
            </div>
            <div class="search-buttons">
                <button type="submit" name="search" class="btn-search">Search</button>
                <button type="button" class="btn-clear" onclick="clearForm()">Clear</button>
            </div>
        </div>
    </form>

    <?php if ($message): ?>
        <div style="text-align:center;font-weight:bold;<?= strpos($message,'✅') !== false ? 'color:green' : 'color:red'; ?>">
            <?= $message; ?>
        </div>
    <?php endif; ?>

    <?php if (count($members) > 1): ?>
        <table border="1" width="100%" cellspacing="0" cellpadding="6" style="margin-top:20px;border-collapse:collapse;text-align:center;">
            <tr style="background:#f0f0f0;">
                <th>Scheme Card Number</th>
                <th>Full Name</th>
                <th>Parent Name</th>
                <th>Winning Status</th>
                <th>Select</th>
            </tr>
            <?php foreach ($members as $m): 
                $isWinner = (isset($m['Winning_Status']) && $m['Winning_Status'] === 'WINNER');
                $statusClass = $m['Winning_Status'] === 'WINNER' ? 'status-winner' : ($m['Winning_Status'] === 'RUNNER' ? 'status-runner' : '');
            ?>
                <tr <?= $isWinner ? "style='background:#f8f8f8;color:#999;'" : ""; ?>>
                    <td><?= htmlspecialchars($m['Scheme_Card_Number']); ?></td>
                    <td><?= htmlspecialchars($m['Full_Name']); ?></td>
                    <td><?= htmlspecialchars($m['Parent_Name']); ?></td>
                    <td><span class="<?= $statusClass ?>"><?= htmlspecialchars($m['Winning_Status']); ?></span></td>
                    <td>
                        <button type="button" class="btn-select" onclick="selectMember('<?= $m['Scheme_Card_Number']; ?>')" <?= $isWinner ? 'disabled' : ''; ?>>Select</button>
                    </td>
                </tr>
            <?php endforeach; ?>
        </table>
    <?php endif; ?>

    <?php if ($selectedMember): ?>
        <div class="details">
            <h3>Member Details</h3>
            <div class="member-grid">
                <div>
                    <p><strong>Scheme Card:</strong> <?= htmlspecialchars($selectedMember['Scheme_Card_Number']); ?></p>
                    <p><strong>Aadhar:</strong> <?= htmlspecialchars($selectedMember['Aadhar_Number']); ?></p>
                    <p><strong>Full Name:</strong> <?= htmlspecialchars($selectedMember['Full_Name']); ?></p>
                    <p><strong>Parent:</strong> <?= htmlspecialchars($selectedMember['Parent_Name']); ?></p>
                    <p><strong>Mobile:</strong> <?= htmlspecialchars($selectedMember['Mobile_Number']); ?></p>
                    <p><strong>DOB:</strong> <?= htmlspecialchars($selectedMember['Date_Of_Birth']); ?></p>
                </div>
                <div>
                    <p><strong>Address:</strong> <?= htmlspecialchars($selectedMember['Address']); ?></p>
                    <p><strong>Place:</strong> <?= htmlspecialchars($selectedMember['Place']); ?></p>
                    <p><strong>Taluk:</strong> <?= htmlspecialchars($selectedMember['Taluk']); ?></p>
                    <p><strong>District:</strong> <?= htmlspecialchars($selectedMember['District']); ?></p>
                    <p><strong>Pincode:</strong> <?= htmlspecialchars($selectedMember['Pincode']); ?></p>
                    <p><strong>Winning Status:</strong>
                        <?php 
                        $statusClass = $selectedMember['Winning_Status'] === 'WINNER' ? 'status-winner' : 
                                      ($selectedMember['Winning_Status'] === 'RUNNER' ? 'status-runner' : '');
                        ?>
                        <span class="<?= $statusClass ?>"><?= htmlspecialchars($selectedMember['Winning_Status']); ?></span>
                    </p>
                </div>
            </div>
        </div>

        <?php if (($selectedMember['Winning_Status'] ?? '') !== 'WINNER'): ?>
            <div class="receipt-section">
                <h3>Enter Lucky Dip Information</h3>
                <form method="post">
                    <input type="hidden" name="scheme" value="<?= htmlspecialchars($_POST['scheme'] ?? '') ?>">
                    <input type="hidden" name="Scheme_Card_Number" value="<?= htmlspecialchars($selectedMember['Scheme_Card_Number']); ?>">

                    <div class="receipt-grid">
                        <div>
                            <label>Category:</label>
                            <select name="Category" required>
                                <option value="">Select</option>
                                <?php for ($i=1;$i<=10;$i++): ?>
                                    <option value="Category <?= $i ?>">Category <?= $i ?></option>
                                <?php endfor; ?>
                            </select>
                        </div>
                        <div>
                            <label>Dip Month:</label>
                            <select name="Dip_Month" required>
                                <option value="">Select</option>
                                <?php 
                                $schemeNameForOptions = $_POST['scheme'] ?? '';
                                foreach ($schemes as $s) {
                                    if ($s['Scheme_Name'] === $schemeNameForOptions) {
                                        $start = strtotime($s['start_date']);
                                        $end = strtotime($s['end_date']);
                                        $current = strtotime(date('Y-m-01'));
                                        while ($start <= $end) {
                                            $monthLabel = date("M-Y", $start);
                                            if ($start <= $current || (date("Y-m", $start) === date("Y-m", $end) && date("Y-m", $end) === date("Y-m", time()))) {
                                                echo "<option value='" . htmlspecialchars($monthLabel) . "'>" . htmlspecialchars($monthLabel) . "</option>";
                                            }
                                            $start = strtotime("+1 month", $start);
                                        }
                                    }
                                }
                                ?>
                            </select>
                        </div>
                        <div style="display:flex;align-items:end;">
                            <button type="submit" name="final_confirm_insert" class="btn-search">Submit Lucky Dip</button>
                        </div>
                    </div>
                </form>
            </div>
        <?php else: ?>
            <div style="color:red;text-align:center;">🏆 Already marked as WINNER.</div>
        <?php endif; ?>
    <?php endif; ?>
</div>
</body>
</html>
