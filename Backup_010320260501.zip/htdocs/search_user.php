<?php
require_once "config.php";

$mobile=$_POST['mobile'];

$stmt=$conn->prepare("SELECT Full_Name FROM ABS_customer_details WHERE Mobile_Number=?");
$stmt->bind_param("s",$mobile);
$stmt->execute();
$result=$stmt->get_result();

if($result->num_rows>0){
$row=$result->fetch_assoc();
echo json_encode(["status"=>"found","name"=>$row['Full_Name']]);
}else{
echo json_encode(["status"=>"not_found"]);
}
?>