<?php
// ======================================================
// USE EXISTING DATABASE CONNECTION
// ======================================================
require_once "config.php";

// ======================================================
// GET VALUES
// ======================================================
$referrer_id   = trim($_POST['search_mobile']);   // mobile stored here
$referrer_name = trim($_POST['customer_name']);   // name stored here

$referred_name    = trim($_POST['referred_name']);
$referred_mobile  = trim($_POST['referred_mobile']);
$referred_email   = trim($_POST['referred_email']);
$pan_card         = strtoupper(trim($_POST['pan_card']));
$aadhaar_number   = trim($_POST['aadhaar_number']);

// ======================================================
// VALIDATION
// ======================================================
if (
    empty($referrer_id) || empty($referrer_name) ||
    empty($referred_name) || empty($referred_mobile) ||
    empty($pan_card) || empty($aadhaar_number)
) {
    die("All required fields must be filled.");
}

if (!preg_match('/^[6-9][0-9]{9}$/', $referrer_id)) {
    die("Invalid Referrer Mobile.");
}

if (!preg_match('/^[6-9][0-9]{9}$/', $referred_mobile)) {
    die("Invalid Referred Mobile.");
}

if (!preg_match('/^[A-Z]{5}[0-9]{4}[A-Z]{1}$/', $pan_card)) {
    die("Invalid PAN Number.");
}

if (!preg_match('/^[0-9]{12}$/', $aadhaar_number)) {
    die("Invalid Aadhaar Number.");
}

// ======================================================
// INSERT DATA
// ======================================================
$stmt = $conn->prepare("
    INSERT INTO ABS_Referral_Details
    (referrer_id, referrer_name, referred_name, referred_mobile, referred_email, pan_card, aadhaar_number)
    VALUES (?, ?, ?, ?, ?, ?, ?)
");

$stmt->bind_param(
    "sssssss",
    $referrer_id,
    $referrer_name,
    $referred_name,
    $referred_mobile,
    $referred_email,
    $pan_card,
    $aadhaar_number
);

if ($stmt->execute()) {
    echo "Referral Added Successfully.";
} else {
    if ($conn->errno == 1062) {
        echo "Duplicate Entry: Already exists.";
    } else {
        echo "Error: " . $conn->error;
    }
}

$stmt->close();
$conn->close();
?>