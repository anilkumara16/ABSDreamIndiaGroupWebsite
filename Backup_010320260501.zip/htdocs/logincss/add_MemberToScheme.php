<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
session_start();

if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit();
}

require_once "config.php"; // DB connection

$message = "";
$customer = null;
$created_by = $_SESSION['username'];
$schemes = [];

// 🔹 Preload active schemes
$schemeSQL = "SELECT id, Scheme_Name, scheme_table_name 
              FROM ABS_Schemes_Details 
              WHERE Status = 'ACTIVE' 
              ORDER BY Scheme_Name";
$schemeResult = $conn->query($schemeSQL);
if ($schemeResult && $schemeResult->num_rows > 0) {
    $schemes = $schemeResult->fetch_all(MYSQLI_ASSOC);
}

// Handle Clear button (redirect to self to clear POST state)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['clear'])) {
    header("Location: add_MemberToScheme.php");
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    // 🔹 Step 1: Search for Aadhar Number
    if (isset($_POST['search'])) {
        $aadhar = trim($_POST['aadhar']);

        // Validate Aadhar - must be 12 digits numeric only
        if (!preg_match('/^[0-9]{12}$/', $aadhar)) {
            $message = "⚠️ Aadhar Number must be exactly 12 digits!";
        } else {
            $sql = "SELECT * FROM ABS_customer_details WHERE Aadhar_Number = ?";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("s", $aadhar);
            $stmt->execute();
            $result = $stmt->get_result();
            $customer = $result->fetch_assoc();

            if (!$customer) {
                $message = "❌ Member not found!";
            }
        }
    }

    // 🔹 Step 2: Insert Gold Scheme Details
    if (isset($_POST['add_scheme'])) {
        $aadhar = $_POST['aadhar'];
        $scheme_no = trim($_POST['scheme_no']);
        $scheme_id = $_POST['scheme_id'];
        $created_at = date("Y-m-d H:i:s");

        if (!preg_match('/^[0-9]+$/', $scheme_no)) {
            $message = "⚠️ Scheme Card Number must contain only numbers!";
        } elseif (empty($scheme_id)) {
            $message = "⚠️ Please select a scheme!";
        } else {
            $schemeInfoSQL = "SELECT Scheme_Name, scheme_table_name 
                              FROM ABS_Schemes_Details 
                              WHERE id = ?";
            $stmtScheme = $conn->prepare($schemeInfoSQL);
            $stmtScheme->bind_param("i", $scheme_id);
            $stmtScheme->execute();
            $schemeInfo = $stmtScheme->get_result()->fetch_assoc();

            if (!$schemeInfo) {
                $message = "❌ Invalid scheme selected!";
            } else {
                $schemeTable = $schemeInfo['scheme_table_name'];

                $checkSQL = "SELECT Scheme_Card_Number FROM $schemeTable WHERE Scheme_Card_Number = ?";
                $checkStmt = $conn->prepare($checkSQL);
                $checkStmt->bind_param("s", $scheme_no);
                $checkStmt->execute();
                $checkResult = $checkStmt->get_result();

                if ($checkResult->num_rows > 0) {
                    $message = "⚠️ Scheme Card Number already allotted to someone!";
                } else {
                    $sql = "SELECT * FROM ABS_customer_details WHERE Aadhar_Number = ?";
                    $stmt = $conn->prepare($sql);
                    $stmt->bind_param("s", $aadhar);
                    $stmt->execute();
                    $customer = $stmt->get_result()->fetch_assoc();

                    if ($customer) {
                        $insertSQL = "INSERT INTO $schemeTable 
                        (Scheme_Card_Number, Aadhar_Number, Full_Name, Parent_Name, Mobile_Number, Date_Of_Birth,
                         House_No, Address, Place, Taluk, District, Pincode, Created_By, Created_At)
                        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

                        $stmt2 = $conn->prepare($insertSQL);
                        $stmt2->bind_param(
                            "isssssssssssss",
                            $scheme_no,
                            $customer['Aadhar_Number'],
                            $customer['Full_Name'],
                            $customer['Parent_Name'],
                            $customer['Mobile_Number'],
                            $customer['Date_of_Birth'],
                            $customer['House_No'],
                            $customer['Address'],
                            $customer['Place'],
                            $customer['Taluk'],
                            $customer['District'],
                            $customer['Pincode'],
                            $created_by,
                            $created_at
                        );
                        $stmt2->execute();

                        $message = "✅ Scheme details added successfully!";
                        $customer = null;
                    } else {
                        $message = "❌ Member not found!";
                    }
                }
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Add Member to Scheme</title>
<style>
body {
    font-family: Arial, sans-serif;
    background: #f5f5f5;
    color: #222;
    margin: 0;
    padding: 20px;
    display: flex;
    justify-content: center;
}

.container {
    background: #fff;
    border-radius: 12px;
    box-shadow: 0 0 8px rgba(0,0,0,0.2);
    max-width: 900px;
    width: 100%;
    padding: 25px;
    box-sizing: border-box;
    position: relative;
    overflow-y: auto;
}

h2 {
    text-align: center;
    margin-top: 0;
}

/* 🔹 Message Box */
.message {
    text-align: center;
    font-weight: bold;
    margin-top: 10px;
    padding: 10px;
    border-radius: 6px;
}
.message.success { color: green; background: #eaffea; border: 1px solid #b5e7b5; }
.message.error { color: red; background: #ffeaea; border: 1px solid #e7b5b5; }

/* 🔹 Search Section */
.search-section {
    background: #eee;
    border: 1px solid #ccc;
    border-radius: 10px;
    padding: 15px 20px;
    margin-bottom: 25px;

    /* ✅ Make entire form a grid for single-row layout */
    display: grid;
    grid-template-columns: 2fr 1fr 1fr;
    gap: 15px;
    align-items: end;
}

.search-section label {
    font-weight: bold;
    display: block;
    margin-bottom: 5px;
}

.search-section input[type="text"] {
    width: 100%;
    padding: 8px;
    border: 1px solid #bbb;
    border-radius: 6px;
    box-sizing: border-box;
}

.search-section button {
    width: 100%;
    border: none;
    padding: 10px 15px;
    border-radius: 6px;
    font-weight: bold;
    cursor: pointer;
}

.search-btn {
    background: #28a745;
    color: white;
}
.search-btn:hover {
    background: #218838;
}
.clear-btn {
    background: #dc3545;
    color: white;
}
.clear-btn:hover {
    background: #c82333;
}

@media (max-width: 768px) {
    .search-section {
        grid-template-columns: 1fr;
    }
}

/* 🔹 Customer Details Section */
.customer-details {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 6px; /* reduced from 12px */
    background: #fafafa;
    border: 1px solid #ddd;
    border-radius: 8px;
    padding: 10px 12px; /* reduced from 15px */
    margin-top: 15px; /* slightly tighter spacing above */
}

.customer-details p {
    margin: 3px 0; /* reduced vertical spacing */
    border-bottom: 1px solid #eee;
    padding-bottom: 2px; /* less padding under each line */
}

/* 🔹 Scheme Section */
.scheme-section {
    border-top: 2px solid #ccc;
    margin-top: 20px;
    padding-top: 15px;
    display: grid;
    grid-template-columns: 1fr 1fr 1fr;
    gap: 15px;
    margin-top: 25px;
}
@media (max-width: 768px) {
    .scheme-section {
        grid-template-columns: 1fr;
    }
}

/* ✅ Added styling for scheme dropdown, input, and Add button */
.scheme-section select,
.scheme-section input[type="text"] {
    width: 100%;
    padding: 8px 10px;
    border: 1px solid #bbb;
    border-radius: 6px;
    box-sizing: border-box;
    font-size: 14px;
    transition: all 0.2s ease-in-out;
}

.scheme-section select:focus,
.scheme-section input[type="text"]:focus {
    border-color: #007bff;
    outline: none;
    box-shadow: 0 0 4px rgba(0,123,255,0.4);
}

.scheme-section button.search-btn {
    background: #007bff;
    color: #fff;
    font-weight: bold;
    border: none;
    border-radius: 6px;
    padding: 10px 15px;
    width: 100%;
    cursor: pointer;
    transition: background 0.3s ease;
}

.scheme-section button.search-btn:hover {
    background: #0056b3;
}
</style>




</head>
<body>
<div class="container">
    <?php include 'nav.php'; ?>
	<img src="logo.webp" alt="ABS Dream India Logo" 
     style="width:180px; height:auto; max-width:100%; display:block; margin:0 auto;">

    <h2>Add Member to Scheme</h2>

    <?php if ($message): ?>
        <div class="message"><?= htmlspecialchars($message); ?></div>
    <?php endif; ?>

    <!-- 🔹 1×3 Aadhar Search Section -->
    <form method="post" class="search-section">
        <div>
            <label>Enter Aadhar Number:</label>
            <input type="text" name="aadhar" maxlength="12" minlength="12" pattern="[0-9]{12}" 
                   title="Enter exactly 12 digits" required 
                   value="<?php echo isset($_POST['aadhar']) ? htmlspecialchars($_POST['aadhar']) : ''; ?>">
        </div>

        <button type="submit" name="search" class="search-btn">🔍 Search</button>

        <!-- Clear is now a submit button handled by PHP to redirect and clear POST -->
        <button type="submit" name="clear" class="clear-btn">🧹 Clear</button>
    </form>

    <?php if ($customer): ?>
        <h3>Member Details</h3>
        <div class="customer-details">
            <p><strong>Aadhar:</strong> <?= htmlspecialchars($customer['Aadhar_Number']); ?></p>
            <p><strong>Name:</strong> <?= htmlspecialchars($customer['Full_Name']); ?></p>
            <p><strong>Parent:</strong> <?= htmlspecialchars($customer['Parent_Name']); ?></p>
            <p><strong>Mobile:</strong> <?= htmlspecialchars($customer['Mobile_Number']); ?></p>
            <p><strong>DOB:</strong> <?= htmlspecialchars($customer['Date_of_Birth']); ?></p>
            <p><strong>House:</strong> <?= htmlspecialchars($customer['House_No']); ?></p>
            <p><strong>Address:</strong> <?= htmlspecialchars($customer['Address']); ?></p>
            <p><strong>Place:</strong> <?= htmlspecialchars($customer['Place']); ?></p>
            <p><strong>Taluk:</strong> <?= htmlspecialchars($customer['Taluk']); ?></p>
            <p><strong>District:</strong> <?= htmlspecialchars($customer['District']); ?></p>
            <p><strong>Pincode:</strong> <?= htmlspecialchars($customer['Pincode']); ?></p>
        </div>

        <form method="post" onsubmit="return confirmAddScheme();" class="scheme-section">
            <input type="hidden" name="aadhar" value="<?= htmlspecialchars($customer['Aadhar_Number']); ?>">
			
            <div>
                <label>Select Scheme:</label>
                <select name="scheme_id" required>
                    <option value="">-- Select Active Scheme --</option>
                    <?php foreach ($schemes as $scheme): ?>
                        <option value="<?= $scheme['id']; ?>"><?= htmlspecialchars($scheme['Scheme_Name']); ?></option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div>
                <label>Enter Scheme Card Number:</label>
                <input type="text" name="scheme_no" required pattern="[0-9]+" title="Only numbers are allowed">
            </div>

            <div style="align-self: end;">
                <button type="submit" name="add_scheme" class="search-btn">💳 Add to Scheme</button>
            </div>
        </form>
    <?php endif; ?>
</div>

<script>
function confirmAddScheme() {
    return confirm("Are you sure you want to add this member to the selected scheme?");
}
</script>
</body>
</html>
