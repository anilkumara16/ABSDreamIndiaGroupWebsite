<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
session_start();

if (!isset($_SESSION['username'])) {
    header("Location: ../login.php");
    exit();
}

require_once "../config.php";

$referrer_id = $_SESSION['username'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>My Referrals</title>
<style>
:root {
    --bg: #f5f5f5;
    --card-bg: #fff;
    --text: #222;
    --border: #ccc;
}

body {
    font-family: Arial, sans-serif;
    background-color: var(--bg);
    color: var(--text);
    display: flex;
    justify-content: center;
    min-height: 100vh;
    margin: 0;
    padding: 15px;
}

.container {
    background: var(--card-bg);
    border-radius: 12px;
    box-shadow: 0 0 10px rgba(0,0,0,0.2);
    max-width: 900px;
    width: 100%;
    padding: 20px;
    box-sizing: border-box;
}

/* ===== TABLE DEFAULT ===== */
.table-wrapper {
    width: 100%;
    overflow-x: auto;
}

table {
    width: 100%;
    border-collapse: collapse;
    font-size: 15px;
    min-width: 700px;
}

th, td {
    padding: 10px 12px;
    text-align: left;
    border-bottom: 1px solid var(--border);
}

th {
    background: #f0f0f0;
    font-weight: bold;
}

tr:nth-child(even) {
    background: #fafafa;
}

/* ===== MOBILE CARD VIEW ===== */
@media (max-width: 768px) {

    .table-wrapper {
        overflow-x: hidden;
    }

    table {
        border: 0;
        min-width: 100%;
    }

    table tr:first-child {
        display: none; /* hide header row */
    }

    table tr {
        display: block;
        margin-bottom: 15px;
        border: 1px solid #ddd;
        border-radius: 8px;
        padding: 10px;
        background: #fff;
        box-shadow: 0 2px 5px rgba(0,0,0,0.08);
    }

    table td {
        display: flex;
        justify-content: space-between;
        padding: 8px 10px;
        border: none;
        border-bottom: 1px dashed #ddd;
        font-size: 14px;
    }

    table td:last-child {
        border-bottom: none;
    }

    table td::before {
        content: attr(data-label);
        font-weight: bold;
        color: #555;
    }
}

/* ===== DESKTOP ENHANCEMENT (No UI change, just polish) ===== */
@media (min-width: 769px) {

    table {
        border-collapse: separate;
        border-spacing: 0;
        background: #ffffff;
        border-radius: 10px;
        overflow: hidden;
        box-shadow: 0 6px 18px rgba(0,0,0,0.08);
    }

    th {
        background: linear-gradient(135deg, #2c3e50, #4ca1af);
        color: #fff;
        padding: 14px;
        font-weight: 600;
        border: none;
    }

    td {
        padding: 13px 14px;
        border-bottom: 1px solid #eee;
        transition: background 0.25s ease;
    }

    tr:hover td {
        background: #f1f7ff;
    }
}
</style>

</head>

<body>
<div class="container">

<?php include 'mem_nav.php'; ?>

<img src="logo.webp" alt="ABS Dream India Logo"
     style="width:180px; height:auto; max-width:100%; display:block; margin:0 auto;">

<h1>My Referrals</h1>

<?php
$sql = "SELECT referred_name, referred_mobile, referred_email,
               pan_card, aadhaar_number, created_at
        FROM ABS_Referral_Details
        WHERE referrer_id = ?
        ORDER BY created_at DESC";

$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $referrer_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {

    echo "<div class='table-wrapper'>";
    echo "<table>";
    echo "<tr>
            <th>Sl. No</th>
            <th>Name</th>
            <th>Mobile</th>
            <th>Email</th>
            <th>PAN</th>
            <th>Aadhaar</th>
            <th>Date</th>
          </tr>";

    $sl = 1;

    while ($row = $result->fetch_assoc()) {

        // Mask Aadhaar for security
        $maskedAadhaar = "XXXXXX" . substr($row['aadhaar_number'], -4);

        echo "<tr>
        <td data-label='Sl No'>{$sl}</td>
        <td data-label='Name'>" . htmlspecialchars($row['referred_name']) . "</td>
        <td data-label='Mobile'>" . htmlspecialchars($row['referred_mobile']) . "</td>
        <td data-label='Email'>" . htmlspecialchars($row['referred_email']) . "</td>
        <td data-label='PAN'>" . htmlspecialchars($row['pan_card']) . "</td>
        <td data-label='Aadhaar'>{$maskedAadhaar}</td>
        <td data-label='Date'>" . date("d-m-Y", strtotime($row['created_at'])) . "</td>
      	</tr>";

        $sl++;
    }

    echo "</table>";
    echo "</div>";

} else {
    echo "<p>No referrals found.</p>";
}

$stmt->close();
$conn->close();
?>

</div>
</body>
</html>