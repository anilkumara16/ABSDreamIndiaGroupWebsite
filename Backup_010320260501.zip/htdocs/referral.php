<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title>ABS Dream India Group</title>
	<link rel="icon" href="img/6-1024x492.webp">
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="" name="keywords">
    <meta content="" name="description">

    <!-- Favicon -->
    <link href="img/favicon.ico" rel="icon">

    <!-- Google Web Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Open+Sans&family=Space+Grotesk&display=swap" rel="stylesheet">

    <!-- Icon Font Stylesheet -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.1/font/bootstrap-icons.css" rel="stylesheet">

    <!-- Libraries Stylesheet -->
    <link href="lib/animate/animate.min.css" rel="stylesheet">
    <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">

    <!-- Customized Bootstrap Stylesheet -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- Template Stylesheet -->
    <link href="css/style.css" rel="stylesheet">
	<style>
    .lang-kn { display: none; } /* Default: show English */
    .lang-switch {
      position: fixed;
      top: 10px;
      right: 15px;
      background: #0056b3;
      color: white;
      padding: 6px 10px;
      border-radius: 5px;
      cursor: pointer;
      font-weight: 600;
    }
	</style>
</head>

<body>
    <!-- Spinner Start -->
    <!--<div id="spinner"
        class="show bg-white position-fixed translate-middle w-100 vh-100 top-50 start-50 d-flex align-items-center justify-content-center">
        <div class="spinner-grow text-primary" style="width: 3rem; height: 3rem;" role="status">
            <span class="sr-only">Loading...</span>
        </div>
    </div>-->
    <!-- Spinner End -->


   <!-- Navbar Start -->
    <div class="container-fluid sticky-top">
        <div class="container">
            <nav class="navbar navbar-expand-lg navbar-light border-bottom border-2 border-white">
                <a href="index.html" class="navbar-brand">
                    <h1><img src="img/6-1024x492.webp" alt="ABS Logo" class="img-fluid" style="height: 50px;"></h1>
                </a>
                <button type="button" class="navbar-toggler ms-auto me-0" data-bs-toggle="collapse"
                    data-bs-target="#navbarCollapse">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarCollapse">
                    <div class="navbar-nav ms-auto">
					<div class="lang-switch" onclick="toggleLanguage()">E / ಕ</div>
						<a href="index.html" class="nav-item nav-link active">
							<span class="lang-en">Home</span>
							<span class="lang-kn">ಮುಖಪುಟ</span>
						</a>

						<a href="about.html" class="nav-item nav-link">
							<span class="lang-en">About</span>
							<span class="lang-kn">ನಮ್ಮ ಬಗ್ಗೆ</span>
						</a>

						<a href="service.html" class="nav-item nav-link">
							<span class="lang-en">Services</span>
							<span class="lang-kn">ಸೇವೆಗಳು</span>
						</a>
						<a href="referral.php" class="nav-item nav-link">
							<span class="lang-en">Referral Page</span>
							<span class="lang-kn">ಉಲ್ಲೇಖಿತ ಪುಟ</span>
						</a>
						<!-- <a href="project.html" class="nav-item nav-link">
							<span class="lang-en">Projects</span>
							<span class="lang-kn">ಯೋಜನೆಗಳು</span>
						</a> -->

						<div class="nav-item dropdown">
							<a href="#" class="nav-link dropdown-toggle" data-bs-toggle="dropdown">
								<span class="lang-en">Projects</span>
								<span class="lang-kn">ಯೋಜನೆಗಳು</span>
							</a>
							<div class="dropdown-menu bg-light mt-2">
								<a href="absgs.html" class="dropdown-item">
									<span class="lang-en">ABS Gold Scheme</span>
									<span class="lang-kn">ABS ಚಿನ್ನದ  ಯೋಜನೆ</span>
								</a>
								<!-- <a href="team.html" class="dropdown-item">
									<span class="lang-en">Our Team</span>
									<span class="lang-kn">ನಮ್ಮ ತಂಡ</span>
								</a>
								<a href="testimonial.html" class="dropdown-item">
									<span class="lang-en">Testimonial</span>
									<span class="lang-kn">ಪ್ರಶಂಸಾಪತ್ರ</span>
								</a>
								<a href="404.html" class="dropdown-item">
									<span class="lang-en">404 Page</span>
									<span class="lang-kn">404 ಪುಟ</span>
								</a> -->
							</div>
						</div>

						<a href="contact.html" class="nav-item nav-link">
							<span class="lang-en">Contact</span>
							<span class="lang-kn">ಸಂಪರ್ಕಿಸಿ</span>
						</a>
						<!--<a href="gallary.php" class="nav-item nav-link">
							<span class="lang-en">Photo Gallary</span>
							<span class="lang-kn">ಚಿತ್ರಸಂಪುಟ</span>
						</a>-->

						<a href="login.php" class="nav-item nav-link">
							<span class="lang-en">Login</span>
							<span class="lang-kn">ಪ್ರವೇಶ ಪುಟ</span>
						</a>						
                    </div>
                </div>
            </nav>
        </div>
    </div>
    <!-- Navbar End -->


    <!-- Hero Start -->
    <div class="container-fluid pb-5 bg-primary hero-header">
        <div class="container py-5">
            <div class="row g-3 align-items-center">
                <div class="col-lg-6 text-center text-lg-start">
                    <h1 class="display-1 mb-0 animated slideInLeft">
						<span class="lang-en">Refferal Page</span>
						<span class="lang-kn">ಉಲ್ಲೇಖಿತ</span>
					</h1>

                </div>
                <div class="col-lg-6 animated slideInRight">
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb justify-content-center justify-content-lg-end mb-0">
                            <li class="breadcrumb-item">
								<a class="text-primary" href="#">
									<span class="lang-en">Home</span>
									<span class="lang-kn">ಮುಖಪುಟ</span>
								</a>
							</li>
							<li class="breadcrumb-item">
								<a class="text-primary" href="#">
									<span class="lang-en">Pages</span>
									<span class="lang-kn">ಪುಟಗಳು</span>
								</a>
							</li>
							<li class="breadcrumb-item text-secondary active" aria-current="page">
								<span class="lang-en">Refferal</span>
								<span class="lang-kn">ಉಲ್ಲೇಖಿತ</span>
							</li>

                        </ol>
                    </nav>
                </div>
            </div>
        </div>
    </div>
    <!-- Hero End -->


    <!-- Contact Start -->
    <!-- <div class="container-fluid py-5">
        <div class="container py-5">
            <div class="text-center wow fadeIn" data-wow-delay="0.1s">
                <h1 class="mb-5">
					<span class="lang-en">Have Any Query?</span>
					<span class="lang-kn">ಯಾವುದೇ ಪ್ರಶ್ನೆ ಇದೆಯೆ?</span>
					<span class="text-uppercase text-primary bg-light px-2">
						<span class="lang-en">Contact Us</span>
						<span class="lang-kn">ಸಂಪರ್ಕಿಸಿ</span>
					</span>
				</h1>
            </div>
            <div class="row justify-content-center">
                <div class="col-lg-7">
                     <h4 class="text-center lh-base mb-4">Receive messages instantly with our PHP and Ajax contact form - available in the <a class="text-decoration-underline" href="https://htmlcodex.com/downloading/?item=3587">Pro Version</a> only.</h4> 
                    <div class="wow fadeIn" data-wow-delay="0.3s">
                        <form>
                            <div class="row g-3">
                                <div class="col-md-6">
                                    <div class="form-floating">
                                        <input type="text" class="form-control" id="name" placeholder="Your Name">
                                        <label for="name">Your Name</label>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-floating">
                                        <input type="email" class="form-control" id="email" placeholder="Your Email">
                                        <label for="email">Your Email</label>
                                    </div>
                                </div>
                                <div class="col-12">
                                    <div class="form-floating">
                                        <input type="text" class="form-control" id="subject" placeholder="Subject">
                                        <label for="subject">Subject</label>
                                    </div>
                                </div>
                                <div class="col-12">
                                    <div class="form-floating">
                                        <textarea class="form-control" placeholder="Leave a message here" id="message" style="height: 150px"></textarea>
                                        <label for="message">Message</label>
                                    </div>
                                </div>
                                <div class="col-12">
                                    <button class="btn btn-primary w-100 py-3" type="submit">
										<span class="lang-en">Send Message</span>
										<span class="lang-kn">ಸಂದೇಶವನ್ನು ಕಳುಹಿಸಿ</span>
									</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div> -->
    <!-- Contact End -->
	<!-- <hr style="border:none; height:2px; background-color:#28a745; width:80%; margin:30px auto; border-radius:2px;"> -->
        <div class="container-fluid py-5">
		<div class="container py-5">
			<div class="text-center wow fadeIn" data-wow-delay="0.1s">
                <h1 class="mb-5">
					<span class="lang-en">Add</span>
					<span class="lang-kn">ಉಲ್ಲೇಖವನ್ನು</span>
					<span class="text-uppercase text-primary bg-light px-2">
						<span class="lang-en">Referral</span>
						<span class="lang-kn"> ಸೇರಿಸಿ </span>
					</span>
				</h1>
            </div>
                <div style="
                width:100%;
                display:flex;
                flex-wrap:wrap;
                justify-content:center;
                align-items:center;
                gap:20px;
                ">

                <form id="referralForm" style="max-width:650px;width:100%;background:#fff;padding:25px;border-radius:10px;box-shadow:0 0 10px #ddd;">

                <h4 class="mb-3">Search Customer</h4>

                <input type="text" id="search_mobile" class="form-control" placeholder="Enter Customer Mobile Number" maxlength="10">
                <button type="button" class="btn btn-primary mt-3" onclick="searchUser()">Search</button>

                <div id="search_msg" class="mt-2"></div>

                <hr>

                <label>Customer Name</label>
                <input type="text" id="customer_name" class="form-control" readonly>

                <hr>

                <h4 class="mb-3">Referral Details</h4>

                <label>Referral Name *</label>
                <input type="text" id="ref_name" class="form-control">

                <label class="mt-3">Referral Mobile *</label>
                <input type="text" id="ref_mobile" class="form-control" maxlength="10">

                <label class="mt-3">Email</label>
                <input type="email" id="ref_email" class="form-control">

                <label class="mt-3">Aadhar</label>
                <input type="text" id="ref_aadhar" class="form-control">

                <label class="mt-3">PAN</label>
                <input type="text" id="ref_pan" class="form-control">

                <button type="button" class="btn btn-success mt-4" onclick="addReferral()">Add Referral</button>

                <div id="form_msg" class="mt-3"></div>

                </form>

                </div>

		</div>
		</div>
    <!-- Newsletter Start -->
    <!-- <div class="container-fluid bg-primary newsletter p-0">
        <div class="container p-0">
            <div class="row g-0 align-items-center">
                <div class="col-md-5 ps-lg-0 text-start wow fadeIn" data-wow-delay="0.2s">
                    <img class="img-fluid w-100" src="img/newsletter.jpg" alt="">
                </div>
                <div class="col-md-7 py-5 newsletter-text wow fadeIn" data-wow-delay="0.5s">
                    <div class="p-5">
                        <h1 class="mb-5">Subscribe the <span class="text-uppercase text-primary bg-white px-2">Newsletter</span></h1>
                        <div class="position-relative w-100 mb-2">
                            <input class="form-control border-0 w-100 ps-4 pe-5" type="text"
                                placeholder="Enter Your Email" style="height: 60px;">
                            <button type="button" class="btn shadow-none position-absolute top-0 end-0 mt-2 me-2"><i
                                    class="fa fa-paper-plane text-primary fs-4"></i></button>
                        </div>
                        <p class="mb-0">Diam sed sed dolor stet amet eirmod</p>
                    </div>
                </div>
            </div>
        </div>
    </div> -->
    <!-- Newsletter End -->


    <!-- Footer Start -->
    <div class="container-fluid bg-dark text-white-50 footer pt-5">
        <div class="container py-5">
            <div class="row g-5">
                <div class="col-md-6 col-lg-3 wow fadeIn" data-wow-delay="0.1s">
                    <a href="index.html" class="d-inline-block mb-3">
                        <h1 class="text-white"><img src="img/6-1024x492.webp" alt="ABS Logo" class="img-fluid" style="height: 70px;"></h1>
                    </a>
                    <p class="mb-4">
						<span class="lang-en">Your trusted partner for a wide range of business services, all under one roof.</span>
						<span class="lang-kn">ನಿಮಗೆ ಅಗತ್ಯವಿರುವ ಎಲ್ಲಾ ಸೇವೆಗಳನ್ನು ಒಂದೇ ವೇದಿಕೆಯಲ್ಲಿ ಪಡೆಯಬಹುದಾಗಿದೆ..</span>
					</p>

                    <!-- <a class="btn btn-primary border-2 px-4" href="https://htmlcodex.com/downloading/?item=3587">Buy Pro Version</a> -->
                </div>
                <div class="col-md-6 col-lg-3 wow fadeIn" data-wow-delay="0.3s">
                    <h5 class="text-white mb-4">
						<span class="lang-en">Get In Touch</span>
						<span class="lang-kn">ಸಂಪರ್ಕಿಸಿ</span>
					</h5>

                    <p>
						<i class="fa fa-map-marker-alt me-3"></i>
						<span class="lang-en">74, Thirula, B C M Office opposite Kotturu Road, Hagaribommanahalli, Vijayanagar District – 583212</span>
						<span class="lang-kn">74, ಥಿರುಲಾ, ಬಿ ಸಿ ಎಂ ಕಚೇರಿ ಎದುರುಗಡೆ, ಕೊಟ್ಟೂರು ರಸ್ತೆ, ಹಗರಿಬೊಮ್ಮನಹಳ್ಳಿ, ವಿಜಯನಗರ ಜಿಲ್ಲೆ – 583212</span>
					</p>

                    <p><i class="fa fa-phone-alt me-3"></i>+91 89706 88749</p>
                    <p><i class="fa fa-envelope me-3"></i>support@absdreamindiagroups.com<br>absdreamindiagroups1@gmail.com</p>
                    <div class="d-flex pt-2">
                        <!-- <a class="btn btn-outline-primary btn-square border-2 me-2" href=""><i class="fab fa-twitter"></i></a>
                        <a class="btn btn-outline-primary btn-square border-2 me-2" href=""><i class="fab fa-facebook-f"></i></a> -->
                        <a class="btn btn-outline-primary btn-square border-2 me-2" href="https://www.youtube.com/@ABSDreamIndiaGroups"><i class="fab fa-youtube"></i></a>
                        <a class="btn btn-outline-primary btn-square border-2 me-2" href="https://www.instagram.com/absdreamindiagroups/"><i class="fab fa-instagram"></i></a>
						<a class="btn btn-outline-primary btn-square border-2 me-2" href="http://wa.me/+918970688749"><i class="fab fa-whatsapp"></i></a>
                        <!-- <a class="btn btn-outline-primary btn-square border-2 me-2" href=""><i class="fab fa-linkedin-in"></i></a> -->
                    </div>
                </div>
                <div class="col-md-6 col-lg-3 wow fadeIn" data-wow-delay="0.5s">
                    <h5 class="text-white mb-4">
						<span class="lang-en">Popular Link</span>
						<span class="lang-kn">ಪ್ರಚಲಿತ ಲಿಂಕ್</span>
					</h5>
					<a class="btn btn-link" href="index.html">
						<span class="lang-en">Home</span>
						<span class="lang-kn">ಮುಖಪುಟ</span>
					</a>
					<a class="btn btn-link" href="about.html">
						<span class="lang-en">About Us</span>
						<span class="lang-kn">ನಮ್ಮ ಬಗ್ಗೆ</span>
					</a>
					<a class="btn btn-link" href="service.html">
						<span class="lang-en">Services</span>
						<span class="lang-kn">ಸೇವೆಗಳು</span>
					</a>
					<a class="btn btn-link" href="contact.html">
						<span class="lang-en">Contact Us</span>
						<span class="lang-kn">ಸಂಪರ್ಕಿಸಿ</span>
					</a>
					<a class="btn btn-link" href="referral.php">
						<span class="lang-en">Referral Page</span>
						<span class="lang-kn">ಉಲ್ಲೇಖಿತ ಪುಟ</span>
					</a>
		                        <a class="btn btn-link" href="login.php">
						<span class="lang-en">Login Page</span>
						<span class="lang-kn">ಪ್ರವೇಶ ಪುಟ</span>
					</a>
                    <!-- <a class="btn btn-link" href="">Terms & Condition</a>
                    <a class="btn btn-link" href="">Career</a> -->
                </div>
                <div class="col-md-6 col-lg-3 wow fadeIn" data-wow-delay="0.7s">
                    <h5 class="text-white mb-4">
						<span class="lang-en">Our Projects</span>
						<span class="lang-kn">ನಮ್ಮ ಯೋಜನೆಗಳು</span>
					</h5>
                    <a class="btn btn-link" href="">
						<span class="lang-en">ABS Gold Scheme</span>
						<span class="lang-kn">ABS ಚಿನ್ನದ  ಯೋಜನೆ</span>
					</a>

                    <!-- <a class="btn btn-link" href="">Project Planning</a>
                    <a class="btn btn-link" href="">Renovation</a>
                    <a class="btn btn-link" href="">Implement</a>
                    <a class="btn btn-link" href="">Landscape Design</a> -->
                </div>
            </div>
        </div>
        <div class="container wow fadeIn" data-wow-delay="0.1s">
            <div class="copyright">
                <div class="row">
                    <div class="col-md-6 text-center text-md-start mb-3 mb-md-0">
                        &copy; <a class="border-bottom" href="#">ABS Dream India Group</a>, All Right Reserved.

                        <!--/*** The author’s attribution link must remain intact in the template. ***/-->
                        <!--/*** If you wish to remove this credit link, please purchase the Pro Version . ***/-->
                        Designed By <a class="border-bottom" href="https://htmlcodex.com">HTML Codex</a>
                    </div>
                    <div class="col-md-6 text-center text-md-end">
                        <div class="footer-menu">
                            <a href="">Home</a>
                            <!-- a href="">Cookies</a>
                            <a href="">Help</a>
                            <a href="">FAQs</a> -->
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Footer End -->


    <!-- Back to Top -->
    <a href="#" class="btn btn-lg btn-primary btn-lg-square back-to-top"><i class="bi bi-arrow-up"></i></a>


    <!-- JavaScript Libraries -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.1/jquery.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="lib/wow/wow.min.js"></script>
    <script src="lib/easing/easing.min.js"></script>
    <script src="lib/waypoints/waypoints.min.js"></script>
    <script src="lib/owlcarousel/owl.carousel.min.js"></script>

    <!-- Template Javascript -->
    <script src="js/main.js"></script>
	<script>
    let currentLang = "en";
    function toggleLanguage() {
      if (currentLang === "en") {
        document.querySelectorAll(".lang-en").forEach(e => e.style.display = "none");
        document.querySelectorAll(".lang-kn").forEach(e => e.style.display = "inline");
        currentLang = "kn";
      } else {
        document.querySelectorAll(".lang-en").forEach(e => e.style.display = "inline");
        document.querySelectorAll(".lang-kn").forEach(e => e.style.display = "none");
        currentLang = "en";
      }
    }
  </script>
  <script>
    function searchUser(){

    let mobile=$("#search_mobile").val();

    if(!/^\d{10}$/.test(mobile)){
    $("#search_msg").html("<span style='color:red'>Enter valid 10 digit mobile</span>");
    return;
    }

    $.post("search_user.php",{mobile:mobile},function(res){

    if(res.status==="found"){
    $("#customer_name").val(res.name);
    $("#search_msg").html("<span style='color:green'>Customer Found</span>");
    }else{
    $("#customer_name").val("");
    $("#search_msg").html("<span style='color:red'>Mobile Not Registered</span>");
    }

    },"json");
    }



    function addReferral(){

    let search_mobile = $("#search_mobile").val().trim();
    let customer_name = $("#customer_name").val().trim();
    let referred_name = $("#ref_name").val().trim();
    let referred_mobile = $("#ref_mobile").val().trim();
    let referred_email = $("#ref_email").val().trim();
    let aadhaar_number = $("#ref_aadhar").val().trim();
    let pan_card = $("#ref_pan").val().trim().toUpperCase();

    if(customer_name===""){
    $("#form_msg").html("<span style='color:red'>Search customer first</span>");
    return;
    }

    if(!/^[A-Za-z\s]+$/.test(referred_name)){
    $("#form_msg").html("<span style='color:red'>Name should contain only letters</span>");
    return;
    }

    if(!/^[6-9]\d{9}$/.test(referred_mobile)){
    $("#form_msg").html("<span style='color:red'>Invalid mobile number</span>");
    return;
    }

    if(!/^\d{12}$/.test(aadhaar_number)){
    $("#form_msg").html("<span style='color:red'>Aadhaar must be 12 digits</span>");
    return;
    }

    if(!/^[A-Z]{5}[0-9]{4}[A-Z]{1}$/.test(pan_card)){
    $("#form_msg").html("<span style='color:red'>Invalid PAN format</span>");
    return;
    }

    $.post("add_referral.php",{

        search_mobile: search_mobile,
        customer_name: customer_name,
        referred_name: referred_name,
        referred_mobile: referred_mobile,
        referred_email: referred_email,
        aadhaar_number: aadhaar_number,
        pan_card: pan_card

    },function(res){

        $("#form_msg").html("<span style='color:green'>"+res+"</span>");
        $("#referralForm")[0].reset();
        $("#customer_name").val("");

    });

    }
</script>
</body>

</html>