<?php
    
// 🔐 Prevent indexing & phishing flags
header('X-Robots-Tag: noindex, nofollow', true);

// 🔐 Block all query parameters (login.php?i=1 etc.)
if (!empty($_GET)) {
    http_response_code(404);
    exit;
}


error_reporting(0);
ini_set('display_errors', 0);
session_start();
require_once 'logincss/config.php';

$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';
    $roleType = $_POST['roleType'] ?? '';

    if ($username === '' || $password === '' || $roleType === '') {
        $errors[] = 'Please enter all fields (username, password, and role).';
    } else {
        // ✅ Choose login table dynamically
        if ($roleType === 'MEMBER') {
            $table = 'ABS_Login_Members_Creds';
            $sql = "SELECT * FROM $table WHERE Userid = ? LIMIT 1";
        } else {
            $table = 'ABS_Login_Creds';
            $sql = "SELECT * FROM $table WHERE Username = ? AND Role = ? LIMIT 1";
        }

        if ($stmt = $conn->prepare($sql)) {
            // Bind parameters based on role
            if ($roleType === 'MEMBER') {
                $stmt->bind_param('s', $username);
            } else {
                $stmt->bind_param('ss', $username, $roleType);
            }

            $stmt->execute();
            $result = $stmt->get_result();

            if ($row = $result->fetch_assoc()) {
                // ✅ Verify password securely
                if (password_verify($password, $row['Password'])) {
                    // Always assign Username for session (common column)
                    //$_SESSION['username'] = $row['Username'];
                    $_SESSION['role'] = $roleType;
                    session_regenerate_id(true);

                    // ✅ Redirect by role type
                    if ($roleType === 'MEMBER') {
                        $_SESSION['username'] = $username;
                        $_SESSION['mem_name'] = $row['Username'];
                        header('Location: logincss/mem_Dashboard.php');
                    } else {
                        $_SESSION['username'] = $row['Username'];
                        header('Location: logincss/dashboard.php');
                    }
                    exit;
                } else {
                    $errors[] = 'Invalid username or password.';
                }
            } else {
                $errors[] = 'Invalid username, password, or role mismatch.';
            }

            $stmt->close();
        } else {
            $errors[] = 'Database error: could not prepare statement.';
        }
    }
}
?>

<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
    <!-- IMPORTANT: prevent Google indexing -->
	<meta name="robots" content="noindex, nofollow">
  <title>Login - ABS Dream India Groups</title>
  <style>
    :root{
      --bg: #f4f5f6;
      --card: #ffffff;
      --text: #111111;
      --muted: #6b6f73;
      --accent: #000000;
    }
    html,body{height:100%;}
    body{
      margin:0;
      font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,'Helvetica Neue',Arial;
      background:linear-gradient(180deg,var(--bg),#ececec);
      color:var(--text);
      display:flex;
      align-items:center;
      justify-content:center;
      padding:24px;
    }
    .container{width:100%;max-width:420px;margin:auto;}
    .card{
      background:var(--card);
      border-radius:12px;
      box-shadow:0 6px 18px rgba(16,24,32,0.08);
      padding:28px;
      border:1px solid rgba(0,0,0,0.06);
    }
    h1{margin:0 0 6px 0;font-size:22px;letter-spacing:-0.2px;}
    p.lead{margin:0 0 18px 0;color:var(--muted);font-size:13px;}
    .field{margin-bottom:14px;}
    label{display:block;font-size:13px;margin-bottom:6px;color:var(--muted);}
    input[type="text"],input[type="password"],select{
      width:100%;padding:12px 14px;font-size:15px;border-radius:8px;
      border:1px solid rgba(0,0,0,0.12);background:#fafafa;color:var(--text);
      box-sizing:border-box;outline:none;
    }
    input[type="text"]:focus,input[type="password"]:focus,select:focus{box-shadow:0 0 0 3px rgba(0,0,0,0.04);}
    .actions{display:flex;align-items:center;justify-content:space-between;gap:12px;margin-top:8px;}
    .btn{display:inline-block;padding:11px 16px;font-weight:600;border-radius:10px;text-decoration:none;text-align:center;cursor:pointer;border:none;background:var(--accent);color:#fff;font-size:14px;}
    .btn.secondary{background:transparent;color:var(--muted);border:1px solid rgba(0,0,0,0.06);}
    .error{background:#fff6f6;border:1px solid #ffd6d6;padding:10px 12px;color:#8a1f1f;border-radius:8px;margin-bottom:12px;font-size:13px;}
    .footer-note{text-align:center;margin-top:14px;font-size:13px;color:var(--muted);}
    .logo-wrapper{text-align:center;margin-bottom:14px;}
    .logo{max-width:120px;height:auto;border-radius:8px;}
    .site-title{text-align:center;font-size:22px;margin:6px 0;color:var(--text);}
    @media(max-width:480px){.logo{max-width:90px;}.site-title{font-size:18px;}}
  </style>
</head>
<body>
  <div class="container">
    <div class="card" role="main">
      <div class="logo-wrapper">
        <img src="images/logo.webp" alt="ABS Dream India Logo" class="logo">
      </div>
      <h1><center>ABS Dream India Groups</center></h1>
      <p class="lead">This secure login is intended only for registered ABS Dream India Group members and authorized users.</p>

      <?php if (!empty($errors)): ?>
        <div class="error">
          <?php echo implode('<br>', array_map('htmlspecialchars', $errors)); ?>
        </div>
      <?php endif; ?>

      <form method="post" novalidate>
        <div class="field">
          <label for="username">Username</label>
          <input id="username" name="username" type="text" autocomplete="username" required value="<?php echo htmlspecialchars($_POST['username'] ?? '') ?>">
        </div>

        <div class="field">
          <label for="password">Password</label>
          <div style="position:relative;">
            <input id="password" name="password" type="password" autocomplete="current-password" required>
            <button type="button" id="togglePwd" style="position:absolute;right:8px;top:8px;padding:6px;border-radius:6px;border:none;background:transparent;cursor:pointer;color:var(--muted);font-size:12px;">Show</button>
          </div>
        </div>

        <div class="field">
          <label for="roleType">Login As</label>
          <select id="roleType" name="roleType" required>
            <option value="">Select Role</option>
            
            <option value="USER" <?php if(($_POST['roleType'] ?? '')==='USER') echo 'selected'; ?>>USER</option>
            <option value="MEMBER" <?php if(($_POST['roleType'] ?? '')==='MEMBER') echo 'selected'; ?>>MEMBER</option>
          </select>
        </div>

        <div class="actions">
          <button class="btn" type="submit">Sign in</button>
          <a class="btn secondary" href="reset_password.php">Forgot?</a>
        </div>
        <div class="actions" style="display: flex; justify-content: center; align-items: center;">
          <a class="btn secondary" href="index.html">Back to Home Page</a>
        </div>
      </form>

      <div class="footer-note">&copy; <?php echo date('Y'); ?> ABS Dream India Group - All rights reserved<br><a href="privacy-policy.html">Privacy Policy</a>
</div>
    </div>
  </div>

  <script>
    (function(){
      var btn=document.getElementById('togglePwd');
      var pwd=document.getElementById('password');
      btn&&btn.addEventListener('click',function(){
        if(pwd.type==='password'){pwd.type='text';btn.textContent='Hide';}
        else{pwd.type='password';btn.textContent='Show';}
      });
    })();
  </script>
</body>
</html>
